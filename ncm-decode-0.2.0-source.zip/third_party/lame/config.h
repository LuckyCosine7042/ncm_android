/*
 * config.h for the Android/NDK build of libmp3lame.
 *
 * LAME normally generates this file with autoconf.  The produced file only
 * records which C library features are available, so this hand-written
 * equivalent lists the same facts for bionic (Android) on arm64-v8a with
 * clang.  It is deliberately explicit instead of relying on machine.h's
 * fallbacks: everything below is known to be true for API 26+ and NDK r28.
 *
 * Only the encoder subset of libmp3lame is built (see README.vendor.md), so
 * HAVE_MPGLIB / DECODE_ON_THE_FLY are intentionally left undefined.
 */
#ifndef LAME_CONFIG_H
#define LAME_CONFIG_H

/* Package identification (only used by version.c / build metadata). */
#define PACKAGE "lame"
#define PACKAGE_NAME "lame"
#define PACKAGE_TARNAME "lame"
#define PACKAGE_VERSION "3.100"
#define PACKAGE_STRING "lame 3.100"
#define PACKAGE_URL ""
#define PACKAGE_BUGREPORT "lame-dev@lists.sourceforge.net"
#define VERSION "3.100"

/* bionic is a normal ANSI C library. */
#define STDC_HEADERS 1
#define HAVE_ERRNO_H 1
#define HAVE_FCNTL_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRINGS_H 1
#define HAVE_STRING_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define HAVE_DLFCN_H 1

/* stdint.h provides all fixed-width types. */
#define HAVE_INT8_T 1
#define HAVE_INT16_T 1
#define HAVE_INT32_T 1
#define HAVE_INT64_T 1
#define HAVE_UINT8_T 1
#define HAVE_UINT16_T 1
#define HAVE_UINT32_T 1
#define HAVE_UINT64_T 1

/* LAME's own IEEE-754 helper types (config.h.in defines these when the
 * platform does not provide them; no Android header does). */
typedef float ieee754_float32_t;
typedef double ieee754_float64_t;
typedef long double ieee854_float80_t;

/* Functions available in bionic. */
#define HAVE_MEMCPY 1
#define HAVE_STRCHR 1
#define HAVE_STRTOL 1
#define HAVE_GETTIMEOFDAY 1

/* arm64 is IEEE754 and little endian; __BYTE_ORDER__ keeps this honest. */
#define TAKEHIRO_IEEE754_HACK 1
#define USE_FAST_LOG 1

/* LAME is compiled as a library here, without its CLI frontend. */
#define LAME_LIBRARY_BUILD 1

/* Object sizes for the machine (used by a few #if checks). */
#define SIZEOF_DOUBLE 8
#define SIZEOF_FLOAT 4
#define SIZEOF_INT 4
#define SIZEOF_LONG 8
#define SIZEOF_LONG_LONG 8
#define SIZEOF_SHORT 2
#define SIZEOF_UNSIGNED_INT 4
#define SIZEOF_UNSIGNED_LONG 8
#define SIZEOF_UNSIGNED_LONG_LONG 8
#define SIZEOF_UNSIGNED_SHORT 2

#endif /* LAME_CONFIG_H */
