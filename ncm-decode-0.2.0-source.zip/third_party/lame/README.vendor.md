# libmp3lame 3.100 (vendored encoder subset)

This directory contains the **encoding** part of LAME 3.100, vendored so the
Android build does not need network access, autotools, or a system LAME.

## Origin

* Project: LAME (LAME Ain't an MP3 Encoder), <https://lame.sourceforge.io/>
* Version: 3.100 (released 2017-10-11)
* Upstream file set used here: `libmp3lame/*.c`, `libmp3lame/*.h`,
  `libmp3lame/vector/lame_intrin.h`, `include/lame.h`, `COPYING`, `LICENSE`.
* Sources were taken verbatim from the `lame-3.100` tree as distributed in the
  `mp3lame-sys` crate (crates.io, version 0.1.11), which vendors the unmodified
  upstream release tarball. No LAME source file was modified.

## What is compiled

`ncm_jni/build.rs` compiles these 19 files into `libmp3lame.a` and links it
statically into `libncm_jni.so` (arm64-v8a only):

```
bitstream.c  encoder.c  fft.c  gain_analysis.c  id3tag.c  lame.c
newmdct.c  presets.c  psymodel.c  quantize.c  quantize_pvt.c  reservoir.c
set_get.c  tables.c  takehiro.c  util.c  vbrquantize.c  VbrTag.c  version.c
```

Not included (not needed for encoding, keeps the binary smaller):

* `mpglib_interface.c` and `mpglib/` — the MP3 *decoder*.
* `frontend/`, `Dll/`, `ACM/`, `mac/`, `dshow/` — CLI/OS frontends.
* `libmp3lame/i386/`, `libmp3lame/vector/xmm_quantize_sub.c` — x86 SIMD paths.

`config.h` in this directory is **not** an upstream file: it is the equivalent
of the `config.h` that LAME's `configure` would generate for bionic/arm64, with
the Android facts spelled out (headers present, `stdint.h` types, IEEE-754
helpers, `LAME_LIBRARY_BUILD`, no `HAVE_MPGLIB`). It is compiled with
`-DHAVE_CONFIG_H`.

## Usage in this app

Only the constant-bitrate encoder API is used (`lame_init`,
`lame_set_in_samplerate`, `lame_set_out_samplerate`, `lame_set_num_channels`,
`lame_set_brate(320)`, `lame_set_VBR(vbr_off)`, `lame_init_params`,
`lame_encode_buffer_interleaved`, `lame_encode_flush`,
`lame_get_lametag_frame`, `lame_close`) via `ncm_jni/src/lame.rs`. Encoder
quality settings are left at LAME's defaults.

## Licence

LAME's library is distributed under the **GNU Library General Public License,
version 2** (LGPL-2.1); see `COPYING` (licence text) and `LICENSE` (upstream
notes about linking). Because this app links libmp3lame statically, the LGPL
requirements for relinking/replacement and source availability apply to any
redistribution of the APK; see `THIRD_PARTY_NOTICES.md` in the repository root.

LAME is patent-free for the techniques it uses (the MP3 patents expired), but
the LGPL obligations remain.
