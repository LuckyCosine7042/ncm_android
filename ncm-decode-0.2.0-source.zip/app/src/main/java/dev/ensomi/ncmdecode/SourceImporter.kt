package dev.ensomi.ncmdecode

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.util.UUID

data class ImportedSource(
    val file: File,
    val displayName: String,
    val workDir: File,
)

object SourceImporter {
    fun copyToCache(context: Context, uri: Uri): ImportedSource {
        val displayName = queryName(context, uri) ?: "selected.ncm"
        val workDir = File(context.cacheDir, "ncm-import-${UUID.randomUUID()}")
        if (!workDir.mkdirs()) throw IOException("无法创建缓存目录")
        val target = File(workDir, "input.ncm")
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { out ->
                    input.copyTo(out, 1024 * 1024)
                    out.flush()
                }
            } ?: throw IOException("无法打开所选文件")
        } catch (t: Throwable) {
            workDir.deleteRecursively()
            throw t
        }
        return ImportedSource(target, displayName, workDir)
    }

    fun queryName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null,
        )?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Throwable) {
        null
    }

    fun querySize(context: Context, uri: Uri): Long = try {
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.SIZE),
            null,
            null,
            null,
        )?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
        } ?: -1L
    } catch (_: Throwable) {
        -1L
    }
}
