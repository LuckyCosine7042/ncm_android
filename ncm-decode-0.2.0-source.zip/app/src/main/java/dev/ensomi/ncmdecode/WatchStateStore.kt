package dev.ensomi.ncmdecode

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Persistent record of files this app has already examined.  A success is only
 * recorded after the output was validated and published.  A changed fingerprint
 * makes the same path eligible again.
 */
class WatchStateStore(context: Context) {
    data class Record(
        val path: String,
        val size: Long,
        val mtime: Long,
        val digest: String,
        val status: String,
        val outputName: String?,
        val attempts: Int,
        val error: String?,
        val updatedAt: Long,
    ) {
        fun matches(fp: FileFingerprint): Boolean =
            size == fp.size && mtime == fp.mtime && digest == fp.digest
    }

    private val file = File(context.filesDir, "watch_state.json")
    private val lock = Any()
    private val records = LinkedHashMap<String, Record>()
    private var loaded = false

    fun get(path: String): Record? = synchronized(lock) {
        ensureLoaded()
        records[path]
    }

    fun isSuccess(path: String, fp: FileFingerprint): Boolean = synchronized(lock) {
        ensureLoaded()
        val r = records[path] ?: return@synchronized false
        r.status == STATUS_SUCCESS && r.matches(fp)
    }

    /** Cheap scan-time filter; the digest is still checked before decrypting. */
    fun isSuccessAt(path: String, size: Long, mtime: Long): Boolean = synchronized(lock) {
        ensureLoaded()
        val r = records[path] ?: return@synchronized false
        r.status == STATUS_SUCCESS && r.size == size && r.mtime == mtime
    }

    fun attemptsFor(path: String, fp: FileFingerprint): Int = synchronized(lock) {
        ensureLoaded()
        val r = records[path] ?: return@synchronized 0
        if (r.matches(fp)) r.attempts else 0
    }

    fun markSuccess(path: String, fp: FileFingerprint, outputName: String?) = synchronized(lock) {
        ensureLoaded()
        records[path] = Record(
            path = path,
            size = fp.size,
            mtime = fp.mtime,
            digest = fp.digest,
            status = STATUS_SUCCESS,
            outputName = outputName,
            attempts = if (records[path]?.matches(fp) == true) (records[path]?.attempts ?: 0) + 1 else 1,
            error = null,
            updatedAt = System.currentTimeMillis(),
        )
        evict()
        save()
    }

    fun markFailure(
        path: String,
        fp: FileFingerprint,
        code: String,
        message: String,
    ) = synchronized(lock) {
        ensureLoaded()
        records[path] = Record(
            path = path,
            size = fp.size,
            mtime = fp.mtime,
            digest = fp.digest,
            status = STATUS_FAILED,
            outputName = null,
            attempts = if (records[path]?.matches(fp) == true) (records[path]?.attempts ?: 0) + 1 else 1,
            error = "$code: ${message.take(300)}",
            updatedAt = System.currentTimeMillis(),
        )
        evict()
        save()
    }

    fun successCount(): Int = synchronized(lock) {
        ensureLoaded()
        records.values.count { it.status == STATUS_SUCCESS }
    }

    fun reset() = synchronized(lock) {
        records.clear()
        loaded = true
        file.delete()
    }

    private fun ensureLoaded() {
        if (loaded) return
        loaded = true
        if (!file.isFile) return
        try {
            val root = JSONObject(file.readText(Charsets.UTF_8))
            val obj = root.optJSONObject("records") ?: return
            obj.keys().forEach { key ->
                val o = obj.optJSONObject(key) ?: return@forEach
                records[key] = Record(
                    path = key,
                    size = o.optLong("size"),
                    mtime = o.optLong("mtime"),
                    digest = o.optString("digest"),
                    status = o.optString("status", STATUS_FAILED),
                    outputName = o.optString("output").takeIf { it.isNotBlank() && it != "null" },
                    attempts = o.optInt("attempts", 1),
                    error = o.optString("error").takeIf { it.isNotBlank() },
                    updatedAt = o.optLong("updatedAt"),
                )
            }
        } catch (t: Throwable) {
            runCatching {
                file.renameTo(File(file.parentFile, "watch_state.corrupt-${System.currentTimeMillis()}.json"))
            }
            WatchEventLog.log("STATE", null, 0, 0, "处理记录损坏，已忽略: ${t.message}")
        }
    }

    private fun evict() {
        if (records.size <= MAX_RECORDS) return
        val sorted = records.values.sortedBy { it.updatedAt }
        sorted.take(records.size - MAX_RECORDS).forEach { records.remove(it.path) }
    }

    private fun save() {
        try {
            val root = JSONObject()
            root.put("version", 1)
            val obj = JSONObject()
            records.values.forEach { r ->
                obj.put(r.path, JSONObject().apply {
                    put("size", r.size)
                    put("mtime", r.mtime)
                    put("digest", r.digest)
                    put("status", r.status)
                    if (r.outputName != null) put("output", r.outputName)
                    put("attempts", r.attempts)
                    if (r.error != null) put("error", r.error)
                    put("updatedAt", r.updatedAt)
                })
            }
            root.put("records", obj)
            val tmp = File(file.parentFile, file.name + ".tmp")
            FileOutputStream(tmp).use { out ->
                out.write(root.toString().toByteArray(Charsets.UTF_8))
                out.flush()
                out.fd.sync()
            }
            if (!tmp.renameTo(file)) {
                file.delete()
                if (!tmp.renameTo(file)) {
                    tmp.copyTo(file, overwrite = true)
                    tmp.delete()
                }
            }
        } catch (t: Throwable) {
            WatchEventLog.log("STATE", null, 0, 0, "保存处理记录失败: ${t.message}")
        }
    }

    companion object {
        const val STATUS_SUCCESS = "SUCCESS"
        const val STATUS_FAILED = "FAILED"
        private const val MAX_RECORDS = 2000
    }
}
