package dev.ensomi.ncmdecode

import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/**
 * A content-aware identity for a source file.  Size+mtime alone are not enough:
 * a download can be rewritten at the same length, and some sync tools preserve
 * mtime.  Hashing the first and last 64 KiB is cheap and detects those cases.
 */
data class FileFingerprint(
    val size: Long,
    val mtime: Long,
    val digest: String,
) {
    fun sameAs(other: FileFingerprint): Boolean =
        size == other.size && mtime == other.mtime && digest == other.digest

    companion object {
        private const val CHUNK = 64 * 1024

        fun of(file: File): FileFingerprint? {
            return try {
                if (!file.isFile) return null
                val size = file.length()
                val mtime = file.lastModified()
                if (size <= 0) return null
                val md = MessageDigest.getInstance("SHA-256")
                RandomAccessFile(file, "r").use { raf ->
                    if (size <= CHUNK * 2L) {
                        val buf = ByteArray(size.toInt())
                        raf.readFully(buf)
                        md.update(buf)
                    } else {
                        val head = ByteArray(CHUNK)
                        raf.readFully(head)
                        md.update(head)
                        raf.seek(size - CHUNK)
                        val tail = ByteArray(CHUNK)
                        raf.readFully(tail)
                        md.update(tail)
                    }
                }
                // If the file grew while hashing, the result is not a stable
                // identity; report no fingerprint and let the caller retry.
                if (file.length() != size || file.lastModified() != mtime) return null
                FileFingerprint(size, mtime, md.digest().joinToString("") { "%02x".format(it) })
            } catch (_: Throwable) {
                null
            }
        }
    }
}
