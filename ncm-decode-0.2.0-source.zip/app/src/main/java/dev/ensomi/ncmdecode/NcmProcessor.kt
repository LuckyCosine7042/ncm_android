package dev.ensomi.ncmdecode

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

data class ProcessResult(
    val ok: Boolean,
    val code: String,
    val message: String,
    val outputName: String? = null,
    val outputUri: Uri? = null,
    val format: String? = null,
    val durationMs: Long = 0L,
    val bytes: Long = 0L,
    val title: String? = null,
    val artist: String? = null,
)

/**
 * Decrypts one already-accessible source file into a temporary cache file,
 * validates it in native code, then publishes it through SAF.
 *
 * FLAC sources are transcoded to MP3 320 kbps CBR inside the same native call
 * (the FLAC decode doubles as the completeness check).  If the encoder cannot
 * be used the native side validates the FLAC and returns it instead, and the
 * task still succeeds; both cases are logged, see [TranscodeDiag].
 */
object NcmProcessor {
    fun decryptAndPublish(
        context: Context,
        source: File,
        displayName: String?,
        treeUri: Uri,
        tempTag: String = "ncmdecode-man",
    ): ProcessResult {
        if (!source.isFile) {
            return ProcessResult(false, "MISSING", "源文件不存在")
        }
        val sourceSize = source.length()
        if (sourceSize < 1024) {
            return ProcessResult(false, "INVALID_NCM", "文件太小，可能不是完整的 .ncm")
        }
        if (!SafOutput.canWrite(context, treeUri)) {
            return ProcessResult(false, "OUTPUT_AUTH", "输出目录不可写，请重新选择并授权")
        }
        val need = sourceSize * 2 + 32L * 1024 * 1024
        if (context.cacheDir.usableSpace < need) {
            return ProcessResult(
                false,
                "NO_SPACE",
                "缓存空间不足：至少需要 ${DirProbe.formatBytes(need)}，当前可用 ${DirProbe.formatBytes(context.cacheDir.usableSpace)}",
            )
        }

        val workKind = when {
            tempTag.endsWith("-svc") -> "svc"
            tempTag.endsWith("-man") -> "man"
            else -> "other"
        }
        val workDir = File(context.cacheDir, "ncm-decrypt-$workKind-${UUID.randomUUID()}")
        if (!workDir.mkdirs()) {
            return ProcessResult(false, "IO", "无法创建临时目录")
        }
        val tempAudio = File(workDir, "audio.tmp")
        try {
            WatchEventLog.log(
                "DECRYPT_BEGIN",
                source.absolutePath,
                sourceSize,
                source.lastModified(),
                "display=${displayName ?: source.name}",
            )
            TranscodeDiag.probeOnce()
            val measuredFrom = TranscodeDiag.start()
            val native = NativeNcm.decryptTo(source.absolutePath, tempAudio.absolutePath)
            if (!native.ok) {
                WatchEventLog.log(
                    "DECRYPT_FAIL",
                    source.absolutePath,
                    sourceSize,
                    source.lastModified(),
                    "${native.code}: ${native.message}",
                )
                return ProcessResult(false, native.code, friendlyError(native.code, native.message))
            }
            val raw = native.raw ?: return ProcessResult(false, "NATIVE", "解密库返回空结果")
            val format = native.string("format")?.lowercase(Locale.ROOT)
                ?: return ProcessResult(false, "NATIVE", "解密库没有返回音频格式")
            if (format != "mp3" && format != "flac") {
                return ProcessResult(false, "UNSUPPORTED_FORMAT", "不支持的输出格式: $format")
            }
            // The native side decides what to publish: for FLAC input that is
            // the converted MP3 (or the FLAC itself after a transcode failure).
            val outputFile = native.string("outputPath")?.let(::File) ?: tempAudio
            if (!outputFile.isFile || outputFile.length() < 1024) {
                return ProcessResult(false, "INCOMPLETE", "解密结果为空或不完整")
            }

            val transcode = raw.optJSONObject("transcode")
            if (transcode != null && transcode.optBoolean("ok", false)) {
                TranscodeDiag.logProfile(transcode, measuredFrom)
            }
            if (raw.optBoolean("transcodeFallback", false)) {
                val reason = raw.optJSONObject("transcodeFallbackReason")
                WatchEventLog.log(
                    "TRANSCODE_FALLBACK",
                    source.absolutePath,
                    sourceSize,
                    source.lastModified(),
                    "code=${reason?.optString("code") ?: "UNKNOWN"} " +
                        "stage=${reason?.optString("stage") ?: "?"} " +
                        "message=${reason?.optString("message") ?: ""} publishing=flac",
                )
            }

            val title = raw.optString("title").takeIf { it.isNotBlank() && it != "null" }
            val artist = raw.optString("artist").takeIf { it.isNotBlank() && it != "null" }
            val base = buildBaseName(artist, title, displayName, source.name)
            val published = try {
                SafOutput.publish(context, treeUri, base, format, outputFile, tempTag)
            } catch (t: Throwable) {
                WatchEventLog.log(
                    "PUBLISH_FAIL",
                    source.absolutePath,
                    sourceSize,
                    source.lastModified(),
                    t.message,
                )
                return ProcessResult(
                    false,
                    "PUBLISH",
                    "写入输出目录失败: ${t.message ?: t.javaClass.simpleName}",
                )
            }
            WatchEventLog.log(
                "DECRYPT_OK",
                source.absolutePath,
                sourceSize,
                source.lastModified(),
                "output=${published.name} format=$format duration=${native.long("durationMs")}ms " +
                    "source=${native.string("sourceFormat") ?: format}",
            )
            return ProcessResult(
                ok = true,
                code = "OK",
                message = "已解密",
                outputName = published.name,
                outputUri = published.uri,
                format = format,
                durationMs = native.long("durationMs"),
                bytes = outputFile.length(),
                title = title,
                artist = artist,
            )
        } catch (t: Throwable) {
            WatchEventLog.log(
                "DECRYPT_ERROR",
                source.absolutePath,
                sourceSize,
                source.lastModified(),
                "${t.javaClass.simpleName}: ${t.message}",
            )
            return ProcessResult(
                false,
                "IO",
                "解密过程异常: ${t.message ?: t.javaClass.simpleName}",
            )
        } finally {
            tempAudio.delete()
            workDir.deleteRecursively()
        }
    }

    fun buildBaseName(artist: String?, title: String?, displayName: String?, fileName: String): String {
        val combined = when {
            !title.isNullOrBlank() && !artist.isNullOrBlank() -> "$artist - $title"
            !title.isNullOrBlank() -> title
            !displayName.isNullOrBlank() -> displayName.removeSuffix(".ncm").removeSuffix(".NCM")
            else -> fileName.removeSuffix(".ncm").removeSuffix(".NCM")
        }
        return SafOutput.sanitize(combined)
    }

    fun friendlyError(code: String, message: String): String = when (code) {
        "INCOMPLETE" -> "文件未下载完整或已损坏：$message"
        "INVALID_NCM" -> "不是有效的 NCM 文件：$message"
        "CANCELLED" -> "已取消"
        "NO_SPACE" -> "存储空间不足：$message"
        "UNSUPPORTED_FORMAT" -> "不支持的格式：$message"
        "AUTH", "OUTPUT_AUTH" -> "目录授权失效，请重新选择：$message"
        else -> "$code: $message"
    }

    fun resultFromJson(json: String?): Map<String, Any?> {
        if (json.isNullOrBlank()) return emptyMap()
        return try {
            val o = JSONObject(json)
            o.keys().asSequence().associateWith { o.opt(it) }
        } catch (_: Throwable) {
            emptyMap()
        }
    }
}
