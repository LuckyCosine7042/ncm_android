package dev.ensomi.ncmdecode

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.FileObserver
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File
import java.util.ArrayDeque
import java.util.LinkedHashMap
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Time-limited foreground watcher.
 *
 * FileObserver only discovers candidates.  A candidate is queued after its
 * size/mtime have been stable for a grace period; decryption and validation
 * happen on a single worker thread.  Only a validated output is published.
 */
class WatchService : Service() {

    private data class Candidate(
        val path: String,
        var lastEventAt: Long,
        var stableSince: Long,
        var lastSize: Long,
        var lastMtime: Long,
        var strongSignal: Boolean,
        var attempts: Int,
        var lastAttemptAt: Long,
        var firstSeenAt: Long,
    )

    private lateinit var config: AppConfig
    private lateinit var store: WatchStateStore
    private lateinit var notificationManager: NotificationManager
    private val main = Handler(Looper.getMainLooper())
    private val decryptor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ncm-decrypt").apply { isDaemon = true }
    }
    private val candidates = LinkedHashMap<String, Candidate>()
    private val queue = ArrayDeque<Candidate>()
    private val inFlight = mutableSetOf<String>()
    private var observer: TreeObserver? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var active = false
    private var ending = false
    private var stopRequested = false
    private var processing = false
    private var endAt = 0L
    private var startedAt = 0L
    private var processed = 0
    private var failed = 0
    private var lastAction = ""

    private val expiryRunnable = Runnable { checkExpiry() }
    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!active) return
            updateNotification()
            main.postDelayed(this, TICK_MS)
        }
    }
    private val readinessRunnable = object : Runnable {
        override fun run() {
            if (!active) return
            evaluateCandidates()
            main.postDelayed(this, READINESS_INTERVAL_MS)
        }
    }
    private val scanRunnable = object : Runnable {
        override fun run() {
            if (!active) return
            if (!ending && !stopRequested) periodicScan()
            main.postDelayed(this, SCAN_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        config = AppConfig(this)
        store = WatchStateStore(this)
        notificationManager = getSystemService(NotificationManager::class.java)
        WatchEventLog.init(this)
        createChannel()
        startForegroundSafely("正在准备…")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Always satisfy the five-second startForeground requirement, including
        // duplicate triggers and notification actions while already running.
        startForegroundSafely(currentText())
        when (intent?.action) {
            ACTION_START -> handleStart(intent.getIntExtra(EXTRA_MINUTES, AppConfig.DEFAULT_MINUTES))
            ACTION_EXTEND -> handleExtend()
            ACTION_STOP -> handleStop()
            ACTION_EXPIRE -> checkExpiry()
            else -> if (!active) {
                WatchEventLog.log("SERVICE", null, 0, 0, "未知 action，忽略")
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Deliberately keep a user-started session alive when the task is
        // swiped away; the persistent notification remains the control surface.
        WatchEventLog.log("TASK_REMOVED", null, 0, 0, "任务从最近列表移除，监听继续")
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        active = false
        isRunning = false
        stopRequested = true
        runCatching { observer?.stop() }
        observer = null
        main.removeCallbacksAndMessages(null)
        cancelExpiryAlarm()
        releaseWakeLock()
        NativeNcm.cancelCurrent()
        decryptor.shutdown()
        config.markIdle()
        runCatching {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        }
        WatchEventLog.log("SERVICE_STOP", null, 0, 0, "服务已退出")
        super.onDestroy()
    }

    // ---------------------------------------------------------------- session

    private fun handleStart(minutesRaw: Int) {
        val minutes = minutesRaw.coerceIn(1, AppConfig.MAX_MINUTES)
        if (active) {
            // Merge duplicate triggers.  Do not extend implicitly; "延长" is an
            // explicit action, otherwise repeated automation could keep the
            // session alive forever.
            WatchEventLog.log(
                "MERGE",
                null,
                0,
                0,
                "重复开始被合并，剩余 ${AppConfig.formatRemaining(endAt - System.currentTimeMillis())}",
            )
            lastAction = "重复触发已合并"
            updateNotification()
            return
        }
        if (!DirProbe.hasStorageAccess(this)) {
            fatal("尚未授予“所有文件访问”，无法监听网易云下载目录")
            return
        }
        val dir = config.watchDir?.let(::File)
        if (dir == null || !dir.isDirectory || !dir.canRead()) {
            fatal("监听目录不可用：${config.watchDir ?: "未设置"}")
            return
        }
        val tree = config.outputUri()
        if (tree == null || !SafOutput.canWrite(this, tree)) {
            fatal("输出目录不可用，请先在 App 内选择并授权输出目录")
            return
        }

        val now = System.currentTimeMillis()
        active = true
        isRunning = true
        ending = false
        stopRequested = false
        processed = 0
        failed = 0
        startedAt = now
        endAt = now + minutes * 60_000L
        config.sessionProcessed = 0
        config.sessionFailed = 0
        config.setSession(AppConfig.PHASE_ACTIVE, startedAt, endAt)
        lastAction = ""
        WatchEventLog.log(
            "SESSION_START",
            null,
            0,
            0,
            "minutes=$minutes dir=${dir.absolutePath} output=${config.outputLabel} " +
                "allFiles=${DirProbe.hasStorageAccess(this)} notification=${NotificationHelper.enabled(this)} " +
                "battery=${NotificationHelper.ignoringBattery(this)}",
        )
        val probe = DirProbe.probe(dir.absolutePath, scan = false)
        WatchEventLog.log(
            "DIR_ACCESS",
            dir.absolutePath,
            0,
            0,
            "read=${probe.readable} write=${probe.writeTest} ncm=${probe.ncmCount}",
        )
        val staleCache = cleanupCache()
        val staleDocs = SafOutput.cleanupTemp(this, tree, "ncmdecode-svc")
        WatchEventLog.log("CLEANUP_STALE", dir.absolutePath, 0, 0, "cache=$staleCache saf=$staleDocs")
        // A foreground service alone does not keep the CPU awake.  FileObserver
        // wakes us for events, but the readiness/expiry handlers otherwise stop
        // running once the screen is off.  Hold a partial wake lock for the
        // bounded session so queued work and the timer continue.
        acquireWakeLock()
        setupObserver(dir)
        initialScan(dir)
        scheduleExpiry()
        main.post(tickRunnable)
        main.post(readinessRunnable)
        main.post(scanRunnable)
        updateNotification()
    }

    private fun handleExtend() {
        if (!active) {
            handleStart(AppConfig.EXTEND_MINUTES)
            return
        }
        if (stopRequested) {
            WatchEventLog.log("EXTEND_IGNORED", null, 0, 0, "服务正在停止")
            return
        }
        val now = System.currentTimeMillis()
        val cap = startedAt + AppConfig.MAX_SESSION_MS
        val base = maxOf(endAt, now)
        endAt = minOf(base + AppConfig.EXTEND_MINUTES * 60_000L, cap)
        ending = false
        config.setSession(AppConfig.PHASE_ACTIVE, startedAt, endAt)
        WatchEventLog.log(
            "SESSION_EXTEND",
            null,
            0,
            0,
            "newEndRemaining=${AppConfig.formatRemaining(endAt - now)}",
        )
        scheduleExpiry()
        main.removeCallbacks(readinessRunnable)
        main.post(readinessRunnable)
        main.removeCallbacks(scanRunnable)
        main.post(scanRunnable)
        updateNotification()
    }

    private fun checkExpiry() {
        if (!active) return
        val now = System.currentTimeMillis()
        if (now < endAt - 1000) {
            scheduleExpiry()
            return
        }
        if (ending || stopRequested) return
        ending = true
        config.setSession(AppConfig.PHASE_ENDING, startedAt, endAt)
        cancelExpiryAlarm()
        WatchEventLog.log(
            "SESSION_EXPIRE",
            null,
            0,
            0,
            "queued=${queue.size} processing=$processing candidates=${candidates.size}",
        )
        // Stop accepting new work: unqueued candidates are dropped.  Already
        // queued tasks and the in-flight task are allowed to finish.
        val dropped = candidates.size
        candidates.clear()
        lastAction = "已到期，完成队列后退出"
        updateNotification()
        if (dropped > 0) {
            WatchEventLog.log("EXPIRE_DROP", null, 0, 0, "未入队候选 $dropped 个")
        }
        if (!processing) {
            if (queue.isNotEmpty()) drainQueue() else finishAndStop()
        }
    }

    private fun handleStop() {
        if (!active) {
            stopSelf()
            return
        }
        stopRequested = true
        ending = true
        config.setSession(AppConfig.PHASE_STOPPING, startedAt, endAt)
        cancelExpiryAlarm()
        main.removeCallbacks(expiryRunnable)
        val dropped = queue.size
        queue.clear()
        candidates.clear()
        WatchEventLog.log("SESSION_STOP", null, 0, 0, "userStop droppedQueued=$dropped processing=$processing")
        NativeNcm.cancelCurrent()
        lastAction = "正在停止并清理半成品"
        updateNotification()
        if (!processing) cleanupAndStop()
    }

    private fun finishAndStop() {
        if (stopRequested) {
            cleanupAndStop()
        } else {
            config.setSession(AppConfig.PHASE_ENDING, startedAt, endAt)
            lastAction = "队列已完成，退出"
            updateNotification()
            cleanupAndStop()
        }
    }

    private fun cleanupAndStop() {
        if (stopRequested && processing) return
        main.removeCallbacksAndMessages(null)
        val tree = config.outputUri()
        decryptor.execute {
            val removedCache = cleanupCache()
            val removedDocs = if (tree != null) SafOutput.cleanupTemp(this, tree, "ncmdecode-svc") else 0
            WatchEventLog.log(
                "CLEANUP",
                null,
                0,
                0,
                "cache=$removedCache saf=$removedDocs",
            )
            main.post {
                stopSelf()
            }
        }
    }

    private fun fatal(message: String) {
        WatchEventLog.log("START_FAIL", null, 0, 0, message)
        lastAction = message
        updateNotification()
        main.postDelayed({ stopSelf() }, 5000)
    }

    // --------------------------------------------------------------- discovery

    private fun setupObserver(dir: File) {
        val treeObserver = TreeObserver(dir)
        observer = treeObserver
        treeObserver.start()
        WatchEventLog.log("OBSERVER_START", dir.absolutePath, 0, 0, "observers=${treeObserver.count()}")
    }

    private fun initialScan(dir: File) {
        val start = SystemClock.elapsedRealtime()
        val files = DirProbe.ncmFiles(dir, maxDepth = 4, limit = 500)
        files.forEach { onCandidate(it, "SCAN", strong = false) }
        WatchEventLog.log(
            "SCAN_INITIAL",
            dir.absolutePath,
            0,
            0,
            "found=${files.size} elapsedMs=${SystemClock.elapsedRealtime() - start}",
        )
    }

    private fun periodicScan() {
        val dir = config.watchDir?.let(::File) ?: return
        val files = DirProbe.ncmFiles(dir, maxDepth = 4, limit = 500)
        var added = 0
        files.forEach { f ->
            if (!candidates.containsKey(f.absolutePath)) {
                onCandidate(f, "RESCAN", strong = false)
                added++
            }
        }
        if (added > 0) {
            WatchEventLog.log("SCAN_PERIODIC", dir.absolutePath, 0, 0, "found=${files.size} added=$added")
        }
    }

    private fun onCandidate(file: File, source: String, strong: Boolean) {
        if (!active || ending || stopRequested) return
        if (!file.isFile || !file.canRead()) return
        if (!file.name.lowercase(Locale.ROOT).endsWith(".ncm")) return
        val now = System.currentTimeMillis()
        val size = file.length()
        val mtime = file.lastModified()
        // Periodic scans must not re-enqueue a file that is already queued or
        // being decrypted, nor every already-successful file every 30 seconds.
        if (inFlight.contains(file.absolutePath) || queue.any { it.path == file.absolutePath }) return
        if (source == "RESCAN" && store.isSuccessAt(file.absolutePath, size, mtime)) return
        val existing = candidates[file.absolutePath]
        if (existing == null) {
            if (candidates.size >= MAX_CANDIDATES) {
                WatchEventLog.log("CANDIDATE_FULL", file.absolutePath, size, mtime, "candidate cap reached")
                return
            }
            candidates[file.absolutePath] = Candidate(
                path = file.absolutePath,
                lastEventAt = now,
                stableSince = 0L,
                lastSize = -1L,
                lastMtime = -1L,
                strongSignal = strong,
                attempts = 0,
                lastAttemptAt = 0L,
                firstSeenAt = now,
            )
            WatchEventLog.log("CANDIDATE_ADD", file.absolutePath, size, mtime, "source=$source strong=$strong")
        } else {
            if (existing.lastSize != size || existing.lastMtime != mtime) {
                existing.stableSince = now
            }
            existing.lastEventAt = now
            existing.strongSignal = existing.strongSignal || strong
            WatchEventLog.log(
                "CANDIDATE_EVENT",
                file.absolutePath,
                size,
                mtime,
                "source=$source strong=$strong",
            )
        }
    }

    private fun evaluateCandidates() {
        if (!active || stopRequested) return
        if (ending) {
            candidates.clear()
            return
        }
        if (processing) return
        if (queue.size >= MAX_QUEUE) return
        val now = System.currentTimeMillis()
        val iterator = candidates.values.iterator()
        while (iterator.hasNext()) {
            val c = iterator.next()
            val file = File(c.path)
            if (!file.isFile || !file.canRead()) {
                iterator.remove()
                WatchEventLog.log("CANDIDATE_GONE", c.path, 0, 0, "disappeared before queue")
                continue
            }
            val size = file.length()
            val mtime = file.lastModified()
            if (size <= 0) continue
            if (size != c.lastSize || mtime != c.lastMtime) {
                c.lastSize = size
                c.lastMtime = mtime
                c.stableSince = now
                continue
            }
            if (c.stableSince == 0L) {
                c.stableSince = now
                continue
            }
            val strong = c.strongSignal
            val required = if (strong) STRONG_STABLE_MS else STABLE_MS
            if (now - c.stableSince < required) continue
            if (c.lastAttemptAt > 0 && now - c.lastAttemptAt < RETRY_MS) continue
            if (queue.size >= MAX_QUEUE) break
            iterator.remove()
            c.attempts++
            c.lastAttemptAt = now
            queue.addLast(c)
            WatchEventLog.log(
                "CANDIDATE_QUEUE",
                c.path,
                size,
                mtime,
                "strong=$strong stableMs=${now - c.stableSince} attempt=${c.attempts}",
            )
        }
        // Queue every stable candidate before starting the worker.  Starting
        // one task per 2-second readiness tick made a 27-file initial scan take
        // almost a minute; the worker can drain the queue continuously.
        drainQueue()
    }

    // --------------------------------------------------------------- processing

    private fun drainQueue() {
        if (processing || queue.isEmpty()) {
            if (!processing && queue.isEmpty() && (ending || stopRequested)) finishAndStop()
            return
        }
        if (stopRequested) {
            queue.clear()
            finishAndStop()
            return
        }
        val c = queue.removeFirst()
        processing = true
        inFlight.add(c.path)
        updateNotification()
        try {
            decryptor.execute { processCandidate(c) }
        } catch (t: Throwable) {
            inFlight.remove(c.path)
            processing = false
            WatchEventLog.log("WORKER_FAIL", c.path, 0, 0, t.message)
            updateNotification()
            drainQueue()
        }
    }

    private fun processCandidate(c: Candidate) {
        val file = File(c.path)
        if (!active || stopRequested) {
            main.post { onProcessingFinished(c, null, null) }
            return
        }
        if (!file.isFile || !file.canRead()) {
            main.post { onProcessingFinished(c, ProcessResult(false, "MISSING", "文件已不存在"), null) }
            return
        }
        val fp = FileFingerprint.of(file)
        if (fp == null) {
            main.post { onProcessingFinished(c, ProcessResult(false, "UNSTABLE", "文件在读取时仍在变化"), null) }
            return
        }
        if (store.isSuccess(c.path, fp)) {
            WatchEventLog.log("SKIP_DONE", c.path, fp.size, fp.mtime, "same fingerprint already processed")
            main.post { onProcessingFinished(c, ProcessResult(true, "SKIP", "已处理过"), fp) }
            return
        }
        val priorAttempts = store.attemptsFor(c.path, fp)
        if (priorAttempts >= MAX_ATTEMPTS) {
            WatchEventLog.log(
                "SKIP_GAVE_UP",
                c.path,
                fp.size,
                fp.mtime,
                "fingerprint unchanged after $priorAttempts failed attempts",
            )
            main.post {
                processing = false
                lastAction = "已放弃：${file.name}（连续 $priorAttempts 次失败）"
                updateNotification()
                drainQueue()
            }
            return
        }

        val tree = config.outputUri()
        if (tree == null) {
            main.post { onProcessingFinished(c, ProcessResult(false, "OUTPUT_AUTH", "输出目录未设置"), fp) }
            return
        }
        main.post {
            lastAction = "正在解密 ${file.name}"
            updateNotification()
        }
        val result = try {
            NcmProcessor.decryptAndPublish(this, file, file.name, tree, "ncmdecode-svc")
        } catch (t: Throwable) {
            ProcessResult(false, "IO", "处理异常: ${t.message ?: t.javaClass.simpleName}")
        }
        main.post { onProcessingFinished(c, result, fp) }
    }

    private fun onProcessingFinished(c: Candidate, result: ProcessResult?, fp: FileFingerprint?) {
        processing = false
        inFlight.remove(c.path)
        if (result != null && result.ok) {
            if (result.code != "SKIP") {
                processed++
                config.sessionProcessed = processed
                lastAction = "已解密 ${result.outputName ?: File(c.path).name}"
                WatchEventLog.log(
                    "TASK_SUCCESS",
                    c.path,
                    fp?.size ?: 0,
                    fp?.mtime ?: 0,
                    "output=${result.outputName} format=${result.format} duration=${result.durationMs}ms",
                )
            }
            if (fp != null) store.markSuccess(c.path, fp, result.outputName)
        } else if (result != null) {
            failed++
            config.sessionFailed = failed
            lastAction = "失败 ${File(c.path).name}: ${result.code}"
            WatchEventLog.log(
                "TASK_FAIL",
                c.path,
                fp?.size ?: 0,
                fp?.mtime ?: 0,
                "${result.code}: ${result.message}",
            )
            if (fp != null) store.markFailure(c.path, fp, result.code, result.message)
            if (result.code == "OUTPUT_AUTH" || result.code == "PUBLISH") {
                ending = true
                config.setSession(AppConfig.PHASE_ENDING, startedAt, endAt)
                lastAction = "输出目录写入失败，结束会话"
            } else if (!ending && !stopRequested && c.attempts < MAX_ATTEMPTS && File(c.path).isFile) {
                // Re-arm only when the file is still present.  It will wait for
                // another stable window and be retried; a completed download
                // that was still growing will pass on the next attempt.
                val now = System.currentTimeMillis()
                c.stableSince = now
                c.lastAttemptAt = now
                c.lastSize = File(c.path).length()
                c.lastMtime = File(c.path).lastModified()
                c.strongSignal = true
                candidates[c.path] = c
                WatchEventLog.log("TASK_RETRY", c.path, 0, 0, "attempt=${c.attempts} code=${result.code}")
            }
        }
        updateNotification()
        drainQueue()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        try {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NcmDecode:session")
            wakeLock?.acquire(6 * 60 * 60 * 1000L)
            WatchEventLog.log("WAKELOCK", null, 0, 0, "held for session")
        } catch (t: Throwable) {
            WatchEventLog.log("WAKELOCK_FAIL", null, 0, 0, t.message)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        wakeLock = null
    }

    // ------------------------------------------------------------- notifications

    private fun currentText(): String = when {
        stopRequested -> "正在停止并清理…"
        ending -> "已到期，正在完成队列…"
        active -> "剩余 ${AppConfig.formatRemaining(endAt - System.currentTimeMillis())} · 已解密 $processed · 队列 ${queue.size + if (processing) 1 else 0}"
        lastAction.isNotBlank() -> lastAction
        else -> "正在准备…"
    }

    private fun notificationText(): String {
        val base = currentText()
        return if (lastAction.isBlank()) base else "$base\n$lastAction"
    }

    private fun buildNotification(): Notification {
        val content = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_ncm)
            .setContentTitle("NCM Decode")
            .setContentText(currentText())
            .setStyle(NotificationCompat.BigTextStyle().bigText(notificationText()))
            .setContentIntent(content)
            .setOngoing(active && !stopRequested)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)

        if (active && !stopRequested) {
            val extend = PendingIntent.getForegroundService(
                this,
                2,
                Intent(this, WatchService::class.java).setAction(ACTION_EXTEND),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            val stop = PendingIntent.getForegroundService(
                this,
                3,
                Intent(this, WatchService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            builder.addAction(R.drawable.ic_stat_ncm, "延长 30 分钟", extend)
            builder.addAction(R.drawable.ic_stat_ncm, "停止", stop)
        }
        return builder.build()
    }

    private fun startForegroundSafely(text: String) {
        val notification = buildNotification()
        val type = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
        } catch (t: Throwable) {
            WatchEventLog.log("FGS_FAIL", null, 0, 0, "${t.javaClass.simpleName}: ${t.message}")
            runCatching { stopSelf() }
        }
    }

    private fun updateNotification() {
        try {
            notificationManager.notify(NOTIFICATION_ID, buildNotification())
        } catch (t: Throwable) {
            WatchEventLog.log("NOTIFY_FAIL", null, 0, 0, t.message)
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "NCM 限时监听",
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "显示监听剩余时间、延长和停止按钮"
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        notificationManager.createNotificationChannel(channel)
    }

    // -------------------------------------------------------------------- timer

    private fun scheduleExpiry() {
        main.removeCallbacks(expiryRunnable)
        val remaining = endAt - System.currentTimeMillis()
        if (remaining <= 0) {
            main.post(expiryRunnable)
        } else {
            main.postDelayed(expiryRunnable, minOf(remaining, 60_000L))
        }
        scheduleExpiryAlarm()
    }

    private fun scheduleExpiryAlarm() {
        try {
            val am = getSystemService(AlarmManager::class.java)
            val pi = expiryPendingIntent()
            am.cancel(pi)
            if (endAt > System.currentTimeMillis()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pi)
            }
        } catch (t: Throwable) {
            WatchEventLog.log("ALARM_FAIL", null, 0, 0, t.message)
        }
    }

    private fun cancelExpiryAlarm() {
        runCatching {
            getSystemService(AlarmManager::class.java).cancel(expiryPendingIntent())
        }
    }

    private fun expiryPendingIntent(): PendingIntent = PendingIntent.getBroadcast(
        this,
        9,
        Intent(this, ExpiryReceiver::class.java).setAction(ACTION_EXPIRE_ALARM),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    // ----------------------------------------------------------------- cleanup

    private fun cleanupCache(): Int {
        var count = 0
        try {
            cacheDir.listFiles()?.forEach { f ->
                if (f.name.startsWith("ncm-decrypt-svc-")) {
                    if (f.deleteRecursively()) count++
                }
            }
        } catch (_: Throwable) {
        }
        return count
    }

    // ---------------------------------------------------------------- observers

    private inner class TreeObserver(private val root: File) {
        private val observers = mutableListOf<FileObserver>()
        private val watched = mutableSetOf<String>()

        fun start() {
            addTree(root, 0)
        }

        fun stop() {
            observers.forEach { runCatching { it.stopWatching() } }
            observers.clear()
            watched.clear()
        }

        fun count(): Int = observers.size

        private fun addTree(dir: File, depth: Int) {
            if (depth > MAX_OBSERVER_DEPTH || observers.size >= MAX_OBSERVERS) return
            if (!dir.isDirectory) return
            if (!watched.add(dir.absolutePath)) return
            try {
                @Suppress("DEPRECATION")
                val fo = object : FileObserver(dir.absolutePath, OBSERVE_MASK) {
                    override fun onEvent(event: Int, path: String?) {
                        main.post { onFileEvent(dir, event, path) }
                    }
                }
                fo.startWatching()
                observers.add(fo)
            } catch (t: Throwable) {
                WatchEventLog.log("OBSERVER_FAIL", dir.absolutePath, 0, 0, "${t.javaClass.simpleName}: ${t.message}")
            }
            val children = runCatching { dir.listFiles()?.filter { it.isDirectory } }.getOrNull() ?: return
            children.forEach { child ->
                if (!child.name.startsWith(".")) addTree(child, depth + 1)
            }
        }

        fun addNewDirectory(dir: File) {
            addTree(dir, 0)
        }
    }

    private fun onFileEvent(dir: File, event: Int, name: String?) {
        if (!active || stopRequested) return
        val file = if (name.isNullOrBlank()) dir else File(dir, name)
        val size = runCatching { if (file.exists()) file.length() else 0L }.getOrDefault(0L)
        val mtime = runCatching { if (file.exists()) file.lastModified() else 0L }.getOrDefault(0L)
        val eventName = describeEvent(event)
        val isDir = runCatching { file.isDirectory }.getOrDefault(false)
        if (name != null && (event and FileObserver.CREATE != 0 || event and FileObserver.MOVED_TO != 0)) {
            if (isDir) {
                main.postDelayed({ observer?.addNewDirectory(file) }, 1500)
            }
        }
        val ncm = file.name.lowercase(Locale.ROOT).endsWith(".ncm")
        if (ncm || isDir) {
            WatchEventLog.log(
                eventName,
                file.absolutePath,
                size,
                mtime,
                "dir=${dir.absolutePath} isDir=$isDir",
            )
        }
        if (!ncm) return
        when {
            event and (FileObserver.DELETE or FileObserver.MOVED_FROM) != 0 -> {
                candidates.remove(file.absolutePath)
                WatchEventLog.log("CANDIDATE_REMOVE", file.absolutePath, size, mtime, eventName)
            }
            else -> {
                val strong = event and (FileObserver.CLOSE_WRITE or FileObserver.MOVED_TO) != 0
                onCandidate(file, eventName, strong)
            }
        }
    }

    private fun describeEvent(event: Int): String {
        val parts = mutableListOf<String>()
        if (event and FileObserver.ACCESS != 0) parts.add("ACCESS")
        if (event and FileObserver.MODIFY != 0) parts.add("MODIFY")
        if (event and FileObserver.ATTRIB != 0) parts.add("ATTRIB")
        if (event and FileObserver.CLOSE_WRITE != 0) parts.add("CLOSE_WRITE")
        if (event and FileObserver.CLOSE_NOWRITE != 0) parts.add("CLOSE_NOWRITE")
        if (event and FileObserver.OPEN != 0) parts.add("OPEN")
        if (event and FileObserver.MOVED_FROM != 0) parts.add("MOVED_FROM")
        if (event and FileObserver.MOVED_TO != 0) parts.add("MOVED_TO")
        if (event and FileObserver.CREATE != 0) parts.add("CREATE")
        if (event and FileObserver.DELETE != 0) parts.add("DELETE")
        if (event and FileObserver.DELETE_SELF != 0) parts.add("DELETE_SELF")
        if (event and FileObserver.MOVE_SELF != 0) parts.add("MOVE_SELF")
        return if (parts.isEmpty()) "EVENT_0x${event.toString(16)}" else parts.joinToString("|")
    }

    companion object {
        const val ACTION_START = "dev.ensomi.ncmdecode.action.START"
        const val ACTION_EXTEND = "dev.ensomi.ncmdecode.action.EXTEND"
        const val ACTION_STOP = "dev.ensomi.ncmdecode.action.STOP"
        const val ACTION_EXPIRE = "dev.ensomi.ncmdecode.action.EXPIRE"
        const val ACTION_EXPIRE_ALARM = "dev.ensomi.ncmdecode.action.EXPIRE_ALARM"
        const val EXTRA_MINUTES = "minutes"

        private const val CHANNEL_ID = "ncm_watch"
        private const val NOTIFICATION_ID = 1001
        private const val TICK_MS = 15_000L
        private const val READINESS_INTERVAL_MS = 2_000L
        private const val SCAN_INTERVAL_MS = 30_000L
        private const val STABLE_MS = 8_000L
        private const val STRONG_STABLE_MS = 3_000L
        private const val RETRY_MS = 20_000L
        private const val MAX_ATTEMPTS = 5
        private const val MAX_QUEUE = 100
        private const val MAX_CANDIDATES = 1000
        private const val MAX_OBSERVERS = 300
        private const val MAX_OBSERVER_DEPTH = 5

        private const val OBSERVE_MASK = FileObserver.CREATE or
            FileObserver.CLOSE_WRITE or
            FileObserver.MOVED_TO or
            FileObserver.MOVED_FROM or
            FileObserver.DELETE or
            FileObserver.MODIFY or
            FileObserver.ATTRIB

        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
