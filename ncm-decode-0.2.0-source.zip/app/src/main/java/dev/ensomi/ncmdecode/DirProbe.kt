package dev.ensomi.ncmdecode

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

data class DirInfo(
    val path: String,
    val exists: Boolean,
    val directory: Boolean,
    val readable: Boolean,
    val writable: Boolean,
    val writeTest: String,
    val ncmCount: Int,
    val samples: List<String>,
)

object DirProbe {
    private const val MAX_SCAN = 5000

    fun candidatePaths(): List<String> {
        val root = Environment.getExternalStorageDirectory()
        val list = linkedSetOf(
            // Measured on NetEase Cloud Music 9.6.15 / Android 16 (Redmi K Pad):
            // downloaded .ncm land under Download/netease/cloudmusic/Music,
            // not under CloudMusic/Music.
            File(root, "Download/netease/cloudmusic/Music").absolutePath,
            File(root, "Download/netease/cloudmusic").absolutePath,
            File(root, "Download/netease").absolutePath,
            File(root, "CloudMusic/Music").absolutePath,
            File(root, "CloudMusic").absolutePath,
            File(root, "Music/CloudMusic").absolutePath,
            File(root, "Download/CloudMusic").absolutePath,
            File(root, "netease/cloudmusic/Music").absolutePath,
            File(root, "Android/data/com.netease.cloudmusic/files").absolutePath,
            File(root, "Android/data/com.netease.cloudmusic/files/download").absolutePath,
            File(root, "Music").absolutePath,
            File(root, "Download").absolutePath,
        )
        // Add direct children of CloudMusic, where some versions put per-quality
        // subdirectories.
        val cloud = File(root, "CloudMusic")
        runCatching {
            cloud.listFiles()?.filter { it.isDirectory }?.take(30)?.forEach { list.add(it.absolutePath) }
        }
        return list.toList()
    }

    fun autoPick(): String {
        val infos = candidatePaths().map { probe(it, scan = true) }
        val withNcm = infos.filter { it.ncmCount > 0 }.maxByOrNull { it.ncmCount }
        if (withNcm != null) return withNcm.path
        val cloud = infos.firstOrNull {
            it.exists && it.directory && it.path.endsWith("CloudMusic/Music")
        }
        if (cloud != null) return cloud.path
        return infos.firstOrNull { it.exists && it.directory }?.path
            ?: File(Environment.getExternalStorageDirectory(), "CloudMusic/Music").absolutePath
    }

    fun probe(path: String, scan: Boolean = true, maxDepth: Int = 4): DirInfo {
        val dir = File(path)
        val exists = dir.exists()
        val isDir = dir.isDirectory
        val readable = exists && isDir && runCatching { dir.canRead() && dir.list() != null }.getOrDefault(false)
        var writeTest = "未测试"
        var writable = false
        if (readable) {
            val test = File(dir, ".ncmdecode-write-test-${System.currentTimeMillis()}")
            try {
                if (test.createNewFile()) {
                    writable = true
                    writeTest = "写入成功"
                } else {
                    writeTest = "无法创建测试文件"
                }
            } catch (t: Throwable) {
                writeTest = "写入失败: ${t.javaClass.simpleName}"
            } finally {
                runCatching { test.delete() }
            }
        } else if (exists && !isDir) {
            writeTest = "不是目录"
        } else if (!exists) {
            writeTest = "目录不存在"
        } else {
            writeTest = "不可读"
        }

        var count = 0
        val samples = mutableListOf<String>()
        if (scan && readable) {
            try {
                for (f in dir.walkTopDown().maxDepth(maxDepth).onEnter { child ->
                    child == dir || !child.name.startsWith(".")
                }) {
                    if (f.isFile && f.name.lowercase(Locale.ROOT).endsWith(".ncm")) {
                        count++
                        if (samples.size < 5) {
                            samples.add("${f.name} (${formatBytes(f.length())})")
                        }
                    }
                    if (count >= MAX_SCAN) break
                }
            } catch (_: Throwable) {
            }
        }
        return DirInfo(path, exists, isDir, readable, writable, writeTest, count, samples)
    }

    fun probeReport(context: Context): String {
        val sb = StringBuilder()
        val pm = context.packageManager
        val netease = try {
            val info = pm.getPackageInfo("com.netease.cloudmusic", 0)
            val label = info.applicationInfo?.loadLabel(pm)?.toString() ?: "网易云音乐"
            "$label ${info.versionName} (${info.versionCode})"
        } catch (_: PackageManager.NameNotFoundException) {
            "未安装或不可查询"
        }
        sb.append("设备: ${Build.MANUFACTURER} ${Build.MODEL}\n")
        sb.append("系统: Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}\n")
        sb.append("网易云: $netease\n")
        sb.append("所有文件访问: ${if (hasStorageAccess(context)) "是" else "否"}\n\n")
        candidatePaths().forEach { path ->
            val info = probe(path)
            if (info.exists || info.ncmCount > 0) {
                sb.append(info.path).append('\n')
                sb.append("  目录=").append(if (info.directory) "是" else "否")
                    .append(" 可读=").append(if (info.readable) "是" else "否")
                    .append(" 可写=").append(if (info.writable) "是" else "否")
                    .append(" .ncm=").append(info.ncmCount)
                    .append(" 写测试=").append(info.writeTest).append('\n')
                info.samples.forEach { sb.append("  · ").append(it).append('\n') }
            }
        }
        return sb.toString().trimEnd()
    }

    fun ncmFiles(dir: File, maxDepth: Int = 4, limit: Int = 500): List<File> {
        val out = mutableListOf<File>()
        try {
            if (!dir.isDirectory || !dir.canRead()) return out
            dir.walkTopDown().maxDepth(maxDepth).onEnter { f ->
                if (f != dir && f.name.startsWith(".")) return@onEnter false
                true
            }.forEach { f ->
                if (f.isFile && f.name.lowercase(Locale.ROOT).endsWith(".ncm")) {
                    out.add(f)
                    if (out.size >= limit) return out
                }
            }
        } catch (_: Throwable) {
        }
        return out
    }

    fun hasStorageAccess(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasAllFiles(): Boolean = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L * 1024 * 1024 -> String.format(Locale.ROOT, "%.1f GB", bytes / (1024.0 * 1024 * 1024))
        bytes >= 1024L * 1024 -> String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024))
        bytes >= 1024 -> String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }
}
