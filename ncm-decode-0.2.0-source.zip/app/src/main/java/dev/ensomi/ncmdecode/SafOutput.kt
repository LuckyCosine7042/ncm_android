package dev.ensomi.ncmdecode

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.webkit.MimeTypeMap
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.UUID

/**
 * Publishes a validated temporary audio file into a user-selected SAF tree.
 *
 * The bytes are first written to a temporary document.  Only after that write
 * succeeds is the document renamed to the final .mp3/.flac name, so an
 * interrupted copy never appears as a successful result.
 */
object SafOutput {
    data class Published(val uri: Uri, val name: String)

    fun treeName(context: Context, treeUri: Uri): String? = try {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
        context.contentResolver.query(
            docUri,
            arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null,
            null,
            null,
        )?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Throwable) {
        null
    }

    fun canWrite(context: Context, treeUri: Uri): Boolean = try {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
        context.contentResolver.query(
            docUri,
            arrayOf(DocumentsContract.Document.COLUMN_FLAGS),
            null,
            null,
            null,
        )?.use { c ->
            if (!c.moveToFirst()) return false
            val flags = c.getInt(0)
            flags and (DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE or
                DocumentsContract.Document.FLAG_SUPPORTS_WRITE) != 0
        } ?: false
    } catch (_: Throwable) {
        false
    }

    fun publish(
        context: Context,
        treeUri: Uri,
        baseName: String,
        extension: String,
        source: File,
        tempTag: String = "ncmdecode-man",
    ): Published {
        val resolver = context.contentResolver
        val treeDocId = DocumentsContract.getTreeDocumentId(treeUri)
        val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocId)
        val mime = mimeFor(extension)
        val tempName = "$tempTag-tmp-${UUID.randomUUID()}.part"
        val tempUri = DocumentsContract.createDocument(resolver, parent, mime, tempName)
            ?: throw IOException("无法在输出目录创建临时文件")

        try {
            resolver.openOutputStream(tempUri, "w")?.use { out ->
                source.inputStream().use { input ->
                    input.copyTo(out, 1024 * 1024)
                }
                out.flush()
            } ?: throw IOException("无法打开输出临时文件")
            if (source.length() <= 0) throw IOException("临时音频为空")

            val finalName = uniqueName(context, treeUri, sanitize(baseName), extension)
            val renamed = try {
                DocumentsContract.renameDocument(resolver, tempUri, finalName)
            } catch (_: Throwable) {
                null
            }
            if (renamed != null) {
                return Published(renamed, finalName)
            }
            // Do not fall back to writing the final name directly.  If the
            // process dies during such a copy, a partial .mp3/.flac would be
            // visible as a finished result.  The temporary document is removed
            // by the catch below and the caller reports PUBLISH.
            throw IOException("输出目录不支持安全重命名，已拒绝发布半成品")
        } catch (t: Throwable) {
            runCatching { DocumentsContract.deleteDocument(resolver, tempUri) }
            throw t
        }
    }

    fun cleanupTemp(context: Context, treeUri: Uri, tag: String? = null): Int {
        val resolver = context.contentResolver
        var deleted = 0
        try {
            val treeDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId)
            val toDelete = mutableListOf<Uri>()
            resolver.query(
                children,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                ),
                null,
                null,
                null,
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    val prefix = if (tag.isNullOrBlank()) "ncmdecode-" else "$tag-"
                    if (name.startsWith(prefix) && name.contains("-tmp-")) {
                        toDelete.add(
                            DocumentsContract.buildDocumentUriUsingTree(
                                treeUri,
                                c.getString(0),
                            ),
                        )
                    }
                }
            }
            toDelete.forEach { uri ->
                if (runCatching { DocumentsContract.deleteDocument(resolver, uri) }.getOrDefault(false)) {
                    deleted++
                }
            }
        } catch (_: Throwable) {
        }
        return deleted
    }

    fun sanitize(base: String): String {
        var s = base.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim('.')
        if (s.isEmpty()) s = "decoded"
        if (s.length > 120) s = s.take(120).trim().trim('.')
        if (s.isEmpty()) s = "decoded"
        return s
    }

    private fun uniqueName(context: Context, treeUri: Uri, base: String, extension: String): String {
        val wanted = "$base.$extension"
        val existing = existingNames(context, treeUri)
        if (!existing.contains(wanted.lowercase(Locale.ROOT))) return wanted
        var i = 1
        while (i < 10000) {
            val candidate = "$base ($i).$extension"
            if (!existing.contains(candidate.lowercase(Locale.ROOT))) return candidate
            i++
        }
        return "$base-${System.currentTimeMillis()}.$extension"
    }

    private fun existingNames(context: Context, treeUri: Uri): Set<String> {
        val result = mutableSetOf<String>()
        try {
            val treeDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId)
            context.contentResolver.query(
                children,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null,
                null,
                null,
            )?.use { c ->
                while (c.moveToNext()) {
                    c.getString(0)?.let { result.add(it.lowercase(Locale.ROOT)) }
                    if (result.size > 20000) break
                }
            }
        } catch (_: Throwable) {
        }
        return result
    }

    fun mimeFor(extension: String): String = when (extension.lowercase(Locale.ROOT)) {
        "mp3" -> "audio/mpeg"
        "flac" -> "audio/flac"
        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            ?: "application/octet-stream"
    }
}
