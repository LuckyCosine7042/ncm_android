package dev.ensomi.ncmdecode

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * AlarmManager backup for the in-process expiry handler.  It never starts a new
 * session: if the service is gone, the alarm is a no-op (v1 deliberately does
 * not auto-restart after being killed).
 */
class ExpiryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!WatchService.isRunning) {
            WatchEventLog.log("EXPIRE_ALARM", null, 0, 0, "服务未运行，忽略")
            return
        }
        try {
            context.startService(
                Intent(context, WatchService::class.java)
                    .setAction(WatchService.ACTION_EXPIRE),
            )
        } catch (t: Throwable) {
            WatchEventLog.log("EXPIRE_ALARM_FAIL", null, 0, 0, t.message)
        }
    }
}
