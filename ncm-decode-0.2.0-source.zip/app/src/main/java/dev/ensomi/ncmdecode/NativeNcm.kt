package dev.ensomi.ncmdecode

import org.json.JSONObject

/**
 * Thin JNI facade.  Every call is serialized because the native cancellation
 * flag is process-global.
 */
object NativeNcm {
    private val lock = Any()

    val loadError: String? = try {
        System.loadLibrary("ncm_jni")
        null
    } catch (t: Throwable) {
        t.message ?: t.javaClass.simpleName
    }

    @JvmStatic
    external fun decrypt(inputPath: String, outputPath: String): String

    @JvmStatic
    external fun probe(inputPath: String): String

    @JvmStatic
    external fun cancel()

    data class Result(
        val ok: Boolean,
        val code: String,
        val message: String,
        val raw: JSONObject?,
    ) {
        fun string(key: String): String? = raw?.optString(key)?.takeIf { it.isNotBlank() && it != "null" }
        fun long(key: String): Long = raw?.optLong(key, 0L) ?: 0L
    }

    fun decryptTo(inputPath: String, outputPath: String): Result {
        if (loadError != null) {
            return Result(false, "NATIVE_LOAD", "无法加载解密库: $loadError", null)
        }
        return synchronized(lock) {
            val raw = try {
                decrypt(inputPath, outputPath)
            } catch (t: Throwable) {
                return@synchronized Result(
                    false,
                    "NATIVE",
                    "解密库调用失败: ${t.message ?: t.javaClass.simpleName}",
                    null,
                )
            }
            parse(raw)
        }
    }

    fun cancelCurrent() {
        if (loadError == null) {
            runCatching { cancel() }
        }
    }

    private fun parse(raw: String?): Result {
        if (raw.isNullOrBlank()) {
            return Result(false, "NATIVE", "解密库没有返回结果", null)
        }
        return try {
            val json = JSONObject(raw)
            Result(
                ok = json.optBoolean("ok", false),
                code = json.optString("code", "UNKNOWN"),
                message = json.optString("message", ""),
                raw = json,
            )
        } catch (t: Throwable) {
            Result(false, "NATIVE", "无法解析解密库结果: ${t.message}", null)
        }
    }
}
