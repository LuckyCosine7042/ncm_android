package dev.ensomi.ncmdecode

import android.Manifest
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import dev.ensomi.ncmdecode.databinding.ActivityMainBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var config: AppConfig
    private lateinit var store: WatchStateStore
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "ncm-ui-io") }
    private var manualBusy = false
    private var resumed = false
    private var pendingExternalMinutes: Int? = null
    private var lastLogRefresh = 0L

    private val openNcm = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) startManual(uri)
    }
    private val pickOutputTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) saveOutputTree(uri)
    }
    private val pickWatchTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) saveWatchTree(uri)
    }
    private val pickExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) exportLog(uri)
    }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshAll()
        maybeStartPendingExternal()
    }
    private val storagePermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshAll()
        maybeStartPendingExternal()
    }

    private val poll = object : Runnable {
        override fun run() {
            refreshStatus()
            if (System.currentTimeMillis() - lastLogRefresh > 5_000) {
                refreshLog()
                lastLogRefresh = System.currentTimeMillis()
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        config = AppConfig(this)
        store = WatchStateStore(this)
        WatchEventLog.init(this)

        if (config.watchDir.isNullOrBlank()) {
            config.watchDir = AppConfig.defaultWatchDir().absolutePath
        }
        autoDetectWatchDir()
        if (!WatchService.isRunning && config.sessionPhase != AppConfig.PHASE_IDLE) {
            // The process was killed while a session was active.  v1 does not
            // auto-resume; clear the stale display so a manual start is clean.
            config.markIdle()
        }
        wire()
        handleIntent(intent)
        refreshAll()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        refreshAll()
        maybeStartPendingExternal()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        refreshAll()
        maybeStartPendingExternal()
        handler.removeCallbacks(poll)
        handler.post(poll)
    }

    override fun onPause() {
        resumed = false
        handler.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        io.shutdownNow()
        super.onDestroy()
    }

    // -------------------------------------------------------------------- wiring

    private fun wire() {
        binding.btnAllFiles.setOnClickListener { openAllFilesSettings() }
        binding.btnNotifications.setOnClickListener { requestNotifications() }
        binding.btnBattery.setOnClickListener { openBatterySettings() }
        binding.btnOutputDir.setOnClickListener {
            pickOutputTree.launch(null)
        }
        binding.btnWatchDir.setOnClickListener { showWatchDirDialog() }
        binding.btnProbe.setOnClickListener { runProbe() }
        binding.btnStart.setOnClickListener {
            val minutes = parseMinutes()
            if (minutes == null) return@setOnClickListener
            val missing = missingForWatch()
            if (missing != null) {
                toast(missing)
                setTopStatus(missing, warning = true)
                return@setOnClickListener
            }
            startWatch(minutes, external = false)
        }
        binding.btnExtend.setOnClickListener {
            if (!isSessionLive()) {
                toast("当前没有进行中的监听")
                return@setOnClickListener
            }
            sendServiceAction(WatchService.ACTION_EXTEND, null)
            toast("已请求延长 30 分钟")
        }
        binding.btnStop.setOnClickListener {
            if (!isSessionLive()) {
                toast("当前没有进行中的监听")
                return@setOnClickListener
            }
            sendServiceAction(WatchService.ACTION_STOP, null)
            toast("正在停止，当前任务会安全结束")
        }
        binding.btnManual.setOnClickListener {
            if (WatchService.isRunning) {
                toast("监听进行中，请先停止监听再手动解密")
                return@setOnClickListener
            }
            val tree = config.outputUri()
            if (tree == null || !SafOutput.canWrite(this, tree)) {
                toast("请先选择可写的输出目录")
                return@setOnClickListener
            }
            if (manualBusy) {
                toast("正在处理上一个文件")
                return@setOnClickListener
            }
            runCatching { openNcm.launch(arrayOf("*/*")) }
                .onFailure { toast("无法打开系统文件选择器: ${it.message}") }
        }
        binding.btnRefreshLog.setOnClickListener { refreshLog() }
        binding.btnExportLog.setOnClickListener {
            val name = "ncm-decode-log-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.ROOT).format(Date())}.txt"
            runCatching { pickExport.launch(name) }
        }
        binding.btnCleanup.setOnClickListener { cleanupTemps() }
        binding.btnResetRecords.setOnClickListener { confirmResetRecords() }
    }

    // ------------------------------------------------------------------ intents

    private fun handleIntent(intent: Intent) {
        val fromDeepLink = intent.action == Intent.ACTION_VIEW &&
            intent.data?.scheme == "ncmdecode" &&
            intent.data?.host == "watch" &&
            (intent.data?.path ?: "").startsWith("/start")
        val fromExplicit = intent.action == ACTION_EXTERNAL_START
        if (!fromDeepLink && !fromExplicit) return

        val rawMinutes = when {
            fromDeepLink -> intent.data?.getQueryParameter("minutes")
            else -> intent.getIntExtra(WatchService.EXTRA_MINUTES, AppConfig.DEFAULT_MINUTES).toString()
        }
        val parsedMinutes = rawMinutes?.toIntOrNull()
        val minutes = parsedMinutes ?: AppConfig.DEFAULT_MINUTES
        config.lastExternalTrigger = System.currentTimeMillis()
        WatchEventLog.log(
            "EXTERNAL_TRIGGER",
            null,
            0,
            0,
            "minutes=$minutes fromDeepLink=$fromDeepLink action=${intent.action}",
        )
        if ((rawMinutes != null && parsedMinutes == null) || minutes !in 1..AppConfig.MAX_MINUTES) {
            pendingExternalMinutes = null
            val msg = "外部触发无效：minutes 必须在 1-${AppConfig.MAX_MINUTES} 之间（收到 ${rawMinutes ?: "空"}）"
            setTopStatus(msg, warning = true)
            toast(msg)
            WatchEventLog.log("EXTERNAL_INVALID", null, 0, 0, msg)
            return
        }
        pendingExternalMinutes = minutes
        val missing = missingForWatch()
        if (missing == null && NotificationHelper.enabled(this)) {
            maybeStartPendingExternal()
        } else {
            setTopStatus(
                "外部触发请求监听 $minutes 分钟。请先完成：${missing ?: "通知权限"}",
                warning = true,
            )
        }
    }

    private fun maybeStartPendingExternal() {
        val minutes = pendingExternalMinutes ?: return
        if (!resumed) return
        val missing = missingForWatch()
        if (missing != null) {
            setTopStatus("外部触发请求监听 $minutes 分钟。请先完成：$missing", warning = true)
            return
        }
        if (!NotificationHelper.enabled(this)) {
            setTopStatus("外部触发请求监听 $minutes 分钟。请先授予通知权限。", warning = true)
            return
        }
        pendingExternalMinutes = null
        startWatch(minutes, external = true)
    }

    private fun parseMinutes(): Int? {
        val value = binding.etMinutes.text.toString().trim().toIntOrNull()
        if (value == null || value !in 1..AppConfig.MAX_MINUTES) {
            toast("监听时长必须是 1-${AppConfig.MAX_MINUTES} 分钟")
            binding.etMinutes.requestFocus()
            return null
        }
        return value
    }

    private fun startWatch(minutes: Int, external: Boolean) {
        config.lastMinutes = minutes
        val intent = Intent(this, WatchService::class.java)
            .setAction(WatchService.ACTION_START)
            .putExtra(WatchService.EXTRA_MINUTES, minutes)
        try {
            ContextCompat.startForegroundService(this, intent)
        } catch (t: Throwable) {
            val msg = "无法启动前台服务: ${t.message ?: t.javaClass.simpleName}"
            setTopStatus(msg, warning = true)
            toast(msg)
            WatchEventLog.log("FGS_START_FAIL", null, 0, 0, msg)
            return
        }
        val msg = if (external) {
            "外部触发已开始 $minutes 分钟监听；通知建立后可返回原 App"
        } else {
            "已开始 $minutes 分钟监听"
        }
        setTopStatus(msg, warning = false)
        toast(msg)
        handler.postDelayed({ refreshAll() }, 600)
    }

    private fun sendServiceAction(action: String, extra: Int?) {
        val intent = Intent(this, WatchService::class.java).setAction(action)
        if (extra != null) intent.putExtra(WatchService.EXTRA_MINUTES, extra)
        try {
            ContextCompat.startForegroundService(this, intent)
        } catch (t: Throwable) {
            toast("操作失败: ${t.message}")
            WatchEventLog.log("ACTION_FAIL", null, 0, 0, "$action ${t.message}")
        }
    }

    private fun missingForWatch(): String? {
        if (manualBusy) return "手动解密进行中"
        if (!hasStorageAccess()) return "“所有文件访问”未授权"
        val dir = config.watchDir?.let(::File)
        if (dir == null || !dir.isDirectory) return "监听目录未设置或不存在"
        if (!dir.canRead()) return "监听目录不可读"
        val tree = config.outputUri()
        if (tree == null) return "输出目录未选择"
        if (!SafOutput.canWrite(this, tree)) return "输出目录不可写（授权可能已失效）"
        if (!NotificationHelper.enabled(this)) return "通知权限未授予"
        return null
    }

    // --------------------------------------------------------------- permissions

    private fun hasStorageAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    private fun openAllFilesSettings() {
        if (hasStorageAccess()) {
            toast("已获得所有文件访问")
            return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val appUri = Uri.parse("package:$packageName")
            val intents = listOf(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, appUri),
                Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
            )
            for (i in intents) {
                try {
                    startActivity(i)
                    return
                } catch (_: ActivityNotFoundException) {
                }
            }
            openAppDetails()
        } else {
            storagePermissions.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                ),
            )
        }
    }

    private fun requestNotifications() {
        if (NotificationHelper.enabled(this)) {
            openNotificationSettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            openNotificationSettings()
        }
    }

    private fun openNotificationSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName),
            )
        } catch (_: Throwable) {
            openAppDetails()
        }
    }

    private fun openBatterySettings() {
        if (NotificationHelper.ignoringBattery(this)) {
            toast("已不受电池优化限制")
            return
        }
        val intents = listOf(
            Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName"),
            ),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")),
        )
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (_: ActivityNotFoundException) {
            }
        }
        toast("无法打开电池优化设置")
    }

    private fun openAppDetails() {
        runCatching {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    // --------------------------------------------------------------------- paths

    private fun autoDetectWatchDir() {
        val initial = config.watchDir
        val legacyDefault = initial == AppConfig.defaultWatchDir().absolutePath ||
            initial == File(Environment.getExternalStorageDirectory(), "CloudMusic").absolutePath
        io.execute {
            val initialInfo = initial?.let { DirProbe.probe(it) }
            val best = DirProbe.autoPick()
            val bestInfo = DirProbe.probe(best)
            // Migrate the old default when it is empty, but never override a
            // non-default user choice that already contains files.
            val shouldSwitch = best != initial && bestInfo.ncmCount > 0 &&
                (initial == null || (legacyDefault && (initialInfo?.ncmCount ?: 0) == 0))
            if (shouldSwitch) {
                config.watchDir = best
                WatchEventLog.log(
                    "WATCH_AUTODETECT",
                    best,
                    0,
                    0,
                    "old=$initial oldNcm=${initialInfo?.ncmCount ?: -1} newNcm=${bestInfo.ncmCount}",
                )
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    toast("已探测到监听目录：$best")
                    refreshAll()
                    maybeStartPendingExternal()
                }
            }
        }
    }

    private fun saveOutputTree(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        } catch (t: Throwable) {
            WatchEventLog.log("OUTPUT_PERM", null, 0, 0, "持久授权失败: ${t.message}")
        }
        config.outputTree = uri.toString()
        config.outputLabel = SafOutput.treeName(this, uri) ?: uri.lastPathSegment ?: uri.toString()
        if (!SafOutput.canWrite(this, uri)) {
            toast("该目录不可写，请换一个目录")
            setTopStatus("输出目录不可写，请重新选择", warning = true)
        } else {
            toast("输出目录：${config.outputLabel}")
            WatchEventLog.log("OUTPUT_SET", null, 0, 0, config.outputLabel)
        }
        refreshAll()
    }

    private fun saveWatchTree(uri: Uri) {
        val path = treeUriToPath(uri)
        if (path == null) {
            toast("只能选择本机存储中的目录")
            return
        }
        val dir = File(path)
        if (!dir.isDirectory) {
            toast("目录不存在或不可访问")
            return
        }
        config.watchDir = dir.absolutePath
        WatchEventLog.log("WATCH_SET", dir.absolutePath, 0, 0, "via tree=$uri")
        toast("监听目录：${dir.absolutePath}")
        refreshAll()
        if (!hasStorageAccess()) {
            setTopStatus("目录已设置；监听仍需“所有文件访问”", warning = true)
        }
    }

    private fun treeUriToPath(uri: Uri): String? {
        return try {
            val docId = DocumentsContract.getTreeDocumentId(uri)
            when {
                docId.startsWith("primary:") -> {
                    val rel = docId.removePrefix("primary:")
                    File(Environment.getExternalStorageDirectory(), rel).absolutePath
                }
                docId.startsWith("raw:") -> docId.removePrefix("raw:")
                else -> null
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun showWatchDirDialog() {
        toast("正在扫描常见目录…")
        io.execute {
            val candidates = DirProbe.candidatePaths().map { DirProbe.probe(it) }
                .filter { it.exists && it.directory }
            runOnUiThread { showWatchDirChoices(candidates) }
        }
    }

    private fun showWatchDirChoices(infos: List<DirInfo>) {
        if (isFinishing) return
        val labels = infos.map { info ->
            val mark = if (info.path == config.watchDir) "● " else "○ "
            "$mark${info.path}\n    .ncm ${info.ncmCount} · 可读 ${if (info.readable) "是" else "否"}"
        }.toMutableList()
        labels.add("浏览其它目录…")
        labels.add("手动输入路径…")
        AlertDialog.Builder(this)
            .setTitle("选择网易云下载目录")
            .setItems(labels.toTypedArray()) { _, which ->
                when (which) {
                    infos.size -> pickWatchTree.launch(null)
                    infos.size + 1 -> showManualPathDialog()
                    else -> {
                        config.watchDir = infos[which].path
                        WatchEventLog.log("WATCH_SET", infos[which].path, 0, 0, "from probe")
                        refreshAll()
                    }
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showManualPathDialog() {
        val edit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(config.watchDir ?: AppConfig.defaultWatchDir().absolutePath)
            setSelection(text.length)
            setSingleLine(false)
        }
        AlertDialog.Builder(this)
            .setTitle("监听目录绝对路径")
            .setView(edit)
            .setPositiveButton("保存") { _, _ ->
                val path = edit.text.toString().trim()
                val dir = File(path)
                if (!dir.isDirectory) {
                    toast("目录不存在")
                    return@setPositiveButton
                }
                config.watchDir = dir.absolutePath
                refreshAll()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // -------------------------------------------------------------------- manual

    private fun startManual(uri: Uri) {
        val tree = config.outputUri()
        if (tree == null || !SafOutput.canWrite(this, tree)) {
            toast("请先选择可写的输出目录")
            setTopStatus("输出目录不可用，无法解密", warning = true)
            return
        }
        manualBusy = true
        binding.progressManual.visibility = View.VISIBLE
        binding.tvManualStatus.text = "正在读取所选文件…"
        io.execute {
            var imported: ImportedSource? = null
            try {
                imported = SourceImporter.copyToCache(this, uri)
                runOnUiThread {
                    binding.tvManualStatus.text =
                        "已读取 ${imported.displayName} (${DirProbe.formatBytes(imported.file.length())})，正在解密并验证…"
                }
                val result = NcmProcessor.decryptAndPublish(
                    this,
                    imported.file,
                    imported.displayName,
                    tree,
                )
                runOnUiThread { showManualResult(result, imported.displayName) }
            } catch (t: Throwable) {
                val msg = t.message ?: t.javaClass.simpleName
                WatchEventLog.log("MANUAL_ERROR", null, 0, 0, msg)
                runOnUiThread {
                    binding.tvManualStatus.text = "失败：$msg"
                    toast("解密失败: $msg")
                }
            } finally {
                imported?.workDir?.deleteRecursively()
                manualBusy = false
                runOnUiThread {
                    binding.progressManual.visibility = View.GONE
                    refreshLog()
                }
            }
        }
    }

    private fun showManualResult(result: ProcessResult, displayName: String) {
        if (result.ok) {
            val duration = if (result.durationMs > 0) {
                val total = TimeUnit.MILLISECONDS.toSeconds(result.durationMs)
                "%d:%02d".format(total / 60, total % 60)
            } else {
                "未知"
            }
            val location = "${config.outputLabel ?: "输出目录"}/${result.outputName}"
            binding.tvManualStatus.text = buildString {
                append("成功：").append(result.outputName).append('\n')
                append("格式 ").append(result.format?.uppercase(Locale.ROOT))
                append(" · 时长 ").append(duration)
                append(" · ").append(DirProbe.formatBytes(result.bytes)).append('\n')
                append("位置：").append(location)
            }
            toast("解密成功：${result.outputName}")
            WatchEventLog.log(
                "MANUAL_OK",
                null,
                0,
                0,
                "source=$displayName output=${result.outputName}",
            )
        } else {
            binding.tvManualStatus.text = "失败：${result.message}"
            toast("解密失败：${result.message}")
        }
    }

    // --------------------------------------------------------------- diagnostics

    private fun runProbe() {
        binding.tvProbe.text = "正在探测目录和写权限…"
        io.execute {
            val report = DirProbe.probeReport(this)
            runOnUiThread {
                binding.tvProbe.text = report
                WatchEventLog.log("PROBE", null, 0, 0, "目录探测完成")
                refreshLog()
            }
        }
    }

    private fun refreshLog() {
        binding.tvLog.text = WatchEventLog.recent()
    }

    private fun exportLog(uri: Uri) {
        io.execute {
            val ok = WatchEventLog.export(this, uri)
            runOnUiThread { toast(if (ok) "日志已导出" else "导出失败") }
        }
    }

    private fun cleanupTemps() {
        if (WatchService.isRunning || manualBusy) {
            toast("监听或手动解密进行中，暂不清理临时文件")
            return
        }
        io.execute {
            var cache = 0
            cacheDir.listFiles()?.forEach { f ->
                if (f.name.startsWith("ncm-decrypt-svc-") ||
                    f.name.startsWith("ncm-decrypt-man-") ||
                    f.name.startsWith("ncm-import-")
                ) {
                    if (f.deleteRecursively()) cache++
                }
            }
            val tree = config.outputUri()
            val saf = if (tree != null) SafOutput.cleanupTemp(this, tree) else 0
            runOnUiThread {
                toast("已清理缓存 $cache 个、输出临时文件 $saf 个")
                refreshLog()
            }
        }
    }

    private fun confirmResetRecords() {
        AlertDialog.Builder(this)
            .setTitle("重置处理记录？")
            .setMessage("下次开始监听时会重新检查已有 .ncm；已成功解密的文件可能再次生成副本。")
            .setPositiveButton("重置") { _, _ ->
                store.reset()
                toast("处理记录已重置")
                refreshLog()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // -------------------------------------------------------------------- status

    private fun refreshAll() {
        refreshStatus()
        refreshLog()
    }

    private fun refreshStatus() {
        val allFiles = hasStorageAccess()
        binding.tvAllFiles.text = if (allFiles) "已授权" else "未授权（监听必需）"
        binding.tvAllFiles.setTextColor(
            ContextCompat.getColor(this, if (allFiles) R.color.success else R.color.warning),
        )
        binding.btnAllFiles.text = if (allFiles) "设置" else "去授权"

        val notifications = NotificationHelper.enabled(this)
        binding.tvNotifications.text = if (notifications) "已开启" else "未开启（前台服务需要）"
        binding.tvNotifications.setTextColor(
            ContextCompat.getColor(this, if (notifications) R.color.success else R.color.warning),
        )
        binding.btnNotifications.text = if (notifications) "设置" else "去授权"

        val battery = NotificationHelper.ignoringBattery(this)
        binding.tvBattery.text = if (battery) "不受限制" else "受系统优化（锁屏测试建议设为不受限制）"
        binding.tvBattery.setTextColor(
            ContextCompat.getColor(this, if (battery) R.color.success else R.color.text_secondary),
        )

        val watchDir = config.watchDir ?: AppConfig.defaultWatchDir().absolutePath
        val dir = File(watchDir)
        binding.tvWatchDir.text = buildString {
            append(watchDir)
            if (!dir.isDirectory) append("\n（目录不存在）")
            else if (!dir.canRead()) append("\n（不可读）")
        }
        binding.tvWatchDir.setTextColor(
            ContextCompat.getColor(
                this,
                if (dir.isDirectory && dir.canRead()) R.color.text_secondary else R.color.danger,
            ),
        )

        val tree = config.outputUri()
        val outputLabel = config.outputLabel
        binding.tvOutputDir.text = when {
            tree == null -> "未选择（手动和监听都需要）"
            outputLabel.isNullOrBlank() -> tree.toString()
            else -> outputLabel
        }
        binding.tvOutputDir.setTextColor(
            ContextCompat.getColor(
                this,
                if (tree != null && SafOutput.canWrite(this, tree)) R.color.text_secondary else R.color.danger,
            ),
        )

        val phase = config.sessionPhase
        val live = WatchService.isRunning || phase == AppConfig.PHASE_ACTIVE ||
            phase == AppConfig.PHASE_ENDING || phase == AppConfig.PHASE_STOPPING
        when {
            phase == AppConfig.PHASE_STOPPING -> {
                binding.tvSession.text = "正在停止并清理…"
                binding.tvSession.setTextColor(ContextCompat.getColor(this, R.color.warning))
            }
            phase == AppConfig.PHASE_ENDING -> {
                binding.tvSession.text = "已到期，正在完成队列后退出"
                binding.tvSession.setTextColor(ContextCompat.getColor(this, R.color.warning))
            }
            live -> {
                val remaining = (config.sessionEndMs - System.currentTimeMillis()).coerceAtLeast(0L)
                binding.tvSession.text = "监听中，剩余 ${AppConfig.formatRemaining(remaining)}"
                binding.tvSession.setTextColor(ContextCompat.getColor(this, R.color.success))
            }
            else -> {
                binding.tvSession.text = "未监听"
                binding.tvSession.setTextColor(ContextCompat.getColor(this, R.color.primary_dark))
            }
        }
        binding.btnStart.isEnabled = !live
        binding.btnExtend.isEnabled = live && phase != AppConfig.PHASE_STOPPING
        binding.btnStop.isEnabled = live && phase != AppConfig.PHASE_STOPPING
        binding.etMinutes.isEnabled = !live

        val pending = pendingExternalMinutes
        val top = when {
            pending != null -> "外部触发：请求监听 $pending 分钟。完成授权和目录设置后自动开始。"
            phase == AppConfig.PHASE_STOPPING -> "正在停止；半成品会被清理。"
            phase == AppConfig.PHASE_ENDING -> "已到期，不再接收新任务，完成队列后退出。"
            live -> "监听中。通知提供“延长 30 分钟”和“停止”；可以返回其它 App。"
            !allFiles -> "监听需要“所有文件访问”；手动解密不受影响。"
            tree == null -> "请选择输出目录。手动解密只需文件选择器授权。"
            !notifications -> "请授予通知权限，否则前台服务状态不可见。"
            else -> "就绪。手动解密可使用任意 .ncm；监听使用上方配置的目录。"
        }
        setTopStatus(top, warning = pending != null || phase == AppConfig.PHASE_STOPPING ||
            phase == AppConfig.PHASE_ENDING || !allFiles || tree == null || !notifications)
    }

    private fun setTopStatus(text: String, warning: Boolean) {
        binding.tvTopStatus.text = text
        binding.tvTopStatus.setTextColor(
            ContextCompat.getColor(this, if (warning) R.color.warning else R.color.success),
        )
    }

    private fun isSessionLive(): Boolean {
        val phase = config.sessionPhase
        return WatchService.isRunning || phase == AppConfig.PHASE_ACTIVE ||
            phase == AppConfig.PHASE_ENDING
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    companion object {
        const val ACTION_EXTERNAL_START = "dev.ensomi.ncmdecode.action.START_WATCH"
    }
}
