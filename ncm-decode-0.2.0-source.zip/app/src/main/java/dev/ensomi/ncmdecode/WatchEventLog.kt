package dev.ensomi.ncmdecode

import android.content.Context
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter

/**
 * Append-only diagnostic log.  Every FileObserver event is written with the
 * file size and mtime at the moment the event was received; this is the data
 * used to decide how NetEase signals a completed download.
 */
object WatchEventLog {
    private const val TAG = "NcmDecode"
    private const val MAX_BYTES = 4L * 1024 * 1024
    private const val MAX_RING_LINES = 400
    private val lock = Any()
    private val ring = ArrayDeque<String>()
    private var logFile: File? = null
    private val timestamp: DateTimeFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME

    fun init(context: Context) {
        synchronized(lock) {
            if (logFile != null) return
            val f = File(context.filesDir, "watch-events.log")
            logFile = f
            try {
                if (f.isFile) {
                    val bytes = f.readBytes()
                    val start = (bytes.size - 128 * 1024).coerceAtLeast(0)
                    val text = String(bytes, start, bytes.size - start, Charsets.UTF_8)
                    text.lineSequence().filter { it.isNotBlank() }.forEach { line ->
                        ring.addLast(line)
                        while (ring.size > MAX_RING_LINES) ring.removeFirst()
                    }
                }
            } catch (_: Throwable) {
            }
        }
    }

    fun log(event: String, path: String?, size: Long, mtime: Long, detail: String? = null) {
        val line = buildString {
            append(OffsetDateTime.now().format(timestamp))
            append(" event=").append(event)
            if (path != null) append(" path=\"").append(escape(path)).append('"')
            if (size > 0 || path != null) append(" size=").append(size)
            if (mtime > 0 || path != null) append(" mtime=").append(mtime)
            if (!detail.isNullOrBlank()) append(" detail=\"").append(escape(detail)).append('"')
        }
        synchronized(lock) {
            ring.addLast(line)
            while (ring.size > MAX_RING_LINES) ring.removeFirst()
            try {
                val f = logFile ?: return
                if (f.length() > MAX_BYTES) {
                    val old = File(f.parentFile, f.name + ".1")
                    old.delete()
                    f.renameTo(old)
                }
                FileOutputStream(f, true).use { out ->
                    out.write((line + "\n").toByteArray(Charsets.UTF_8))
                }
            } catch (_: Throwable) {
            }
        }
        Log.i(TAG, line)
    }

    fun recent(maxChars: Int = 14000): String {
        synchronized(lock) {
            if (ring.isEmpty()) return "暂无日志"
            val out = StringBuilder()
            for (line in ring.asReversed()) {
                if (out.length + line.length + 1 > maxChars) break
                out.insert(0, line + "\n")
            }
            return out.toString().trimEnd()
        }
    }

    fun export(context: Context, uri: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                synchronized(lock) {
                    val f = logFile
                    if (f != null && f.isFile) {
                        f.inputStream().use { it.copyTo(out) }
                    }
                    if (ring.isEmpty()) {
                        out.write("暂无日志\n".toByteArray(Charsets.UTF_8))
                    }
                }
            }
            true
        } catch (t: Throwable) {
            log("EXPORT_ERROR", null, 0, 0, t.message)
            false
        }
    }

    private fun escape(s: String): String = s.replace("\\", "\\\\").replace("\"", "\\\"")
        .replace("\n", " ").replace("\r", " ")
}
