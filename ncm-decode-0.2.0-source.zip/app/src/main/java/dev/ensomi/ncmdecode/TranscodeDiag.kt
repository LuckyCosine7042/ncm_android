package dev.ensomi.ncmdecode

import android.media.MediaCodecList
import android.os.Debug
import android.os.SystemClock
import org.json.JSONObject
import java.io.File

/**
 * Diagnostics for the FLAC -> MP3 path.
 *
 * Emits two kinds of lines through [WatchEventLog] (so they appear both in the
 * in-app log and in `adb logcat -s NcmDecode`):
 *
 * - `TRANSCODE_ENCODER` once per process: which encoder is used, and whether the
 *   device happens to expose a MediaCodec `audio/mpeg` encoder.
 * - `TRANSCODE_PROFILE` once per transcoded file: byte counts, wall/CPU time,
 *   peak RSS, sample rate/channel handling and the throughputs derived from
 *   them.  This is the line the profile report is built from.
 *
 * The measurements are cheap (two clock reads, two `/proc/self` reads) and are
 * taken around the native call, so they can stay in the release build.
 */
object TranscodeDiag {
    private const val MIME_MPEG = "audio/mpeg"

    @Volatile
    private var probed = false

    /** Log the encoder choice and the MediaCodec MP3 encoder availability once. */
    fun probeOnce() {
        if (probed) return
        probed = true
        val mediaCodec = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
                .filter { it.isEncoder }
                .any { info -> info.supportedTypes.any { it.equals(MIME_MPEG, ignoreCase = true) } }
        } catch (_: Throwable) {
            false
        }
        WatchEventLog.log(
            "TRANSCODE_ENCODER",
            null,
            0,
            0,
            "encoder=lame-3.100 mediaCodecMp3=$mediaCodec " +
                "note=MediaCodec audio/mpeg encoders are vendor-specific, LAME is bundled",
        )
    }

    /** Snapshot taken immediately before the native decrypt call. */
    class Start(val wallMs: Long, val cpuMs: Long, val rssKb: Long)

    fun start(): Start = Start(
        wallMs = SystemClock.elapsedRealtime(),
        cpuMs = Debug.threadCpuTimeNanos() / 1_000_000L,
        rssKb = peakRssKb(),
    )

    /** Log one `TRANSCODE_PROFILE` line for a successful transcode. */
    fun logProfile(transcode: JSONObject, start: Start) {
        val wallMs = (SystemClock.elapsedRealtime() - start.wallMs).coerceAtLeast(0L)
        val cpuMs = (Debug.threadCpuTimeNanos() / 1_000_000L - start.cpuMs).coerceAtLeast(0L)
        val rssPeak = peakRssKb()
        val inputBytes = transcode.optLong("inputBytes", 0L)
        val outputBytes = transcode.optLong("outputBytes", 0L)
        val pcmBytes = transcode.optLong("pcmBytes", 0L)
        val durationMs = transcode.optLong("durationMs", 0L)
        val transcodeMs = transcode.optLong("transcodeMs", 0L).coerceAtLeast(1L)
        val decodeMs = transcode.optLong("decodeMs", 0L)
        val encodeMs = transcode.optLong("encodeMs", 0L)
        val validateMs = transcode.optLong("validateMs", 0L)
        val seconds = transcodeMs / 1000.0
        val audioSeconds = durationMs / 1000.0
        val ratio = if (inputBytes > 0) outputBytes.toDouble() / inputBytes else 0.0
        val flacMbps = if (seconds > 0) inputBytes / 1_000_000.0 / seconds else 0.0
        val pcmMbps = if (seconds > 0) pcmBytes / 1_000_000.0 / seconds else 0.0
        val realtime = if (seconds > 0) audioSeconds / seconds else 0.0
        WatchEventLog.log(
            "TRANSCODE_PROFILE",
            null,
            inputBytes,
            0,
            String.format(
                java.util.Locale.ROOT,
                "encoder=%s in=%d out=%d ratio=%.3f wallMs=%d cpuMs=%d rssStartKb=%d " +
                    "rssPeakKb=%d rssDeltaKb=%d sr=%d->%d ch=%d kbps=%d frames=%d mp3Frames=%d " +
                    "decodeMs=%d encodeMs=%d transcodeMs=%d validateMs=%d " +
                    "flacMBps=%.2f pcmMBps=%.2f realtime=%.2fx resampled=%s",
                transcode.optString("encoder", "lame"),
                inputBytes,
                outputBytes,
                ratio,
                wallMs,
                cpuMs,
                start.rssKb,
                rssPeak,
                (rssPeak - start.rssKb).coerceAtLeast(0L),
                transcode.optInt("sampleRate", 0),
                transcode.optInt("outputSampleRate", 0),
                transcode.optInt("channels", 0),
                transcode.optInt("bitrateKbps", 0),
                transcode.optLong("decodedFrames", 0L),
                transcode.optLong("mp3Frames", 0L),
                decodeMs,
                encodeMs,
                transcodeMs,
                validateMs,
                flacMbps,
                pcmMbps,
                realtime,
                transcode.optBoolean("resampled", false),
            ),
        )
    }

    /**
     * Peak resident set size of this process in KiB (`VmHWM`), or 0 when the
     * file cannot be read.  `VmHWM` is monotonic, so the delta across one
     * transcode is the peak memory that operation needed.
     */
    fun peakRssKb(): Long = try {
        File("/proc/self/status").useLines { lines ->
            lines.firstOrNull { it.startsWith("VmHWM:") }
                ?.removePrefix("VmHWM:")
                ?.trim()
                ?.removeSuffix("kB")
                ?.trim()
                ?.toLongOrNull()
                ?: 0L
        }
    } catch (_: Throwable) {
        0L
    }
}
