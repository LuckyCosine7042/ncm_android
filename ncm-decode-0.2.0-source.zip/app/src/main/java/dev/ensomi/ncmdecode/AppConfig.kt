package dev.ensomi.ncmdecode

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Small persistent settings/session store.  The service is the only writer of
 * session fields while running; the activity polls them for display.
 */
class AppConfig(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("ncm_decode", Context.MODE_PRIVATE)

    var watchDir: String?
        get() = prefs.getString(KEY_WATCH_DIR, null)
        set(value) = prefs.edit().putString(KEY_WATCH_DIR, value).apply()

    var outputTree: String?
        get() = prefs.getString(KEY_OUTPUT_TREE, null)
        set(value) = prefs.edit().putString(KEY_OUTPUT_TREE, value).apply()

    var outputLabel: String?
        get() = prefs.getString(KEY_OUTPUT_LABEL, null)
        set(value) = prefs.edit().putString(KEY_OUTPUT_LABEL, value).apply()

    var lastMinutes: Int
        get() = prefs.getInt(KEY_LAST_MINUTES, DEFAULT_MINUTES)
        set(value) = prefs.edit().putInt(KEY_LAST_MINUTES, value).apply()

    var sessionPhase: String
        get() = prefs.getString(KEY_PHASE, PHASE_IDLE) ?: PHASE_IDLE
        set(value) = prefs.edit().putString(KEY_PHASE, value).apply()

    var sessionStartedMs: Long
        get() = prefs.getLong(KEY_STARTED, 0L)
        set(value) = prefs.edit().putLong(KEY_STARTED, value).apply()

    var sessionEndMs: Long
        get() = prefs.getLong(KEY_END, 0L)
        set(value) = prefs.edit().putLong(KEY_END, value).apply()

    var sessionProcessed: Int
        get() = prefs.getInt(KEY_PROCESSED, 0)
        set(value) = prefs.edit().putInt(KEY_PROCESSED, value).apply()

    var sessionFailed: Int
        get() = prefs.getInt(KEY_FAILED, 0)
        set(value) = prefs.edit().putInt(KEY_FAILED, value).apply()

    var lastExternalTrigger: Long
        get() = prefs.getLong(KEY_LAST_TRIGGER, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_TRIGGER, value).apply()

    fun setSession(phase: String, startedMs: Long, endMs: Long) {
        prefs.edit()
            .putString(KEY_PHASE, phase)
            .putLong(KEY_STARTED, startedMs)
            .putLong(KEY_END, endMs)
            .apply()
    }

    fun markIdle() {
        prefs.edit()
            .putString(KEY_PHASE, PHASE_IDLE)
            .putLong(KEY_STARTED, 0L)
            .putLong(KEY_END, 0L)
            .apply()
    }

    fun remainingMs(now: Long = System.currentTimeMillis()): Long {
        if (sessionPhase == PHASE_IDLE) return 0L
        return (sessionEndMs - now).coerceAtLeast(0L)
    }

    fun outputUri(): Uri? = outputTree?.let(Uri::parse)

    companion object {
        const val DEFAULT_MINUTES = 30
        const val MAX_MINUTES = 180
        const val EXTEND_MINUTES = 30
        const val MAX_SESSION_MS = 6 * 60 * 60 * 1000L

        const val PHASE_IDLE = "idle"
        const val PHASE_ACTIVE = "active"
        const val PHASE_ENDING = "ending"
        const val PHASE_STOPPING = "stopping"

        private const val KEY_WATCH_DIR = "watch_dir"
        private const val KEY_OUTPUT_TREE = "output_tree"
        private const val KEY_OUTPUT_LABEL = "output_label"
        private const val KEY_LAST_MINUTES = "last_minutes"
        private const val KEY_PHASE = "session_phase"
        private const val KEY_STARTED = "session_started"
        private const val KEY_END = "session_end"
        private const val KEY_PROCESSED = "session_processed"
        private const val KEY_FAILED = "session_failed"
        private const val KEY_LAST_TRIGGER = "last_external_trigger"

        fun formatRemaining(ms: Long): String {
            val total = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0L))
            val m = total / 60
            val s = total % 60
            return "%02d:%02d".format(m, s)
        }

        fun defaultWatchDir(): File {
            val root = android.os.Environment.getExternalStorageDirectory()
            return File(root, "CloudMusic/Music")
        }
    }
}
