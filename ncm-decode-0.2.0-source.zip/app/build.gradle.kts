import org.gradle.internal.os.OperatingSystem

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val rustProjectDir = rootProject.projectDir.resolve("ncm_jni")
val rustTarget = "aarch64-linux-android"
val jniLibsDir = layout.projectDirectory.dir("src/main/jniLibs/arm64-v8a").asFile

android {
    namespace = "dev.ensomi.ncmdecode"
    compileSdk = 36
    ndkVersion = "28.2.13676358"

    defaultConfig {
        applicationId = "dev.ensomi.ncmdecode"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "0.2.0"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            ndk {
                // Emulator-only ABI for local UI/service testing.  Release is
                // arm64-v8a only.
                abiFilters += listOf("x86_64")
            }
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            // Self-use build: sign with the local debug key so the APK is
            // directly installable.  Replace this with a private release key
            // before distributing it.
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
    }
    lint {
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
}

val cargoExecutable: String = run {
    val configured = providers.gradleProperty("cargoPath").orNull
    if (!configured.isNullOrBlank()) return@run configured
    val fromEnv = System.getenv("CARGO")
    if (!fromEnv.isNullOrBlank()) return@run fromEnv
    val home = System.getProperty("user.home")
    val candidate = File(home, ".cargo/bin/cargo" + if (OperatingSystem.current().isWindows) ".exe" else "")
    if (candidate.isFile) candidate.absolutePath else "cargo"
}

val hostTag: String = when {
    OperatingSystem.current().isWindows -> "windows-x86_64"
    OperatingSystem.current().isMacOsX -> "darwin-x86_64"
    else -> "linux-x86_64"
}

val ndkDir = android.ndkDirectory
val clangName = "aarch64-linux-android26-clang" + if (OperatingSystem.current().isWindows) ".cmd" else ""
val ndkClang = File(ndkDir, "toolchains/llvm/prebuilt/$hostTag/bin/$clangName")

val buildRustArm64 by tasks.registering(Exec::class) {
    group = "rust"
    description = "Build libncm_jni.so for arm64-v8a with the Android NDK"
    workingDir = rustProjectDir
    inputs.dir(rustProjectDir.resolve("src"))
    inputs.file(rustProjectDir.resolve("Cargo.toml"))
    inputs.dir(rootProject.projectDir.resolve("third_party/ncmc_lib"))
    outputs.file(File(rustProjectDir, "target/$rustTarget/release/libncm_jni.so"))
    environment("CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER", ndkClang.absolutePath)
    environment("CC_aarch64_linux_android", ndkClang.absolutePath)
    environment(
        "AR_aarch64_linux_android",
        File(ndkDir, "toolchains/llvm/prebuilt/$hostTag/bin/llvm-ar.exe").absolutePath,
    )
    environment(
        "CARGO_TARGET_AARCH64_LINUX_ANDROID_RUSTFLAGS",
        "-C link-arg=-Wl,-z,max-page-size=16384",
    )
    commandLine(cargoExecutable, "build", "--release", "--lib", "--target", rustTarget)
    doLast {
        val source = File(rustProjectDir, "target/$rustTarget/release/libncm_jni.so")
        check(source.isFile) { "Rust build did not produce ${source.absolutePath}" }
        jniLibsDir.mkdirs()
        source.copyTo(File(jniLibsDir, "libncm_jni.so"), overwrite = true)
        println("Copied ${source.length()} bytes to $jniLibsDir/libncm_jni.so")
    }
}

tasks.named("preBuild").configure { dependsOn(buildRustArm64) }
tasks.matching { it.name.startsWith("merge") && it.name.contains("JniLibFolders") }.configureEach {
    dependsOn(buildRustArm64)
}
