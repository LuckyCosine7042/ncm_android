# JNI entry points are resolved by name; keep them.
-keepclasseswithmembernames class dev.ensomi.ncmdecode.NativeNcm { native <methods>; }
