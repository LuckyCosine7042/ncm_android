# 关键问题结论与已知限制

日期：2026-11-02（Asia/Shanghai）  
设备：Xiaomi Redmi K Pad，型号 25079RPDCC，Android 16 / API 36，arm64-v8a，安全补丁 2026-08-01  
网易云音乐：9.6.15（versionCode 9006015），targetSdk 33  
测试 App：`dev.ensomi.ncmdecode` 0.1.0 / 0.2.0（release，arm64-v8a，debug key）

## 1. 网易云怎样表示下载完成？

**更正（2026-11-02 21:15，同一台设备）：网易云 9.6.15 的“下载”确实会写 `.ncm` 到共享存储，路径是
`/sdcard/Download/netease/cloudmusic/Music/`。** 实测一次批量下载落盘 27 个 `.ncm`（5.1–12.9 MB，时间集中在 21:15–21:16）。

此前“共享存储没有 `.ncm`”的观察对应的是**试听/缓存**路径，不是“下载”：

| 行为 | 落盘位置 | 格式 |
|---|---|---|
| 在线播放 / 试听缓存 | `Android/data/com.netease.cloudmusic/files/Cache/Music3/…` | `.nmsf` 分片，不是完整 NCM 容器 |
| 点“下载” | `/sdcard/Download/netease/cloudmusic/Music/` | `.ncm` |

因此 App 的监听目录应指向 `Download/netease/cloudmusic/Music`；`CloudMusic/Music` 在这台设备上是空目录。
`DirProbe.candidatePaths()` 原先漏了这条路径，且 `Download` 的扫描深度只有 3 层（文件在第 4 层），
导致“探测目录”里所有候选都显示 `.ncm=0`。已修复：加入该路径、扫描深度改为 4，并允许旧的空默认目录自动迁移到有 NCM 的候选目录。

以下为修复前的原始观察，保留备查：

- 全盘 `find /sdcard -type f -iname '*.ncm'` 无结果；`/sdcard/CloudMusic` 原本不存在（测试用的目录是后来创建的）。
- 网易云把播放/下载缓存写到：
  `Android/data/com.netease.cloudmusic/files/Cache/Music3/<分片>/<id>_<bitrate>_<hash>.nmsf`
  并配 `.nmsfi` / `.config`。
- 最新一个 `.nmsfi` 样例：
  ```json
  {"file_id":"864433778_...","file_size":7217233,"file_slice_size":314572800,
   "slices":[{"offset":0,"size":7217233,"trunks":[{"offset":0,"size":320000}]}]}
  ```
  对应 `.nmsf` 实际只有 320000 字节，是流式/分片缓存，不是完整 NCM 容器。
- 播放器菜单显示“已下载”，但共享存储没有出现 `.ncm`；`cache/Cache/Download` 为空。
- 网易云 targetSdk 33，数据目录在 `Android/data`；即使 App 有 `MANAGE_EXTERNAL_STORAGE`，Android 11+ 也**不能**读取其他 App 的 `Android/data`。

结论：这台设备的网易云“下载”确实产生共享存储 `.ncm`；此前是**监听目录配置错误**，不是没有 NCM。
修复后已经实际批量解密该目录 27 个 `.ncm`（5.1–12.9 MB，共 230 MB 源文件，输出 212 MB MP3），全部 `TASK_SUCCESS`。
最终构建又把 27 个文件在会话开始后约 8 秒内全部入队，新增真实 NCM 副本触发 `CLOSE_WRITE` 后约 3 秒入队并成功解密，说明批量检测和单文件增量路径都正常。
“下载完成”的实时事件仍未在网易云实际下载过程中抓取（这批文件是在 App 修复前已下载完成的），
但初始扫描、真实 NCM 解析和批量解密已经验证；暂停/恢复/取消仍需后续实测。

App 的监听流程另外用 adb push 模拟“另一个 App 写入”验证了 CREATE/MODIFY/CLOSE_WRITE/ATTRIB。

## 2. 什么才算 ready？`CLOSE_WRITE` 够吗？

不够。`CLOSE_WRITE` 只说明某个写入句柄关闭；暂停下载、分段写入、重命名前后都可能出现。

App 的判定：

1. 只把 FileObserver 事件当作“候选发现”。
2. 候选文件大小/mtime 必须稳定：
   - 普通事件 8 秒；
   - `CLOSE_WRITE` / `MOVED_TO` 视为强信号，3 秒。
3. 稳定后还要通过 Rust 的完整验证：
   - MP3：逐帧扫描到逻辑 EOF，拒绝帧中间截断；完整解码并检查 declared/decoded 样本数。
   - FLAC：解析 STREAMINFO `total_samples`，完整解码后必须与解码样本数一致。
   - 解码时长与 NCM 元数据时长差 ≤ 500 ms（捕捉在帧边界被切掉的文件）。
4. 只有验证通过才发布正式文件名；失败会删除临时音频并重试，最多 5 次（同一指纹）。
5. 发布依赖 SAF provider 支持 `renameDocument`。不支持重命名时**拒绝发布**并删除临时文档，而不是直接写最终文件名；这样进程中断不会留下半成品正式文件。

实测 adb push 的事件序列：
`CREATE` → 多次 `MODIFY` → `CLOSE_WRITE` → `ATTRIB`。
- `CLOSE_WRITE` 时文件已经 492914 字节；
- 4.0 秒后入队，约 0.2 秒完成解密/验证；
- 说明“强信号 + 稳定窗口 + 完整验证”可用。

## 3. 解密库会不会接受截断文件？

**会。** `ncmc_lib` 的 `Read` 只是按块 XOR，`std::io::copy` 到 EOF 就返回成功；它不知道 NCM 音频应有长度。

主机实验（合成 MP3、FLAC，各 20 秒）：

| 截断比例 | 裸 ncmc_lib/初版验证 | App 最终验证 |
|---|---|---|
| 50% | 拒绝（时长明显短） | 拒绝 INCOMPLETE |
| 90% | 拒绝 | 拒绝 INCOMPLETE |
| 99% | 初版 2000ms 容差会接受 | 拒绝（MP3 帧中间 / FLAC 样本数不足） |
| 99.9% | 初版会接受 | 拒绝（MP3 帧中间 / FLAC 样本数不足） |

截断 99.9% 的 MP3 报错示例：
`MP3 stream ends inside a frame at byte 480965: frame needs 627 bytes, only 145 remain`
FLAC 示例：
`FLAC decoded 880128 samples but STREAMINFO declares 882000; file is truncated`

因此“Rust 返回 OK”不能作为下载完整的证明；App 以完整解码 + 声明样本数 + 结构检查为准。

## 4. 跨 App 文件事件可靠吗？

在 Redmi K Pad / Android 16 上，App 获得 `MANAGE_EXTERNAL_STORAGE` 后，**adb shell 写入**触发并收到了：

- `CREATE`
- `MODIFY`（多次）
- `CLOSE_WRITE`
- `ATTRIB`

事件包含完整路径、当时的大小和 mtime，说明跨 UID 的 FileObserver 在该设备/该目录可用。

限制：

- 没有用网易云真实 `.ncm` 验证（本机不产生 `.ncm`）。
- 其他 ROM/FUSE 实现可能不同；App 仍保留 30 秒周期补扫，避免完全依赖事件。
- 递归目录只监听启动时已有目录；运行中新建目录会在 1.5 秒后补挂观察器，深度上限 5，观察器上限 300。

## 5. 锁屏后发生什么？

**前台服务本身不保证 CPU 持续运行。** 测试中仅靠 FGS 时，屏幕关闭后 readiness Handler 明显延迟，文件在唤醒前没有及时处理。

修复：整个限时会话持有 `PARTIAL_WAKE_LOCK`（`NcmDecode:session`，最长 6 小时），停止/到期时释放。

实测：
- 14:10:34 开始 5 分钟会话，确认 `NcmDecode:session` 被持有；
- 14:11:19 push 文件，屏幕处于 `Asleep`；
- 14:12:39 入队并成功输出（约 80 秒延迟），输出 `... (7).flac`；
- 该次默认电池策略为“受系统优化”，且队列中还有旧候选，延迟包含排队时间。

之后把 App 加入 Doze 白名单（`cmd deviceidle whitelist +dev.ensomi.ncmdecode`），但没有得到干净的单文件延迟数据。  
结论：锁屏处理**可以发生**，但在这台 HyperOS 设备上实时性不作保证；建议用户把 App 设为“不受限制”，并接受最长约 1 分钟的发现/处理延迟。没有做“仅转换期间持有唤醒锁”的方案，因为实测发现等待稳定窗口和到期定时器也需要 CPU。

## 6. 外部触发实际由哪个 App 发起？

验证方式：

- `adb shell am start -a android.intent.action.VIEW -d "ncmdecode://watch/start?minutes=10"`：Activity 进入前台，服务启动；已有会话时日志为 `MERGE`，剩余时间不重置。
- `adb shell am start -n dev.ensomi.ncmdecode/.MainActivity -a dev.ensomi.ncmdecode.action.START_WATCH --ei minutes 5`：同样进入并合并。
- `minutes=0`：`EXTERNAL_INVALID`，不启动。
- 按返回键回到之前的前台 App（测试时回到浏览器/其它 App），说明入口不会强行停留。
- 首次未授权/未配置目录时，入口只显示待完成事项，不会由后台绕过授权直接启动。

另提供了 `trigger` 测试 App 源码与 APK；由于 HyperOS 对**新包**的 ADB 安装限制，本次没有把它安装到真机（主 App 的更新安装已成功）。实际验证使用了 adb shell 这一自动化工具。触发 App 的 Intent 形式与上面完全一致。

## 7. 其他已验证/未验证

已验证：

- 手动 MP3/FLAC 成功，输出可被 ffprobe 识别：MP3 20.04s / 192kbps，FLAC 20.00s。
- 撤销“所有文件访问”后，手动模式仍可通过 SAF 解密成功。
- 输出重名自动 `(1)`…`(7)`。
- 1 分钟会话初始扫描 2 个文件，到期自动退出。
- 延长 30 分钟：App 内按钮和通知按钮均生效。
- 停止：通知按钮生效，清理缓存/SAF 临时文件，服务退出。
- 重复触发合并，不新建服务。
- 临时文件清理：启动时删除遗留 `ncmdecode-svc-tmp-*.part`（实测 `saf=1`）。
- 同一路径内容变化：以 size+mtime+首尾 64KB SHA-256 识别；变化后重新处理。
- 超过 5 次失败的同一指纹：`SKIP_GAVE_UP`，不再反复解密。
- App 更新后 MIUI 会重置通知权限；UI 会显示未开启并阻止监听启动，需要重新授权。

未验证/不保证：

- 网易云真实 `.ncm` 下载（本机版本不产生）。
- 存储真正写满时的行为（代码检查缓存空间并捕获写入异常，但未实测）。
- SAF 授权被系统/用户中途撤销（代码会报 `OUTPUT_AUTH` 并结束会话，未实测）。
- 下载暂停后继续、取消、下载中途删除的真实网易云行为（用 adb push/截断文件模拟了部分）。
- 不同品牌 ROM 的锁屏/后台限制。
- 通知在其它 ROM 的展开方式（本机 HyperOS 需长按）。

## 8. 前台服务类型

- Manifest：`specialUse|mediaProcessing`，并声明对应权限与 `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`。
- Android 16 实际启动后 `dumpsys` 只显示 `types=0x40000000`（specialUse）。
- 尝试在会话中切换到 `mediaProcessing`（0x2000）被系统拒绝：
  `InvalidForegroundServiceTypeException: Starting FGS with type none ... has been prohibited`。
- 因此最终版本不在任务中切换类型，整个限时会话以 `specialUse` 运行；这不免除前台服务类型要求，类型已在 manifest 声明。若后续要严格按“处理时 mediaProcessing”运行，需要把监听与处理拆成两个服务并验证系统是否允许后台启动第二个 FGS。

## 9. 其他限制

- 输出不写标签，只保留原始 MP3/FLAC 音频帧。
- NCM 容器没有音频总长度字段；验证依赖完整解码和容器声明，无法对“恰好切在帧边界且元数据时长也被篡改”的恶意文件作绝对保证。
- 会话单次 1–180 分钟，延长上限为开始后 6 小时。
- 不做开机启动、常驻、被杀自动拉起；进程被杀后需手动再启动，启动时会重新扫描并跳过已成功指纹。
- 手动模式通过系统文件选择器读取 URI，复制到缓存后交给 Rust，不把 URI 当路径。
- 输出目录为空/不可写/授权失效时不会开始监听。
