# 真机测试记录

测试开始：2026-11-02 11:09（Asia/Shanghai）  
测试设备：Xiaomi Redmi K Pad，型号 25079RPDCC  
系统：Android 16 / API 36，安全补丁 2026-08-01，arm64-v8a  
网易云音乐：9.6.15（versionCode 9006015，targetSdk 33），已登录  
App：NCM Decode 0.1.0（§10 为 0.2.0 的 FLAC→MP3 验证），release，arm64-v8a，debug key 签名  
安装方式：浏览器下载 APK 后由 HyperOS 包安装器安装；后续更新用 `adb install -r` 成功

> 说明：§1–§9 记录 0.1.0 的行为；0.2.0 起 FLAC 输出自动转 MP3 320 kbps，见 §10。
>
> 21:15–21:16 网易云实际下载了 27 个 `.ncm`，位于 `/sdcard/Download/netease/cloudmusic/Music/`（230 MB）。App 早先监听默认的 `/sdcard/CloudMusic/Music`，所以“探测不到”；修复候选路径和自动迁移后，已完整批量解密这 27 个真实文件。合成 NCM 仍用于截断/FLAC/异常路径测试。

## 1. 目录与权限

| 项目 | 结果 |
|---|---|
| `MANAGE_EXTERNAL_STORAGE` | `cmd appops set ... MANAGE_EXTERNAL_STORAGE allow` 成功，App 显示“已授权” |
| 网易云数据目录 | `/sdcard/Android/data/com.netease.cloudmusic/` 可被 shell 列出，但 App 的 MANAGE 权限不能读其他 App 的 `Android/data` |
| 网易云缓存 | `files/Cache/Music3/.../*.nmsf`、`.nmsfi`、`.config` |
| 网易云实际 `.ncm` 目录 | `/sdcard/Download/netease/cloudmusic/Music/`，27 个文件，230 MB |
| 旧默认目录 | `/sdcard/CloudMusic/Music/`，0 个 `.ncm`（App 原先监听这里） |
| 修复后配置 | 自动迁移到 `Download/netease/cloudmusic/Music`，日志 `oldNcm=0 newNcm=27` |
| 输出目录 | `/sdcard/NcmOut` |
| 写测试 | App 的 `DirProbe` 在监听目录创建/删除测试文件成功（日志 `DIR_ACCESS read=true write=写入成功`） |
| 通知权限 | MIUI 在 App 更新后会重置；UI 正确显示“未开启”，重新系统授权后可用 |

## 2. Rust / JNI

- 构建：`aarch64-linux-android`，NDK 28.2.13676358，`libncm_jni.so` 1,510,544 字节。
- ELF：AArch64，`LOAD` 对齐 `0x4000`（16 KB）。
- 放入 release APK：`lib/arm64-v8a/libncm_jni.so`，`zipalign -c -P 16` 通过。
- JNI 在真机调用成功：手动 MP3、FLAC 均返回 `ok=true`，输出可播放。

主机截断实验（合成音频，20 秒）：

| 文件 | 结果 |
|---|---|
| 完整 MP3 | OK，decoded 882000 = declared 882000 |
| 完整 FLAC | OK，882000 = 882000 |
| MP3 截断 50/90/99/99.9% | 全部 INCOMPLETE（帧中间截断） |
| FLAC 截断 50/90/99/99.9% | 全部 INCOMPLETE（样本数不足） |

## 3. 解密验证（手动 + 批量）

| 用例 | 结果 |
|---|---|
| 选择合成 MP3 NCM | 成功，输出 `NCM Decode Test - Synthetic Stereo Test.mp3`，481,592 B，20.04s/192kbps（ffprobe） |
| 选择合成 FLAC NCM | 成功，输出 `...flac`，492,189 B，20.00s FLAC（ffprobe） |
| 撤销所有文件访问后手动 FLAC | 成功，输出 `... (4).flac`；证明手动模式只依赖 SAF，不依赖 MANAGE |
| 同名输出 | 自动 `(1)`…`(7)`，无覆盖 |
| 文件选择器 | HyperOS“安全访问”选择器可浏览到 `CloudMusic/Music` / `Download/netease/cloudmusic/Music` 并选中 `.ncm` |
| 输出位置 | `NcmOut`，App 显示成功、格式、时长、大小、位置 |

截图：[手动 MP3 成功](images/manual-mp3.png)、[撤销所有文件访问后手动成功](images/manual-no-all-files.png)。

### 3.1 真实网易云 NCM 批量（监听模式）

21:47:06 开始 2 分钟会话，监听修复后的真实目录：

- `SCAN_INITIAL found=27`，21:47:15–21:48:07 逐首 `TASK_SUCCESS`。
- 输出 27 个 MP3，共 212 MB；示例 `王力宏 - 大城小爱(Live).mp3` 8,902,574 B，ffprobe：3:42.54 / 320 kbps。
- 无 `TASK_FAIL`、无 `DECRYPT_FAIL`。
- 其中一个文件耗时约 2 秒，27 个文件在约 52 秒内完成。

### 3.2 0.1.0 最终构建回归（监听模式，21:57）

- 安装重新构建的 APK（`1874b2ef…`），通知/所有文件访问权限保留。
- 21:57:18 启动 2 分钟会话：`SCAN_INITIAL found=27 elapsedMs=7`；8 秒后 27 个 `CANDIDATE_QUEUE` 在约 40 ms 内全部入队（批量填充生效，不再每 2 秒只启动一首）。
- 27 个文件指纹与成功记录一致，全部 `SKIP_DONE`，没有重复解密。
- 21:57:37 把一个真实 NCM 复制进监听目录：`CLOSE_WRITE` 标记 `strong=true`，3 秒稳定后入队，约 1 秒完成 `DECRYPT_OK`，输出 `王力宏 - 大城小爱(Live) (1).mp3`（与已有同名文件自动加序号）。
- 删除测试副本和重复输出后，21:59:18 到期：`SESSION_EXPIRE queued=0 processing=false`，随即 `SERVICE_STOP`，无残留前台服务。
- 探测深度改为 4 后，`Download/netease/cloudmusic/Music` 下 27 个 `.ncm` 全部被初始扫描发现。

## 4. 监听会话

### 4.1 初始扫描与到期

- 12:01:59 开始首次 1 分钟会话；初始扫描后成功解密 MP3、FLAC，截断文件失败；通知显示“剩余 00:44 · 已解密 2 · 队列 0”，到期退出。
- 13:42 左右又以 2 分钟会话复跑；初始扫描发现 3 个合成文件（MP3/FLAC/截断），成功文件生成 `(1)` 副本。
- 两次到期后服务均退出，UI 回到“未监听”。

### 4.2 实时 FileObserver（adb push）

- 13:11:26 推送 `LivePush_FLAC.ncm`；14:xx 的多次测试同样。
- 事件日志（节选）：
  ```
  CREATE   size=262144
  MODIFY   size=492914
  MODIFY   size=492914
  CLOSE_WRITE size=492914
  ATTRIB   size=492914
  ```
- `CLOSE_WRITE` 被标记 `strong=true`；4.0 秒后 `CANDIDATE_QUEUE`，随后 `DECRYPT_BEGIN` → `DECRYPT_OK`。
- 输出 `NCM Decode Test - Synthetic Stereo Test (2).flac`。
- 说明跨 UID FileObserver 在该设备可用；仍有 30 秒补扫兜底。

### 4.3 重复触发合并

- 会话剩余 32:31 时执行 10 分钟深链接。
- 日志：`EXTERNAL_TRIGGER minutes=10` → `MERGE "重复开始被合并，剩余 32:31"`。
- 没有启动第二个服务；剩余时间不被重复触发重置。

### 4.4 延长

- App 内按钮：日志 `SESSION_EXTEND newEndRemaining=33:13`。
- 通知按钮（长按展开）：日志 `SESSION_EXTEND newEndRemaining=30:53`。
- 通知文案从 00:19 变为剩余 30:29。
- 截图：[通知操作](images/notification-actions.png)。

### 4.5 停止

- 通知“停止”按钮：`SESSION_STOP userStop droppedQueued=0 processing=false` → `CLEANUP cache=0 saf=0` → `SERVICE_STOP`。
- 服务从 `dumpsys activity services` 消失。
- `start` 时清理了预置的 `ncmdecode-svc-tmp-fake.part`（`CLEANUP_STALE saf=1`）。

### 4.6 到期

- 1 分钟会话到点后 `SESSION_EXPIRE`，未入队候选丢弃，队列完成后 `CLEANUP`/`SERVICE_STOP`。
- 5 分钟会话到点同样退出；UI 回到未监听。

## 5. 外部触发

| 方式 | 结果 |
|---|---|
| 深链接 `ncmdecode://watch/start?minutes=10` | Activity 前台，`EXTERNAL_TRIGGER`，会话启动/合并，返回键可回原 App |
| 深链接 `...minutes=0` | `EXTERNAL_INVALID`，不启动 |
| 显式 Intent `dev.ensomi.ncmdecode.action.START_WATCH` + `minutes=5` | 成功；会话活跃时 `MERGE` |
| 首次未授权 | 顶部提示需完成授权/目录，后台不会绕过 |
| 测试 App | `trigger` 源码/APK 已构建；HyperOS 对新包 ADB 安装限制，未安装到本机；实际用 adb shell 自动化验证 |

## 6. 锁屏

测试方法：开始 5 分钟会话 → 确认 `PARTIAL_WAKE_LOCK 'NcmDecode:session'` → 电源键锁屏（`mWakefulness=Asleep`）→ adb push `LockTest4.ncm`。

结果：

- FileObserver 在锁屏状态收到 `MODIFY/CLOSE_WRITE/ATTRIB`。
- 文件最终成功输出 `... (7).flac`。
- 但发现/入队延迟约 80 秒（14:11:19 push，14:12:39 queue），不是屏幕点亮时的 4 秒级。
- 期间队列里还有旧候选，延迟包含排队时间；仍说明锁屏实时性有限。
- 电池策略为默认“受系统优化”；加入 Doze 白名单后没有取得干净的单文件数据。
- 结论：锁屏可处理，但不保证及时；建议“不受限制”，不承诺固定延迟。

## 7. 终止/恢复与半成品

- 处理记录持久化在 `files/watch_state.json`；成功指纹 = size + mtime + 首尾 64 KiB SHA-256。
- 重启 App 后初始扫描对已完成文件输出 `SKIP_DONE same fingerprint already processed`。
- 同一路径内容变化（size/mtime 改变）会重新成为候选。
- 同一指纹连续失败 5 次后不再解密；后续扫描输出 `SKIP_GAVE_UP`。
- 服务启动/停止时清理 `ncmdecode-svc-tmp-*.part`；输出先写 SAF 临时文档，成功后才重命名。
- 未观察到一个半成品被当作正式 `.mp3/.flac` 发布。

## 8. 未覆盖/未通过实测

- 网易云真实 `.ncm` 的实时写完信号、暂停、恢复、取消、下载中删除（这批 27 个文件在修复前已完成下载；尚未在下载过程中抓包）。
- 存储真正耗尽。
- SAF 授权中途被撤销。
- 不同 ROM 的通知展开/锁屏策略。
- 新包 `trigger` 在 HyperOS 上的 ADB 安装。

## 9. 结论

- 手动模式、Rust 解密/验证、SAF 输出、跨 App 事件发现、限时队列、到期/延长/停止、重复触发合并、外部深链接/显式 Intent 均已在真机跑通。
- 对截断文件，裸库会接受；App 的验证层能拒绝 99.9% 截断（合成 MP3/FLAC）。
- 真实网易云 `.ncm` 已确认存在并完成 27 文件批量解密；此前“检测不到”是监听目录配置错误。
- 仍需在网易云**正在下载**时验证 CLOSE_WRITE/暂停/取消等实时行为，不能把“能解密已完成文件”等同于“能及时识别任意下载状态”。

## 10. FLAC → MP3 320 kbps（2026-11-02 23:18 – 11-03 00:06）

> 本节之后，§3 中“合成 FLAC NCM → 输出 `.flac`”描述的是加转码之前的行为；现在 FLAC 默认输出 `.mp3`。
> 详细设计与逐项数据见 [flac-to-mp3-profile.md](flac-to-mp3-profile.md)。

| 用例 | 结果 |
|---|---|
| 监听路径，合成 FLAC NCM（20 s） | 输出 `… Twenty Sec Flac.mp3` 802,480 B（320 kbps）；`TRANSCODE_PROFILE` 一条；无 `.flac` |
| 监听路径，合成 FLAC NCM（4 min，30 MB）×3 | 每次输出 9,602,611 B MP3；`transcodeMs` 1917/1917/1916，`wallMs` 2490/2486/2485，任务总计 2.62–2.64 s；9,190 帧全部 320 kbps 44.1 kHz，时长 240.000→240.065 s |
| 手动路径，合成 FLAC NCM | `MANUAL_OK`，输出 `… Twenty Sec Flac (1).mp3`（同名 ` (1)` 语义保留），UI 显示 MP3/0:20/783.7 KB |
| MP3 NCM（手动与监听） | 输出 `.mp3` 481,592 B，无 `TRANSCODE_PROFILE`，`source=mp3`，行为与之前一致 |
| 回退：22,050 Hz FLAC（无法 320 kbps MPEG-1） | `TRANSCODE_FALLBACK code=TRANSCODE_UNSUPPORTED_RATE`，发布 `.flac` 287,939 B，`TASK_SUCCESS` |
| 96 kHz 立体声 FLAC | `sr=96000->48000 resampled=true`，输出 48 kHz/立体声 320 kbps，时长 20.06 s |
| 0.2.0 最终包独立回归（versionCode 2） | 放入真实 FLAC NCM：`TRANSCODE_PROFILE` 一条，输出 `… Twenty Sec Flac.mp3` 802,480 B，`source=flac`；`/sdcard/NcmOut` 无 `.flac`。随后把 28 个真实 NCM 复制到临时子目录重跑，全部 `TASK_SUCCESS`，输出 28 个 MP3（其中一个因同曲双路径并发产生 ` (1)`，已删除重复），临时子目录已清理 |
| 44.1 kHz 单声道 FLAC | `ch=1`，输出 44.1 kHz/**mono** 320 kbps，时长 20.06 s |
| 回退：临时注入编码器失败（验证后已还原，最终 APK 不含该分支） | `TRANSCODE_FALLBACK code=TRANSCODE_TEST_FORCED`，发布 `.flac` 492,189 B，`TASK_SUCCESS` |
| 临时文件 | 每次会话开始 `CLEANUP_STALE cache=0 saf=0`；输出目录只有 `.mp3`（或回退时只有 `.flac`），无 `.part` |
| 编码器探测 | `TRANSCODE_ENCODER encoder=lame-3.100 mediaCodecMp3=false`（本机无 MediaCodec `audio/mpeg` 编码器） |
| 输出校验 | `ffmpeg -i` 解码无错误；帧头解析 9,190 帧全部 320 kbps；无 ID3v1/ID3v2/APE 标签 |
| 体积 | APK 3,816,896 → 4,064,744 B（+247,848 B）；APK 内 `.so` 997,624 → 1,245,472 B |

