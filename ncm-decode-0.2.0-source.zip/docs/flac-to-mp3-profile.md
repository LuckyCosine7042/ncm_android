# FLAC → MP3 320 kbps：设计、优化与真机剖析

测试设备：Redmi K Pad 25079RPDCC（`turner`），Android 16 / API 36，arm64-v8a，序列号 `7LOFU4X4KRKB5DKJ`。
App：`dev.ensomi.ncmdecode` 0.1.0（行为同 0.2.0，最终包仅版本号变更），release（debug key），`adb install -r` 覆盖安装，权限/目录配置保留。
测试时间：2026-11-02 23:18 – 11-03 00:06（Asia/Shanghai）。设备空闲：无监听会话、无其他解密任务，电量 100%，电池温度 25.1 ℃。

> 测试素材是**合成** FLAC（粉红/布朗噪声，非真实网易云 FLAC NCM）。合成素材只影响“像不像音乐”，
> 不影响解码/编码的每样本工作量，因此时间与吞吐数字仍具代表性；FLAC 体积按 30 MB / 4 分钟做了
> 接近真实 44.1 kHz 无损的水平（1000 kbps）。

## 1. 设计

| 项目 | 选择 | 理由 |
|---|---|---|
| 编码器 | 随包 LAME 3.100（libmp3lame 编码子集，静态链接进 `libncm_jni.so`） | AOSP 不提供 `audio/mpeg` MediaCodec 编码器；本机实测 `mediaCodecMp3=false`（见 `TRANSCODE_ENCODER` 日志）。厂商实现是否存在/可用不可控，跨设备兼容只能自带编码器 |
| 转码位置 | Rust/JNI 内部，`decrypt` 调用里完成 | FLAC 解码与“下载是否完整”的校验是同一次解码，省掉一次完整解码；编码器与解码器同进程、无 PCM 落盘、无二次拷贝 |
| 解码 | symphonia FLAC（已 vendored，原本就用于校验） | 不新增解码依赖 |
| 封装 | 输出 MP3 与 FLAC 临时文件同目录，成功后删除 FLAC | 回退时无需重新解密，直接发布现成 FLAC |
| 发布 | 仍走原 `SafOutput`（临时文档 + rename） | 保留“半成品永不出现”的语义；未改成直接写 SAF fd（收益 ~5%，风险高，见 §6） |

失败语义（`ncm_jni/src/transcode.rs` 的 `TranscodeErrorKind`）：

* `Audio`：FLAC 本身截断/损坏（解码错误、样本数与 STREAMINFO 不符、被取消）→ 任务失败，**不发布任何文件**，与旧行为一致。
* `Encoder`：源音频正常但编码不可用（采样率/声道不支持、`lame_init`/`lame_init_params`/编码失败、输出未通过 MP3 完整解码校验）→ 重新对 FLAC 做完整解码校验后发布 `.flac`，日志 `TRANSCODE_FALLBACK`，任务成功。

## 2. 代码路径

```
NcmProcessor.decryptAndPublish
  └─ NativeNcm.decryptTo  (JNI, 一次调用完成下面全部)
       ├─ NCM 解密 → cache/…/audio.tmp          (FLAC 时不 fsync：同一进程马上读回)
       ├─ detect_format
       ├─ transcode_flac_to_mp3  (symphonia 流式解码 → LAME → cache/…/transcoded.mp3)
       │    ├─ 解码样本数 == STREAMINFO total_samples（完整性证明，替代旧校验解码）
       │    ├─ 写完后 patch Xing/Info 帧（帧数/TOC）
       │    └─ 失败时区分 Audio / Encoder
       ├─ validate_audio(mp3)：帧头遍历 + 完整解码 + 样本数校验（发布前保证）
       └─ 成功则删除 FLAC，返回 outputPath / format / transcode 指标
  └─ SafOutput.publish(outputPath, format)
```

关键文件：

* `ncm_jni/build.rs` — 用 Gradle 已导出的 `CC_aarch64_linux_android` / `AR_aarch64_linux_android`（NDK clang，`cmd /C` 包装）编译 `third_party/lame/libmp3lame/*.c` 成 `libmp3lame.a`，`cargo:rustc-link-lib=static=mp3lame`。宿主（非 Android）目标跳过 LAME，转码返回 `Encoder` 错误 → 回退发布 FLAC，`cargo test`/`ncmcheck` 仍可用。
* `ncm_jni/src/lame.rs` — 最小 FFI + `Encoder`（`lame_set_brate(320)`、`lame_set_VBR(vbr_off)`、默认 psychoacoustic quality，未改）。
* `ncm_jni/src/transcode.rs`, `transcode/android.rs` — 流式转码实现。
* `ncm_jni/src/lib.rs` — `prepare_publish`：MP3 NCM 走原路径；FLAC 走转码/回退；`decrypt` 返回 `outputPath`、`format`、`sourceFormat`、`transcode{…}`、`transcodeFallback`。
* `app/…/NcmProcessor.kt` — 按 `outputPath` 发布；记录 `TRANSCODE_PROFILE` / `TRANSCODE_FALLBACK`。
* `app/…/TranscodeDiag.kt` — 剖析与编码器探测日志（`Debug.threadCpuTimeNanos`、`/proc/self/status VmHWM`、`MediaCodecList`）。
* `ncm_jni/src/bin/ncmtranscode.rs` — 真机可复现的剖析工具（`--naive` 为基线实现）。

## 3. 基线 vs 优化

基线（`ncmtranscode --naive`，同一份 4 分钟 FLAC）：整文件读入内存 → 全部 PCM 累积到内存 →
每 1152 样本调用一次编码器 → 每次 `write_all` 不缓冲 → 另外先做一次旧管线的完整 FLAC 校验解码。
优化版（App 与 `ncmtranscode` 默认路径）：256 KiB 读缓冲流式解码、复用 `SampleBuffer<i16>`、
按解码包（4096 样本）喂编码器、1 MiB `BufWriter`、省掉重复校验解码、FLAC 不 fsync。

同一文件 3 次，设备串行执行（`/data/local/tmp/ncmtranscode`）：

| 指标（240.0 s / 44.1 kHz / 立体声 / 30,004,812 B FLAC） | 基线 naive | 优化后 | 变化 |
|---|---|---|---|
| 墙钟总计（含额外 FLAC 校验解码） | 2269 / 2267 / 2265 ms | 1973 / 1967 / 1968 ms | −13.3 % |
| CPU 时间（进程 utime+stime） | 2260 / 2240 / 2260 ms | 1960 / 1960 / 1950 ms | −13.5 % |
| FLAC 解码 | 280 / 281 / 282 ms | 214 / 214 / 213 ms | −24 % |
| LAME 编码 | 1738 / 1740 / 1739 ms | 1722 / 1718 / 1720 ms | ≈0（同一编码器设置） |
| 额外 FLAC 校验解码（旧管线） | 230 / 226 / 224 ms | 0（由转码解码承担） | −100 % |
| 进程峰值 RSS（VmHWM） | 109,952 / 110,484 / 110,624 kB | 6,804 / 7,064 / 7,072 kB | −94 % |

App 真实路径（`TRANSCODE_PROFILE`，同一文件 3 次，监听服务）：

| 字段 | 3 次测量 |
|---|---|
| `wallMs`（整个 JNI 调用：解密+解码+编码+MP3 校验） | 2490 / 2486 / 2485 |
| `cpuMs`（`Debug.threadCpuTimeNanos`） | 2467 / 2463 / 2464 |
| `transcodeMs`（解码+编码+写盘） | 1918 / 1917 / 1917 |
| `decodeMs` / `encodeMs` / `validateMs`(MP3 完整解码) | 160 / 1716 / 427（第 1 次），161 / 1716 / 427，161 / 1716 / 426 |
| NCM 解密（wallMs − transcodeMs − validateMs） | ≈142 ms（30 MB NCM，≈211 MB/s） |
| SAF 发布（`DECRYPT_OK` − profile 时刻） | 149 / 133 / 148 ms（9.6 MB） |
| 任务总计（`DECRYPT_BEGIN` → `TASK_SUCCESS`） | 2642 / 2623 / 2638 ms |

吞吐与正确性（优化版，4 分钟文件）：

| 指标 | 值 |
|---|---|
| FLAC 输入吞吐 | 15.6 MB/s（30.0 MB / 1.917 s） |
| PCM 吞吐 | 22.1 MB/s（42.34 MB / 1.917 s） |
| 实时倍速（仅转码） | 125×（整任务 91×） |
| 输出大小 / 压缩比 | 9,602,611 B；0.320（MP3 为 FLAC 的 32 %） |
| 输出码率（帧头解析，无 ffprobe） | 9,190 帧全部 `bitrate_index=14` → 320 kbps，44.1 kHz，MPEG-1 Layer III；帧长 1044/1045 B，恰好覆盖文件 9,602,611 B |
| 时长保持 | 源 240.000 s → MP3 240.065 s（+65 ms，编码器 delay/padding，在 500 ms 容差内） |
| 采样率/声道 | 44100 → 44100，2 → 2（`resampled=false`） |
| 可解码性 | `ffmpeg -i out.mp3 -f null -` 无错误；`Duration 00:04:00.07, 320 kb/s, stereo` |
| 标签 | 无 ID3v2（首字节 `ff fb`）、无 ID3v1、无 APE tag |

短文件（20 s FLAC NCM，492,189 B）：`transcodeMs=147`（解码 13 + 编码 131）、`validateMs=35`、
`wallMs=194`、136× 实时、输出 802,480 B（320.99 kbps）。

采样率/声道矩阵（同一 20 s 素材，监听路径）：

| 源 | 结果 | 输出 |
|---|---|---|
| 44.1 kHz 立体声 | `sr=44100->44100 ch=2 resampled=false`，`transcodeMs=144` | `ffmpeg`: 44100 Hz, stereo, 320 kb/s, 20.06 s |
| 44.1 kHz 单声道 | `ch=1 resampled=false`，`transcodeMs=89`（224× 实时） | 44100 Hz, **mono**, 320 kb/s, 20.06 s |
| 96 kHz 立体声 | `sr=96000->48000 ch=2 resampled=true`，`transcodeMs=218` | **48000 Hz**, stereo, 320 kb/s, 20.06 s |
| 22.05 kHz 立体声 | 拒绝：320 kbps 属于 MPEG-1，22.05 kHz 只能 MPEG-2（≤160 kbps） | 回退发布 FLAC（`TRANSCODE_UNSUPPORTED_RATE`） |

### 方法学与注意事项

* 每轮都是独立进程内的一次完整转码；3 轮在同一进程里串行（`--iterations 3`），峰值 RSS 用
  `VmHWM`（单调），所以第 2/3 轮的 `rssDeltaKb` 只有几百 kB——绝对值才是峰值内存。
* App 路径的 `rssDeltaKb=0` 是因为进程峰值早已被前面任务抬高（256 MB），**不能**当作“转码不占内存”；
  独立进程的 6.8 MB 才是转码本身的峰值（解码块缓冲 + 2 个 I/O 缓冲）。
* CPU 时间：剖析工具取 `/proc/self/stat`（10 ms 粒度）；App 取 `Debug.threadCpuTimeNanos`（同一工作线程）。
* 编码占转码时间的 ~89 %，且按要求未改编码质量/码率/线程模型，因此优化上限就是省掉重复解码、
  减少分配与拷贝：总计 −13 %、峰值内存 −94 %。
* 温度/调度未锁定（未 root），重复测量的波动约 ±1 %（上表 3 次即可看出）。
* 文件系统页缓存已热（NCM/FLAC 刚写入或刚 push），冷缓存下解密与读取会略慢。

## 4. APK 与原生库体积

| 项目 | 之前 | 之后 | 增量 |
|---|---|---|---|
| `app-release.apk` | 3,816,896 B | 4,064,744 B | +247,848 B（+6.5 %） |
| APK 内 `lib/arm64-v8a/libncm_jni.so` | 997,624 B | 1,245,472 B | +247,848 B |
| 构建产物 `libncm_jni.so`（未再 strip） | 1,637,992 B | 1,941,248 B | +303,256 B |

只有 arm64-v8a（`abiFilters` 未改）；LAME 以静态库链接进现有 `.so`，没有新增 `.so`。

## 5. 真机验证（日志与文件）

监听路径（`/sdcard/Download/netease/cloudmusic/Music` → `/sdcard/NcmOut`），`adb logcat -s NcmDecode`：

```
event=TRANSCODE_ENCODER detail="encoder=lame-3.100 mediaCodecMp3=false note=MediaCodec audio/mpeg encoders are vendor-specific, LAME is bundled"
event=TRANSCODE_PROFILE size=30004812 detail="encoder=libmp3lame 3.100 in=30004812 out=9602611 ratio=0.320 wallMs=2485 cpuMs=2464 rssStartKb=256272 rssPeakKb=256272 rssDeltaKb=0 sr=44100->44100 ch=2 kbps=320 frames=10584000 mp3Frames=9190 decodeMs=161 encodeMs=1716 transcodeMs=1917 validateMs=426 flacMBps=15.65 pcmMBps=22.08 realtime=125.20x resampled=false"
event=DECRYPT_OK … detail="output=NCM Decode Test - Profile Noise 240s (5).mp3 format=mp3 duration=240065ms source=flac"
event=TASK_SUCCESS … detail="output=NCM Decode Test - Profile Noise 240s (5).mp3 format=mp3 duration=240065ms"
```

MP3 NCM（不变路径，无 `TRANSCODE_PROFILE`）：

```
event=DECRYPT_OK … detail="output=NCM Decode Test - Synthetic Stereo Test (1).mp3 format=mp3 duration=20000ms source=mp3"
```

回退（两种，均发布 `.flac` 且任务成功）：

```
# 真实不可编码采样率：22050 Hz 无法承载 320 kbps MPEG-1
event=TRANSCODE_FALLBACK … detail="code=TRANSCODE_UNSUPPORTED_RATE stage=encode message=22050 Hz cannot be encoded as 320 kbps MPEG-1 audio publishing=flac"
event=DECRYPT_OK … detail="output=NCM Decode Test - Low Rate Flac.flac format=flac duration=20000ms source=flac"
event=TASK_SUCCESS … detail="output=NCM Decode Test - Low Rate Flac.flac format=flac duration=20000ms"

# 临时注入的编码器失败构建（验证后已还原，最终 APK 中不存在该分支）
event=TRANSCODE_FALLBACK … detail="code=TRANSCODE_TEST_FORCED stage=encode message=forced encoder failure for fallback test publishing=flac"
event=DECRYPT_OK … detail="output=NCM Decode Test - Twenty Sec Flac.flac format=flac duration=20000ms source=flac"
event=TASK_SUCCESS … detail="output=NCM Decode Test - Twenty Sec Flac.flac format=flac duration=20000ms"
```

输出目录（每次会话后）：只有 `.mp3`（FLAC 成功时）或只有 `.flac`（回退时），无 `.tmp/.part` 残留；
会话开始时 `CLEANUP_STALE … detail="cache=0 saf=0"` 证明上一轮缓存工作目录已被清理（含临时 FLAC）。
手动路径同样走新逻辑：`MANUAL_OK … output=NCM Decode Test - Twenty Sec Flac (1).mp3`，UI 显示
“格式 MP3 · 时长 0:20 · 783.7 KB”。

## 6. 明确未做的优化

* **直接写 SAF 临时文档**：可省掉发布时对 9.6 MB 的一次拷贝（实测 133–149 ms，占任务 ~5 %），
  但需要把 `ParcelFileDescriptor` 传进 JNI、在同一个 fd 上完成写入与回读校验，并重做“失败即删临时
  文档”的路径；收益小、破坏现有发布语义的风险大，故保留原 `SafOutput`。
* 编码器质量/码率、并行编码、服务线程模型、其他 ABI：按要求不动。
* 输出 MP3 的完整解码校验保留（发布保证）；省掉的是**源 FLAC** 的重复解码。

## 7. 已知限制

* 只有 arm64-v8a（与现有 APK 一致）。
* LAME 3.100 为 LGPL-2.1；以静态库链接，见 `THIRD_PARTY_NOTICES.md`（再分发时需满足 LGPL 的
  源码/替换要求）。
* 320 kbps CBR 通常比 FLAC 小（本例 32 %），但低码率/安静素材可能变大（20 s 测试音 FLAC 196 kbps
  → MP3 320 kbps，比例 1.63）。
* 单/双声道以外、以及无法映射到 32/44.1/48 kHz 的采样率不转码，回退发布 FLAC。
* 不保留/不写入标签（元数据仅用于文件名），封面也不写入。
* 编码器 delay/padding 使时长比源多 ~65 ms/4 min（在容差内，播放器 gapless 信息由 Xing/LAME 帧提供）。

## 8. 复现

```powershell
# 1) 构建并安装
$env:JAVA_HOME='C:\Program Files\Java\jdk-21'
.\gradlew.bat assembleRelease
adb install -r app\build\outputs\apk\release\app-release.apk

# 2) 合成 4 分钟 FLAC 与 NCM（需要 pycryptodome；ffmpeg 可用 imageio-ffmpeg 的二进制）
#    testdata/audio/profile_4min.flac 已随工作区保留；重建命令：
#    ffmpeg -f lavfi -i "anoisesrc=color=pink:sample_rate=44100:amplitude=0.25:duration=240:seed=11" `
#           -f lavfi -i "anoisesrc=color=brown:sample_rate=44100:amplitude=0.25:duration=240:seed=29" `
#           -filter_complex "[0:a][1:a]amerge=inputs=2[aout]" -map "[aout]" -ac 2 -ar 44100 `
#           -c:a flac -sample_fmt s16 -y testdata\audio\profile_4min.flac
python tools\make_test_ncm.py --audio testdata\audio\profile_4min.flac `
  --out testdata\ncm\synth_flac_profile.ncm --format flac --duration-ms 240000 `
  --bitrate 1411200 --title "Profile Noise 240s" --artist "NCM Decode Test"

# 3) 设备上的纯转码剖析（优化版 / 基线）
cargo build --release --bin ncmtranscode --target aarch64-linux-android   # 由 Gradle 的 CC/AR 环境变量驱动
adb push ncm_jni\target\aarch64-linux-android\release\ncmtranscode /data/local/tmp/
adb shell "/data/local/tmp/ncmtranscode --iterations 3 /data/local/tmp/x.flac /data/local/tmp/x.mp3"
adb shell "/data/local/tmp/ncmtranscode --naive --iterations 3 /data/local/tmp/x.flac /data/local/tmp/x.mp3"

# 4) App 路径：把 NCM 放进监听目录，开一个短会话，读日志
adb logcat -c
adb shell am start -a android.intent.action.VIEW -d 'ncmdecode://watch/start?minutes=2' dev.ensomi.ncmdecode
adb logcat -d -s NcmDecode:I | Select-String "TRANSCODE_PROFILE|TRANSCODE_FALLBACK"
```

最终验证是在 `gradlew clean assembleRelease` 的干净构建上重新 `adb install -r` 后完成的：
FLAC 20 s → `.mp3`、MP3 NCM → `.mp3`（无 `TRANSCODE_PROFILE`）、22.05 kHz FLAC → `TRANSCODE_FALLBACK` 发布 `.flac`，
三条用例均 `TASK_SUCCESS`，输出目录无残留，会话到期后服务正常退出。
