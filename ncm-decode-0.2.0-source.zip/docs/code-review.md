# 代码审阅记录

审阅范围：`app/`、`ncm_jni/`、`third_party/ncmc_lib/`、Gradle 配置、manifest。
审阅方式：静态阅读 + 重新构建 + 真机冒烟（1 分钟监听、单文件 MP3 解密）。

结论：整体结构清晰，线程边界基本正确，SAF 临时文件/成功状态/截断验证思路可靠。发现并修复了一批高优先级问题；仍有若干中低风险项，主要集中在并发、主线程 I/O 和真实网易云行为未验证。

## 已修复的高优先级问题

### H1. `panic = "abort"` 让 JNI 的 `catch_unwind` 失效

位置：`ncm_jni/Cargo.toml` 的 release profile。

`ncmc_lib` 对恶意/损坏 NCM 的 key 数据没有全部防御（例如 key 明文只剩 `neteasecloudmusic` 17 字节时，KSA 会越界 panic）。JNI 层虽然用了 `catch_unwind`，但 `panic=abort` 下 panic 直接终止整个 App 进程，`catch_unwind` 不可能生效。

修复：改为 `panic = "unwind"`。代价是 `.so` 从约 1.51 MB 增至约 1.6 MB；换来损坏文件不会拖垮进程。

### H2. 服务与手动解密共用 `ncm-decrypt-*`，清理会误删正在处理的文件

位置：`NcmProcessor.kt`、`WatchService.kt`、`MainActivity.kt`。

服务启动/停止清理 `ncm-decrypt-*`，而手动解密的工作目录也是同一前缀。若用户监听中手动解密，或点“清理临时文件”，可能删掉另一个任务的 `audio.tmp`/工作目录，导致失败或半成品。

修复：

- 工作目录改为 `ncm-decrypt-svc-*` / `ncm-decrypt-man-*`。
- 服务只清理 `ncm-decrypt-svc-*`。
- 手动/服务进行中时，“清理临时文件”直接拒绝。
- 手动解密与服务监听互斥（监听中禁止手动，手动中不允许启动监听）。

### H3. SAF provider 不支持 rename 时，fallback 会把半成品写成正式文件

位置：`SafOutput.publish()`。

原实现 rename 失败后创建最终文件再复制，复制过程中进程被杀会留下一个正式的 `.mp3/.flac` 半成品，违反“成功后才发布正式文件名”。

修复：rename 失败时删除临时文档并抛 `IOException`，由上层返回 `PUBLISH`；不再写最终文件名。代价是不支持 `renameDocument` 的 provider 无法输出，需要在文档中说明。

### H4. 周期补扫每 30 秒重新入队所有已成功文件

位置：`WatchService.periodicScan()` / `onCandidate()` / `WatchStateStore.isSuccessAt()`。

成功记录只在处理时校验；补扫会把已成功文件重新加入候选，导致每 30 秒重新计算 SHA-256、入队、再 `SKIP_DONE`。文件多时浪费 CPU/电量，也让日志噪声很大。

修复：

- 增加 `isSuccessAt(path,size,mtime)` 的轻量扫描过滤；同一 size/mtime 的成功文件不再入队。
- 增加 `inFlight` 集合和队列检查，避免正在解密/已排队的路径被重复加入。
- 真正的 digest 校验仍保留在处理前，防止同大小但内容变化的文件漏判。

### H5. 外部触发 `minutes=abc` 被静默当成 30 分钟

位置：`MainActivity.handleIntent()`。

原逻辑 `rawMinutes?.toIntOrNull() ?: 30` 对非数字输入也回落默认值，违背“校验传入时长”。

修复：区分“未提供”（默认 30）与“提供了但不是整数/为空”（`EXTERNAL_INVALID`，不启动）。

### H6. Android 10 及以下 `hasAllFiles()` 误报

位置：`DirProbe.hasAllFiles()` / `WatchService.handleStart()`。

原实现 API < 30 直接返回 true，即使没有 READ/WRITE 运行时权限；深层链接直接启动服务时可能绕过 Activity 的检查。

修复：新增 `DirProbe.hasStorageAccess(context)`，API < 30 检查 READ+WRITE，服务使用该版本；API >= 30 仍检查 `Environment.isExternalStorageManager()`。

### H7. 到期时队列存在但 `processing=false` 可能不继续消费

位置：`WatchService.checkExpiry()`。

原代码只在 `!processing && queue.isEmpty()` 时 `finishAndStop()`；如果队列非空且没有 worker 在跑，队列会停滞。正常情况下入队会立即 drain，但这是不必要的状态漏洞。

修复：到期后若 `!processing`，队列非空则继续 `drainQueue()`，空才 `finishAndStop()`。

### H8. 通知更新从 worker 线程读写主线程状态

位置：`WatchService.processCandidate()`。

原代码在解密 worker 里直接改 `lastAction` 并调用 `updateNotification()`，而 `buildNotification()` 读取 `queue`、`processing`、`active` 等主线程字段。

修复：改为 `main.post { lastAction=...; updateNotification() }`；其他更新均在主线程。

## 仍存在的中等风险

### M1. 主线程上的目录扫描

`initialScan()` / `periodicScan()` 在 service 主线程调用 `DirProbe.ncmFiles()`（`File.walkTopDown`）。目录很大或 FUSE 卡顿时会阻塞 Handler、通知和到期检查。当前限制 500 个文件、深度 4，测试目录很小；建议把扫描移到 worker，结果再回主线程合并。

### M2. `refreshStatus()` 每秒查询 SAF

`MainActivity.refreshStatus()` 每秒调用 `SafOutput.canWrite()`，内部查询 `ContentResolver`。在慢 provider 上会造成 jank；可缓存 5–10 秒，或只在 Resume/操作后刷新。

### M3. 文件事件日志在主线程同步写文件

`WatchEventLog.log()` 每次 `FileOutputStream(...).use` 同步追加；`onFileEvent` 每个 NCM `MODIFY` 都写。真实大文件分块下载可能产生大量事件，造成主线程 I/O 压力。建议改为单线程异步 writer，或按路径/时间节流 `MODIFY` 日志（保留 `CLOSE_WRITE`/`MOVED_TO`）。

### M4. 服务和手动解密的全局取消标志仍可能互相影响

虽然已让 UI 互斥，但 `NativeNcm.cancelCurrent()` 是进程级 `AtomicBool`：

- 服务停止时如果手动解密正好持有 native 锁，取消标志可能终止手动任务；
- `decrypt_impl()` 开始时会清空标志，存在“取消早于 native 开始”的窗口。

当前通过 UI 互斥规避了常见路径，但底层没有 owner/token 机制。彻底修复需要把取消标志改为按任务 token，或在 Kotlin 层用同一把锁串行化 cancel 与 decrypt 的启动。

### M5. SAF 并发发布的重名竞态

`uniqueName()` 先查询已有名字，再创建/重命名；服务与手动已互斥，但两个外部触发或未来并发任务仍可能在查询与创建之间竞争。provider 可能自动改名，`Published.name` 与实际显示名可能不一致。建议对 `publish` 加进程内互斥，或 rename 后回查实际 display name。

### M6. 不恢复标签

输出只复制原始音频帧，不写 ID3/Vorbis 标签；这是第一版的有意限制，但用户可能期望歌名/封面。NCM 元数据已经解析出来（title/artist），MP3 可写 ID3，FLAC 需要 Vorbis comment，工作量另计。

### M7. 真实网易云“下载中”行为仍未验证

已确认网易云 9.6.15 真实 `.ncm` 目录为 `/storage/emulated/0/Download/netease/cloudmusic/Music`，并完成 27 个真实文件批量解密。此前检测失败是候选路径遗漏导致（已修复）。

仍缺少：

- 在网易云下载进行中抓取 CLOSE_WRITE/临时文件/重命名行为；
- 暂停、恢复、取消、下载中删除的真实网易云复现；
- 30 分钟完整锁屏会话（目前只有 5 分钟级和约 80 秒延迟的一次观察）。

详见 `docs/findings.md`。

### M8. 主线程锁屏/Doze 行为仍依赖厂商

整个会话持有 `PARTIAL_WAKE_LOCK` 6 小时上限，已比“只转换期间持有”更可靠；但 HyperOS 默认电池策略下仍观察到延迟。不要把“锁屏可处理”宣传成固定时限。

## 低风险/清理项

- `WatchService` 的 `Candidate.lastEventAt`、`firstSeenAt` 目前未参与判定，可删。
- `WatchService` 导入 `Environment`、`TimeUnit`、`AtomicBoolean` 未使用。
- `WatchStateStore.successCount()`、`NcmProcessor.resultFromJson()`、`DirProbe.hasAllFiles()` 目前无调用（`hasAllFiles` 仅保留兼容）。
- `periodicScan` 的 `added` 计数在 `onCandidate` 提前返回时仍加一，日志数字偏大。
- `README` 已说明 release 用 debug key 签名；公开分发前必须换私钥。

## 验证

- `assembleRelease` 成功（AGP 8.13.2 / Kotlin 2.1.21 / NDK 28.2）。
- 1 分钟真机监听复跑：`ReviewTest.ncm` 在 18:03:44 入队，18:03:52 输出 MP3，`TASK_SUCCESS`；补扫未再入队该文件。
- APK 重新签名/16 KB 对齐校验通过。
- Rust host test 仍通过；完整的 JNI malformed-file 测试尚未加入自动化用例。
