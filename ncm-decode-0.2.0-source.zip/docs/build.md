# 构建与验证

## 环境

本次实际使用：

- Windows 10.0.26300（x64）
- JDK 21（`C:\Program Files\Java\jdk-21`）
- Android SDK Platform 36、Build-Tools 36.0.0、NDK 28.2.13676358
- Gradle 8.13（项目自带 wrapper）
- Rust stable 1.99.1，targets：`aarch64-linux-android`，测试另加 `x86_64-linux-android`
- Android Gradle Plugin 8.13.2，Kotlin 2.1.21

## 安装依赖（概要）

```powershell
# Android SDK 安装后
sdkmanager "platform-tools" "platforms;android-36" "build-tools;36.0.0" "ndk;28.2.13676358"

# Rust
rustup target add aarch64-linux-android
```

`local.properties`：

```properties
sdk.dir=D\:\\path\\to\\android-sdk
```

`app/build.gradle.kts` 的 `buildRustArm64` 会用 NDK clang 编译 `ncm_jni`，并把 `libncm_jni.so` 复制到 `app/src/main/jniLibs/arm64-v8a/`。默认查找 `%USERPROFILE%\.cargo\bin\cargo.exe`，也可：

```powershell
.\gradlew.bat assembleRelease -PcargoPath="C:\Users\you\.cargo\bin\cargo.exe"
```

### LAME（FLAC → MP3）

`ncm_jni/build.rs` 在构建 Android 目标时，会把 `third_party/lame/libmp3lame` 里的 19 个编码器 C 文件
用 Gradle 已经导出的 `CC_aarch64_linux_android`（NDK 的 `aarch64-linux-android26-clang.cmd`，通过
`cmd /C` 调用）编译成 `libmp3lame.a`，再静态链接进 `libncm_jni.so`。不需要 CMake、autotools 或网络。

- 宿主目标（`cargo test` / `cargo build --bin ncmcheck`）不编译 LAME；此时转码返回
  `TRANSCODE_UNSUPPORTED_HOST`，解密走 FLAC 回退，主机侧测试行为不变。
- 需要重新生成源码包时，`third_party/lame` 原样保留即可；构建脚本只依赖该目录。
- 许可证（LGPL-2.1）与替换/重链接要求见 [THIRD_PARTY_NOTICES.md](../THIRD_PARTY_NOTICES.md) 和
  `third_party/lame/README.vendor.md`。

## 构建 APK

```powershell
$env:JAVA_HOME='C:\Program Files\Java\jdk-21'
$env:ANDROID_HOME='D:\path\to\android-sdk'
$env:ANDROID_SDK_ROOT=$env:ANDROID_HOME
.\gradlew.bat assembleRelease
```

产物：

- `app/build/outputs/apk/release/app-release.apk`（arm64-v8a）
- `trigger/build/outputs/apk/release/trigger-release.apk`

release 使用 debug signingConfig，便于自用安装；公开分发前应换私钥。

## 校验

```powershell
# 签名
apksigner verify --print-certs app\build\outputs\apk\release\app-release.apk

# 16 KB 页对齐
zipalign -c -P 16 -v 4 app\build\outputs\apk\release\app-release.apk

# 原生库
aapt list app\build\outputs\apk\release\app-release.apk | findstr lib/
```

## 主机侧解密/截断测试

```powershell
# 先构建 host ncmcheck
cd ncm_jni
cargo build --release --bin ncmcheck

# 完整文件
.\target\release\ncmcheck.exe ..\testdata\ncm\synth_mp3.ncm ..\testdata\out\out.mp3

# 截断文件（预期 INCOMPLETE，且不留下输出）
.\target\release\ncmcheck.exe ..\testdata\ncm\synth_mp3_trunc999.ncm ..\testdata\out\bad.mp3
```

生成合成 NCM（用于截断、FLAC、异常路径等可控测试）：

```powershell
python -m pip install pycryptodome imageio-ffmpeg
python tools\make_test_ncm.py --audio testdata\audio\test.mp3 `
  --out testdata\ncm\synth_mp3.ncm --format mp3 --duration-ms 20000 --bitrate 192000
```

`tools/make_test_ncm.py` 会随源码包提供；`testdata/` 和 SDK 不随源码包分发。

## 真机安装/触发

```powershell
adb install -r app\build\outputs\apk\release\app-release.apk
adb shell am start -a android.intent.action.VIEW `
  -d "ncmdecode://watch/start?minutes=30"
```

首次使用需要手动授权“所有文件访问”、通知，并选择输出目录。

## 测试数据说明

- `testdata/ncm/synth_*.ncm` 是本地生成的合成 NCM，只用于测试解密/验证，不是网易云下载文件。
- 真实 NCM 样例来自 ncmc 仓库 `test/`，以及本机网易云 `Download/netease/cloudmusic/Music/`（27 个 MP3 类 `.ncm`）。
- 测试记录见 [test-record.md](test-record.md)。
