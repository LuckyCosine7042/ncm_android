package dev.ensomi.ncmtrigger

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Minimal second app used to verify the external-trigger contract and the
 * "return to the originating app" experience.
 */
class TriggerActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "NCM Decode 外部触发测试"
            textSize = 22f
            setTextColor(Color.rgb(20, 30, 40))
        }
        val hint = TextView(this).apply {
            text = "先打开 NCM Decode 完成一次授权和目录设置。首次使用未配置时，入口界面会提示，不能由后台绕过。"
            textSize = 13f
            setTextColor(Color.rgb(80, 90, 100))
            setPadding(0, 12, 0, 24)
        }
        status = TextView(this).apply {
            text = "尚未触发"
            textSize = 14f
            setTextColor(Color.rgb(20, 80, 160))
            setPadding(0, 24, 0, 0)
        }
        root.addView(title, matchWrap())
        root.addView(hint, matchWrap())
        root.addView(button("深链接：ncmdecode://watch/start?minutes=30") {
            openDeepLink(30)
        }, matchWrap())
        root.addView(button("深链接：…?minutes=120（测试延长上限）") {
            openDeepLink(120)
        }, matchWrap())
        root.addView(button("深链接：…?minutes=0（应被拒绝）") {
            openDeepLink(0)
        }, matchWrap())
        root.addView(button("显式 Intent：START_WATCH, minutes=30") {
            openExplicit(30)
        }, matchWrap())
        root.addView(button("只打开 NCM Decode 主界面") {
            openMain()
        }, matchWrap())
        root.addView(status, matchWrap())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun openDeepLink(minutes: Int) {
        val uri = Uri.parse("ncmdecode://watch/start?minutes=$minutes")
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launch(intent, "深链接 $minutes 分钟")
    }

    private fun openExplicit(minutes: Int) {
        val intent = Intent().apply {
            component = ComponentName("dev.ensomi.ncmdecode", "dev.ensomi.ncmdecode.MainActivity")
            action = "dev.ensomi.ncmdecode.action.START_WATCH"
            putExtra("minutes", minutes)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        launch(intent, "显式 Intent $minutes 分钟")
    }

    private fun openMain() {
        val intent = Intent().apply {
            component = ComponentName("dev.ensomi.ncmdecode", "dev.ensomi.ncmdecode.MainActivity")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        launch(intent, "打开主界面")
    }

    private fun launch(intent: Intent, label: String) {
        try {
            startActivity(intent)
            status.text = "$label：已发送。按返回键应回到此页面。"
        } catch (t: Throwable) {
            status.text = "$label：失败 ${t.javaClass.simpleName}: ${t.message}"
        }
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = 10 }
    }

    private fun matchWrap(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
    ).apply { gravity = Gravity.START }
}
