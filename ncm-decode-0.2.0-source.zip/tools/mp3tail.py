import sys
BR=[0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0]
SR=[44100,48000,32000,0]
def frame_len(d,i):
    if i+4>len(d) or d[i]!=0xFF or (d[i+1]&0xE0)!=0xE0: return None
    ver=(d[i+1]>>3)&3; layer=(d[i+1]>>1)&3; br=(d[i+2]>>4)&15; sr=(d[i+2]>>2)&3; pad=(d[i+2]>>1)&1
    if ver==1 and layer==1 and br not in (0,15) and sr!=3:
        return (1152//8)*BR[br]*1000//SR[sr]+pad
    return None
def check(path):
    d=open(path,'rb').read(); end=len(d)
    if d[-128:-125]==b'TAG': end-=128
    # APE footer
    if d[end-32:end-24]==b'APETAGEX': end-=32
    found=[]
    for i in range(max(0,end-65536), end-3):
        fl=frame_len(d,i)
        if fl and i+fl==end:
            found.append((i,fl))
    print(path, 'size',len(d),'end',end,'last_frame_candidates',found[-3:], 'trailing', end-(found[-1][0]+found[-1][1]) if found else 'none')
for p in sys.argv[1:]: check(p)
