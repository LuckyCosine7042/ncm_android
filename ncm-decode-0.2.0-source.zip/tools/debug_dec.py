import sys, struct, base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
CORE=b"hzHRAmso5kInbaxW"; META=b"#14ljk_!\\]&0U<'("
def box(kd):
 b=list(range(256)); last=0; off=0
 for i in range(256):
  c=(b[i]+last+kd[off])&255; off=(off+1)%len(kd); b[i],b[c]=b[c],b[i]; last=c
 return bytes(b)
def ks(bx,n):
 out=bytearray(); i=0
 for _ in range(n):
  i=(i+1)&255; a=bx[i]; bb=bx[(a+i)&255]; out.append(bx[(a+bb)&255])
 return bytes(out)
def dec(path):
 d=open(path,'rb').read(); off=10
 kl=struct.unpack_from('<I',d,off)[0]; off+=4; k=bytes(x^0x64 for x in d[off:off+kl]); off+=kl
 kd=AES.new(CORE,AES.MODE_ECB).decrypt(k); kd=unpad(kd,16)[17:]
 ml=struct.unpack_from('<I',d,off)[0]; off+=4; m=bytes(x^0x63 for x in d[off:off+ml]); off+=ml
 print('keylen',kl,'metalen',ml,'meta prefix',m[:22])
 m=AES.new(META,AES.MODE_ECB).decrypt(base64.b64decode(m[22:])); print('meta inner',m[:10])
 off+=5; cfl,cl=struct.unpack_from('<II',d,off); off+=8; print('cover',cfl,cl); off+=cfl
 audio=d[off:]; plain=bytes(a^b for a,b in zip(audio,ks(box(kd),len(audio))))
 print('audio off',off,'first',plain[:16].hex(),'audio len',len(plain))
 open(path+'.dec','wb').write(plain)
dec(sys.argv[1])
