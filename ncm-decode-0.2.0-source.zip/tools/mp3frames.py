import sys
BR=[0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0]
SR=[44100,48000,32000,0]
def frame_len(d,i):
    if i+4>len(d) or d[i]!=0xFF or (d[i+1]&0xE0)!=0xE0: return None
    ver=(d[i+1]>>3)&3; layer=(d[i+1]>>1)&3; br=(d[i+2]>>4)&15; sr=(d[i+2]>>2)&3; pad=(d[i+2]>>1)&1
    if layer!=1 or br in (0,15) or sr==3: return None
    spf=1152 if ver==3 else 576
    if ver==1: return None
    return (spf//8)*BR[br]*1000//SR[sr]+pad
def scan(path):
    d=open(path,'rb').read(); off=0
    if d[:3]==b'ID3':
        sz=((d[6]&0x7f)<<21)|((d[7]&0x7f)<<14)|((d[8]&0x7f)<<7)|(d[9]&0x7f); off=10+sz
        if d[5]&0x10: off+=10
    end=len(d)
    if d[end-128:end-125]==b'TAG': end-=128
    start=None
    for i in range(off,min(end,off+4096)):
        if frame_len(d,i): start=i; break
    if start is None: print(path,'no start'); return
    off=start; frames=0; bad=None; samples=0
    while off<end:
        fl=frame_len(d,off)
        if fl is None or off+fl>end: bad=(off,end-off,fl); break
        frames+=1; samples += 1152 if ((d[off+1]>>3)&3)==3 else 576; off+=fl
    print(path.split('\\')[-1],'size',len(d),'start',start,'frames',frames,'samples',samples,'end_off',off,'target_end',end,'bad',bad,'trailing',end-off)
for p in sys.argv[1:]: scan(p)
