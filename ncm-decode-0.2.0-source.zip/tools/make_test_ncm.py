#!/usr/bin/env python3
"""Build structurally valid synthetic NCM files for testing.

This is NOT a NetEase downloader.  It wraps ordinary MP3/FLAC audio in the NCM
container so the Android decryptor can be exercised with real audio frames,
including truncated variants and both output formats.

Usage:
  python tools/make_test_ncm.py --audio input.mp3 --out out.ncm --format mp3
"""

import argparse
import base64
import json
import os
import struct
import subprocess
import sys

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

CORE_KEY = b"hzHRAmso5kInbaxW"
META_KEY = b"#14ljk_!\\]&0U<'("
KEY_MASK = 0x64
META_MASK = 0x63


def aes_ecb(data: bytes, key: bytes) -> bytes:
    return AES.new(key, AES.MODE_ECB).encrypt(pad(data, 16))


def make_key_box(key_data: bytes) -> bytes:
    box = list(range(256))
    last = 0
    offset = 0
    for i in range(256):
        c = (box[i] + last + key_data[offset]) & 0xFF
        offset += 1
        if offset >= len(key_data):
            offset = 0
        box[i], box[c] = box[c], box[i]
        last = c
    return bytes(box)


def keystream(box: bytes, length: int) -> bytes:
    out = bytearray()
    i = 0
    for _ in range(length):
        i = (i + 1) & 0xFF
        a = box[i]
        b = box[(a + i) & 0xFF]
        out.append(box[(a + b) & 0xFF])
    return bytes(out)


def xor(data: bytes, stream: bytes) -> bytes:
    return bytes(a ^ b for a, b in zip(data, stream))


def probe(path: str):
    ffprobe = os.path.join(os.path.dirname(sys.executable), "ffprobe.exe")
    if not os.path.exists(ffprobe):
        # imageio-ffmpeg ships ffmpeg only; use it for a rough duration if needed.
        ffprobe = "ffprobe"
    cmd = [
        ffprobe, "-v", "error", "-show_entries", "format=duration",
        "-show_entries", "stream=codec_name,sample_rate,channels,bit_rate",
        "-of", "json", path,
    ]
    return json.loads(subprocess.check_output(cmd))


def build(audio: str, out: str, fmt: str, duration_ms: int, bitrate: int,
          title: str, artist: str, album: str, key_data: bytes, cover: bytes):
    audio_bytes = open(audio, "rb").read()
    meta = {
        "musicId": 900000001,
        "musicName": title,
        "artist": [[artist, 1]],
        "album": album,
        "albumId": 1,
        "albumPic": "",
        "albumPicDocId": "",
        "alias": [],
        "bitrate": bitrate,
        "duration": duration_ms,
        "fee": 0,
        "flag": 0,
        "format": fmt,
        "mp3DocId": None,
        "mvId": 0,
        "transNames": [],
    }
    meta_plain = b"music:" + json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    meta_enc = aes_ecb(meta_plain, META_KEY)
    meta_b64 = base64.b64encode(meta_enc)
    meta_outer = b"163 key(Don't modify):" + meta_b64
    meta_block = bytes(b ^ META_MASK for b in meta_outer)

    key_plain = b"neteasecloudmusic" + key_data
    key_enc = aes_ecb(key_plain, CORE_KEY)
    key_block = bytes(b ^ KEY_MASK for b in key_enc)

    box = make_key_box(key_data)
    encrypted_audio = xor(audio_bytes, keystream(box, len(audio_bytes)))

    with open(out, "wb") as f:
        f.write(b"CTENFDAM")
        f.write(b"\x01\x70")
        f.write(struct.pack("<I", len(key_block)))
        f.write(key_block)
        f.write(struct.pack("<I", len(meta_block)))
        f.write(meta_block)
        f.write(b"\x00" * 5)
        f.write(struct.pack("<I", len(cover)))
        f.write(struct.pack("<I", len(cover)))
        f.write(cover)
        f.write(encrypted_audio)
    return len(audio_bytes), len(cover)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--audio", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--format", choices=["mp3", "flac"], required=True)
    p.add_argument("--duration-ms", type=int, required=True)
    p.add_argument("--bitrate", type=int, default=128000)
    p.add_argument("--title", default="Synthetic Tone")
    p.add_argument("--artist", default="NCM Decode Test")
    p.add_argument("--album", default="Test Album")
    p.add_argument("--cover", default=None)
    p.add_argument("--key", default=None, help="hex key, default random 256 bytes")
    a = p.parse_args()
    key_data = bytes.fromhex(a.key) if a.key else os.urandom(256)
    cover = open(a.cover, "rb").read() if a.cover else b""
    size, csize = build(a.audio, a.out, a.format, a.duration_ms, a.bitrate,
                        a.title, a.artist, a.album, key_data, cover)
    print(f"wrote {a.out}: audio={size} bytes cover={csize} bytes format={a.format}")


if __name__ == "__main__":
    main()
