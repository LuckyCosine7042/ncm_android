import sys, struct, base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
CORE=b"hzHRAmso5kInbaxW"
def box(kd):
 b=list(range(256)); last=0; off=0
 for i in range(256):
  c=(b[i]+last+kd[off])&255; off=(off+1)%len(kd); b[i],b[c]=b[c],b[i]; last=c
 return bytes(b)
def ks(bx,n):
 out=bytearray(); i=0
 for _ in range(n):
  i=(i+1)&255; a=bx[i]; bb=bx[(a+i)&255]; out.append(bx[bb])
 return bytes(out)
d=open(sys.argv[1],'rb').read(); off=10; kl=struct.unpack_from('<I',d,off)[0]; off+=4; k=bytes(x^0x64 for x in d[off:off+kl]); off+=kl
kd=unpad(AES.new(CORE,AES.MODE_ECB).decrypt(k),16)[17:]
off+=4+struct.unpack_from('<I',d,off)[0]+5; cfl,cl=struct.unpack_from('<II',d,off); off+=8+cfl
stream=ks(box(kd),len(d)-off)
for target in [b'ID3', b'fLaC', b'\xff\xfb']:
 hits=[]
 for i in range(0,min(len(stream),2000)):
  if bytes(c^s for c,s in zip(d[off+i:off+i+len(target)], stream[i:i+len(target)]))==target:
   hits.append(i)
 print(target,hits[:10])
print('audiooff',off,'first cipher',d[off:off+8].hex(),'ks',stream[:8].hex())
