import sys, os
BITRATES=[0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0]
SR=[44100,48000,32000,0]
def parse(path):
    d=open(path,'rb').read()
    off=0
    if d[:3]==b'ID3':
        sz=((d[6]&0x7f)<<21)|((d[7]&0x7f)<<14)|((d[8]&0x7f)<<7)|(d[9]&0x7f)
        off=10+sz
    start=off; frames=0; samples=0; partial=0
    while off+4<=len(d):
        if d[off]==0xFF and (d[off+1]&0xE0)==0xE0:
            ver=(d[off+1]>>3)&3; layer=(d[off+1]>>1)&3; br=(d[off+2]>>4)&15; sr=(d[off+2]>>2)&3; pad=(d[off+2]>>1)&1
            if ver==1 and layer==1 and br not in (0,15) and sr!=3:
                spf=1152; brv=BITRATES[br]*1000; srv=SR[sr]
                flen=(spf//8)*brv//srv+pad
                if off+flen>len(d):
                    partial=len(d)-off; break
                frames+=1; samples+=spf; off+=flen; continue
        partial=len(d)-off; break
    print(path, 'len',len(d),'audio_start',start,'frames',frames,'samples',samples,'dur_ms',samples/44100*1000,'end',off,'partial',partial,'tail',d[-16:].hex())
for p in sys.argv[1:]: parse(p)
