//! Build script for the JNI crate.
//!
//! The FLAC -> MP3 path needs an MP3 encoder.  AOSP does not ship a
//! `audio/mpeg` MediaCodec encoder and vendor support is inconsistent, so the
//! encoder is LAME (libmp3lame 3.100), vendored under `third_party/lame` and
//! compiled here for the Android target with the NDK clang that Gradle already
//! passes through `CC_<target>` / `AR_<target>` (see `buildRustArm64` in
//! `app/build.gradle.kts`).
//!
//! Only the encoder subset of libmp3lame is compiled: the decoder (mpglib) and
//! the CLI frontend are not part of the library and are not needed here.
//!
//! Host builds (cargo test / ncmcheck on the developer machine) skip LAME; the
//! transcode entry point then reports an encoder failure and the decrypt path
//! falls back to publishing FLAC.

use std::env;
use std::path::PathBuf;
use std::process::Command;

/// libmp3lame encoder sources (LAME 3.100).  `mpglib_interface.c` and the
/// `mpglib/` decoder are deliberately absent.
const LAME_SOURCES: &[&str] = &[
    "bitstream.c",
    "encoder.c",
    "fft.c",
    "gain_analysis.c",
    "id3tag.c",
    "lame.c",
    "newmdct.c",
    "presets.c",
    "psymodel.c",
    "quantize.c",
    "quantize_pvt.c",
    "reservoir.c",
    "set_get.c",
    "tables.c",
    "takehiro.c",
    "util.c",
    "vbrquantize.c",
    "VbrTag.c",
    "version.c",
];

fn main() {
    let target = env::var("TARGET").unwrap_or_default();
    println!("cargo:rerun-if-changed=build.rs");

    if !target.contains("android") {
        println!(
            "cargo:warning=libmp3lame is only built for Android targets; \
             FLAC transcoding is disabled for {target}"
        );
        return;
    }

    let manifest_dir = PathBuf::from(env::var("CARGO_MANIFEST_DIR").expect("CARGO_MANIFEST_DIR"));
    // `absolute` rather than `canonicalize`: the `\\?\` prefix Windows adds to
    // canonical paths breaks clang's -I / input handling here.
    let mut lame_dir = std::path::absolute(manifest_dir.join("..").join("third_party").join("lame"))
        .expect("third_party/lame path");
    let text = lame_dir.to_string_lossy().into_owned();
    if let Some(rest) = text.strip_prefix(r"\\?\") {
        lame_dir = PathBuf::from(rest);
    }
    let out_dir = PathBuf::from(env::var("OUT_DIR").expect("OUT_DIR"));
    let target_key = target.replace('-', "_");

    let cc = env::var(format!("CC_{target_key}"))
        .or_else(|_| env::var("TARGET_CC"))
        .or_else(|_| env::var("CC"))
        .unwrap_or_else(|_| panic!("no C compiler for {target}; set CC_{target_key}"));
    let ar = env::var(format!("AR_{target_key}"))
        .or_else(|_| env::var("TARGET_AR"))
        .or_else(|_| env::var("AR"))
        .unwrap_or_else(|_| panic!("no archiver for {target}; set AR_{target_key}"));

    let obj_dir = out_dir.join("lame-obj");
    std::fs::create_dir_all(&obj_dir).expect("create lame object dir");

    let mut objects = Vec::with_capacity(LAME_SOURCES.len());
    for source in LAME_SOURCES {
        let src = lame_dir.join("libmp3lame").join(source);
        let obj = obj_dir.join(source.replace(".c", ".o"));
        println!("cargo:rerun-if-changed={}", src.display());
        run(
            &cc,
            &[
                "-O2".into(),
                "-fPIC".into(),
                "-std=gnu99".into(),
                "-w".into(),
                "-DHAVE_CONFIG_H".into(),
                format!("-I{}", lame_dir.display()),
                format!("-I{}", lame_dir.join("include").display()),
                format!("-I{}", lame_dir.join("libmp3lame").display()),
                "-c".into(),
                src.display().to_string(),
                "-o".into(),
                obj.display().to_string(),
            ],
        );
        objects.push(obj);
    }

    let archive = out_dir.join("libmp3lame.a");
    let mut ar_args: Vec<String> = vec!["rcs".into(), archive.display().to_string()];
    ar_args.extend(objects.iter().map(|p| p.display().to_string()));
    run(&ar, &ar_args);

    println!("cargo:rustc-link-search=native={}", out_dir.display());
    println!("cargo:rustc-link-lib=static=mp3lame");
    // libmp3lame uses math functions (log, pow, ...) from bionic's libm.
    println!("cargo:rustc-link-lib=m");
    println!("cargo:rerun-if-changed={}", lame_dir.join("config.h").display());
    println!("cargo:rerun-if-changed={}", lame_dir.join("include/lame.h").display());
    println!(
        "cargo:rerun-if-changed={}",
        lame_dir.join("libmp3lame").display()
    );
}

/// Run a compiler/archiver.  Gradle points `CC_*` at the NDK's `.cmd` wrapper
/// on Windows; `Command` cannot execute batch files directly, so those are run
/// through `cmd /C`.
fn run(tool: &str, args: &[String]) {
    let is_batch = {
        let lower = tool.to_ascii_lowercase();
        lower.ends_with(".cmd") || lower.ends_with(".bat")
    };
    let status = if is_batch {
        let mut cmd = Command::new("cmd");
        cmd.arg("/C").arg(tool).args(args);
        cmd.status()
    } else {
        Command::new(tool).args(args).status()
    };
    let status = status.unwrap_or_else(|e| panic!("cannot run {tool}: {e}"));
    if !status.success() {
        panic!("{tool} failed with {status}");
    }
}
