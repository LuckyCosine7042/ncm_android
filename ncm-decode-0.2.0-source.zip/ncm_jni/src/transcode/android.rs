//! Android implementation of the FLAC -> MP3 transcode.
//!
//! Streaming design (all buffers are allocated once per file):
//!
//! ```text
//! FLAC file --(256 KiB ring buffer)--> symphonia demux --+
//!                                                        |
//!                       decoder --> SampleBuffer<i16>  --+--> LAME --> 1 MiB
//!                       (reused, grown once)                  |        BufWriter
//!                                                             +--> MP3 file
//! ```
//!
//! Nothing is held whole-file: peak memory is the decoder's block buffer plus
//! the two fixed I/O buffers, independent of track length.

use std::fs::{self, File};
use std::io::{self, BufWriter, Read, Seek, SeekFrom, Write};
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Instant;

use symphonia::core::audio::SampleBuffer;
use symphonia::core::codecs::DecoderOptions;
use symphonia::core::errors::Error as SymphoniaError;
use symphonia::core::formats::FormatOptions;
use symphonia::core::io::{MediaSourceStream, MediaSourceStreamOptions};
use symphonia::core::meta::MetadataOptions;
use symphonia::core::probe::Hint;
use symphonia::default::{get_codecs, get_probe};

use super::{TranscodeError, TranscodeErrorKind, TranscodeStats};
use crate::lame::Encoder;
use crate::mp3_frame_len;

/// Read buffer for the FLAC input.  symphonia's default is 64 KiB; 256 KiB cuts
/// the read syscalls by 4x on a multi-MB file.
const INPUT_BUFFER_BYTES: usize = 256 * 1024;
/// Write buffer for the MP3 output.  LAME emits ~1 KiB frames, so 1 MiB batches
/// roughly a thousand writes into one.
const OUTPUT_BUFFER_BYTES: usize = 1024 * 1024;

/// Sample rates MPEG-1 Layer III supports (320 kbps only exists for MPEG-1).
const MPEG1_RATES: [u32; 3] = [32_000, 44_100, 48_000];

pub fn transcode_flac_to_mp3(
    flac: &Path,
    mp3: &Path,
    cancelled: &AtomicBool,
) -> Result<TranscodeStats, TranscodeError> {
    let started = Instant::now();
    let input_bytes = fs::metadata(flac).map(|m| m.len()).unwrap_or(0);
    let result = run(flac, mp3, cancelled, input_bytes);
    match result {
        Ok(mut stats) => {
            stats.transcode_ms = started.elapsed().as_millis() as u64;
            Ok(stats)
        }
        Err(e) => {
            // Never leave a half-written MP3 behind; the caller treats this file
            // as untrusted and falls back to the FLAC.
            let _ = fs::remove_file(mp3);
            Err(e)
        }
    }
}

fn audio(code: &'static str, message: impl Into<String>) -> TranscodeError {
    TranscodeError::new(TranscodeErrorKind::Audio, code, message)
}

fn encoder(code: &'static str, message: impl Into<String>) -> TranscodeError {
    TranscodeError::new(TranscodeErrorKind::Encoder, code, message)
}

fn io_encoder(context: &str, error: io::Error) -> TranscodeError {
    encoder("TRANSCODE_IO", format!("{context}: {error}"))
}

fn run(
    flac: &Path,
    mp3: &Path,
    cancelled: &AtomicBool,
    input_bytes: u64,
) -> Result<TranscodeStats, TranscodeError> {
    let file = File::open(flac)
        .map_err(|e| audio("INCOMPLETE", format!("cannot open FLAC for transcoding: {e}")))?;
    let mss = MediaSourceStream::new(
        Box::new(file),
        MediaSourceStreamOptions {
            buffer_len: INPUT_BUFFER_BYTES,
        },
    );
    let mut hint = Hint::new();
    hint.with_extension("flac");
    let probed = get_probe()
        .format(
            &hint,
            mss,
            &FormatOptions {
                enable_gapless: true,
                ..Default::default()
            },
            &MetadataOptions::default(),
        )
        .map_err(|e| audio("INCOMPLETE", format!("FLAC container cannot be parsed: {e}")))?;
    let mut fmt = probed.format;
    let track = fmt
        .default_track()
        .ok_or_else(|| audio("INCOMPLETE", "FLAC has no decodable track"))?;
    let track_id = track.id;
    let sample_rate = track
        .codec_params
        .sample_rate
        .ok_or_else(|| audio("INCOMPLETE", "FLAC track has no sample rate"))?;
    let channels = track
        .codec_params
        .channels
        .map(|c| c.count() as u32)
        .ok_or_else(|| audio("INCOMPLETE", "FLAC track has no channel count"))?;
    let declared_frames = track.codec_params.n_frames;
    let mut decoder = get_codecs()
        .make(&track.codec_params, &DecoderOptions::default())
        .map_err(|e| audio("UNSUPPORTED_FORMAT", format!("no FLAC decoder: {e}")))?;

    // 320 kbps CBR is an MPEG-1 feature: the output rate must be 32/44.1/48 kHz.
    // Common hi-res rates (64/88.2/96/128/176.4/192 kHz) halve to one of those,
    // and LAME resamples internally, so the timer stays intact.  Anything else
    // is refused here and published as FLAC instead.
    let output_rate = choose_output_rate(sample_rate)?;
    let resampled = output_rate != sample_rate;

    let mut mp3_encoder = Encoder::new(sample_rate, output_rate, channels as usize)
        .map_err(|e| encoder(e.code, e.message))?;

    let out_file = File::create(mp3).map_err(|e| io_encoder("cannot create MP3 output", e))?;
    let mut writer = BufWriter::with_capacity(OUTPUT_BUFFER_BYTES, out_file);

    let mut sample_buf: Option<SampleBuffer<i16>> = None;
    let mut mp3buf: Vec<u8> = Vec::with_capacity(mp3_encoder.max_output_bytes + 4096);
    let mut decoded_frames: u64 = 0;
    let mut frame_counter = FrameCounter::new();
    let mut decode_ns: u64 = 0;
    let mut encode_ns: u64 = 0;

    loop {
        if cancelled.load(Ordering::Relaxed) {
            return Err(audio("CANCELLED", "transcode cancelled"));
        }
        let packet = match fmt.next_packet() {
            Ok(packet) => packet,
            Err(SymphoniaError::IoError(e)) if e.kind() == io::ErrorKind::UnexpectedEof => break,
            Err(SymphoniaError::ResetRequired) => {
                return Err(audio(
                    "UNSUPPORTED_FORMAT",
                    "FLAC stream changed parameters mid-file",
                ))
            }
            Err(e) => {
                return Err(audio(
                    "INCOMPLETE",
                    format!("FLAC demux failed (truncated or corrupt): {e}"),
                ))
            }
        };
        if packet.track_id() != track_id {
            continue;
        }

        let decode_start = Instant::now();
        let decoded = match decoder.decode(&packet) {
            Ok(decoded) => decoded,
            Err(SymphoniaError::IoError(e)) if e.kind() == io::ErrorKind::UnexpectedEof => break,
            Err(e) => {
                return Err(audio(
                    "INCOMPLETE",
                    format!("FLAC decode failed (truncated or corrupt): {e}"),
                ))
            }
        };
        let frame_count = decoded.frames();
        if frame_count == 0 {
            continue;
        }
        if decoded.spec().channels.count() != channels as usize {
            return Err(audio(
                "UNSUPPORTED_FORMAT",
                "FLAC channel layout changed mid-stream",
            ));
        }
        let needed = frame_count * channels as usize;
        if sample_buf
            .as_ref()
            .map(|sb| sb.capacity() < needed)
            .unwrap_or(true)
        {
            sample_buf = Some(SampleBuffer::<i16>::new(
                decoded.capacity().max(frame_count) as u64,
                *decoded.spec(),
            ));
        }
        let sb = sample_buf.as_mut().expect("sample buffer initialised above");
        sb.copy_interleaved_ref(decoded);
        decode_ns += decode_start.elapsed().as_nanos() as u64;
        decoded_frames += frame_count as u64;

        let encode_start = Instant::now();
        mp3_encoder
            .encode(sb.samples(), &mut mp3buf)
            .map_err(|e| encoder(e.code, e.message))?;
        encode_ns += encode_start.elapsed().as_nanos() as u64;
        if !mp3buf.is_empty() {
            frame_counter.push(&mp3buf);
            writer
                .write_all(&mp3buf)
                .map_err(|e| io_encoder("cannot write MP3 output", e))?;
        }
    }

    if decoded_frames == 0 {
        return Err(audio("INCOMPLETE", "FLAC contains no decodable frames"));
    }
    // The decode above consumed the whole stream, so this is the same proof of
    // completeness the separate validation pass used to provide.
    if let Some(declared) = declared_frames {
        if decoded_frames != declared {
            return Err(audio(
                "INCOMPLETE",
                format!(
                    "FLAC decoded {decoded_frames} samples but STREAMINFO declares {declared}; \
                     file is truncated"
                ),
            ));
        }
    }

    let flush_start = Instant::now();
    mp3_encoder
        .flush(&mut mp3buf)
        .map_err(|e| encoder(e.code, e.message))?;
    encode_ns += flush_start.elapsed().as_nanos() as u64;
    if !mp3buf.is_empty() {
        frame_counter.push(&mp3buf);
        writer
            .write_all(&mp3buf)
            .map_err(|e| io_encoder("cannot write MP3 output", e))?;
    }
    writer
        .flush()
        .map_err(|e| io_encoder("cannot flush MP3 output", e))?;
    let mut out = writer
        .into_inner()
        .map_err(|e| io_encoder("cannot finalise MP3 output", e.into_error()))?;

    // Replace LAME's placeholder Xing/Info frame with the finalised one.  It is
    // at offset 0 because no ID3v2 tag is written; if that ever changes, leave
    // the stream alone rather than overwriting a tag.
    let tag = mp3_encoder.lametag_frame();
    if !tag.is_empty() && starts_with_mp3_frame(&mut out) {
        out.seek(SeekFrom::Start(0))
            .map_err(|e| io_encoder("cannot seek MP3 output", e))?;
        out.write_all(&tag)
            .map_err(|e| io_encoder("cannot patch MP3 info frame", e))?;
        out.flush()
            .map_err(|e| io_encoder("cannot flush MP3 output", e))?;
    }
    // No fsync here on purpose: the file is copied into the SAF document by the
    // same process right after this call, so the page cache is enough.  A
    // durability flush would only add latency to a cache file that is deleted
    // once publishing succeeds.
    let output_bytes = out
        .metadata()
        .map(|m| m.len())
        .map_err(|e| io_encoder("cannot stat MP3 output", e))?;
    if output_bytes <= 16 {
        return Err(encoder("TRANSCODE_EMPTY", "encoder produced an empty MP3"));
    }

    Ok(TranscodeStats {
        input_bytes,
        output_bytes,
        sample_rate,
        output_sample_rate: output_rate,
        channels,
        decoded_frames,
        duration_ms: decoded_frames.saturating_mul(1000) / sample_rate as u64,
        decode_ms: decode_ns / 1_000_000,
        encode_ms: encode_ns / 1_000_000,
        transcode_ms: 0,
        mp3_frames: frame_counter.frames,
        resampled,
    })
}

/// Pick the MP3 sample rate for a FLAC rate: identical when MPEG-1 already
/// supports it, otherwise a power-of-two reduction (LAME resamples the stream).
fn choose_output_rate(sample_rate: u32) -> Result<u32, TranscodeError> {
    if MPEG1_RATES.contains(&sample_rate) {
        return Ok(sample_rate);
    }
    let mut rate = sample_rate;
    while rate > 48_000 {
        rate /= 2;
    }
    if MPEG1_RATES.contains(&rate) && sample_rate % rate == 0 {
        return Ok(rate);
    }
    Err(encoder(
        "TRANSCODE_UNSUPPORTED_RATE",
        format!("{sample_rate} Hz cannot be encoded as 320 kbps MPEG-1 audio"),
    ))
}

/// Counts complete MPEG-1 Layer III frames across LAME output chunks.
///
/// LAME does not guarantee that every returned chunk ends on a frame boundary,
/// so a few bytes are carried over to the next chunk.
struct FrameCounter {
    carry: Vec<u8>,
    frames: u64,
}

impl FrameCounter {
    fn new() -> Self {
        Self {
            carry: Vec::with_capacity(8 * 1024),
            frames: 0,
        }
    }

    fn push(&mut self, chunk: &[u8]) {
        if self.carry.is_empty() {
            let used = Self::parse(chunk, &mut self.frames);
            if used < chunk.len() {
                self.carry.extend_from_slice(&chunk[used..]);
            }
            return;
        }
        self.carry.extend_from_slice(chunk);
        let used = Self::parse(&self.carry, &mut self.frames);
        if used > 0 {
            self.carry.drain(..used);
        }
    }

    /// Parse as many whole frames as `data` contains; return the bytes consumed.
    fn parse(data: &[u8], frames: &mut u64) -> usize {
        let mut pos = 0usize;
        while pos + 4 <= data.len() {
            match mp3_frame_len(&data[pos..pos + 4]) {
                Some(len) if pos + len <= data.len() => {
                    *frames += 1;
                    pos += len;
                }
                _ => break,
            }
        }
        pos
    }
}

fn starts_with_mp3_frame(file: &mut File) -> bool {
    let mut head = [0u8; 4];
    if file.seek(SeekFrom::Start(0)).is_err() {
        return false;
    }
    if file.read_exact(&mut head).is_err() {
        return false;
    }
    mp3_frame_len(&head).is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn output_rate_mapping() {
        assert_eq!(choose_output_rate(44_100).unwrap(), 44_100);
        assert_eq!(choose_output_rate(48_000).unwrap(), 48_000);
        assert_eq!(choose_output_rate(32_000).unwrap(), 32_000);
        assert_eq!(choose_output_rate(88_200).unwrap(), 44_100);
        assert_eq!(choose_output_rate(96_000).unwrap(), 48_000);
        assert_eq!(choose_output_rate(192_000).unwrap(), 48_000);
        assert_eq!(choose_output_rate(64_000).unwrap(), 32_000);
        assert!(choose_output_rate(22_050).is_err());
        assert!(choose_output_rate(37_800).is_err());
    }
}