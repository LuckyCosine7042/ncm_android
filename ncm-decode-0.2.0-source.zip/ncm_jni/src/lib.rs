//! JNI bridge and decryption/validation core for the NCM Decode Android app.
//!
//! The public entry points never treat "ncmc_lib returned Ok" as proof of a
//! complete download.  After decrypting, the restored audio is fully decoded
//! and its duration is compared with the duration stored in the NCM metadata.

use std::fs::{self, File};
use std::io::{self, Read, Seek, SeekFrom, Write};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};

use ncmc_lib::NcmFile;
use serde_json::{json, Value};
use symphonia::core::codecs::DecoderOptions;
use symphonia::core::errors::Error as SymphoniaError;
use symphonia::core::formats::FormatOptions;
use symphonia::core::io::MediaSourceStream;
use symphonia::core::meta::MetadataOptions;
use symphonia::core::probe::Hint;
use symphonia::default::{get_codecs, get_probe};

#[cfg(target_os = "android")]
pub mod lame;
pub mod transcode;

use transcode::{TranscodeErrorKind, TranscodeStats};

const NCM_MAGIC: &[u8; 8] = b"CTENFDAM";
const MAX_KEY_LEN: u64 = 1 * 1024 * 1024;
const MAX_META_LEN: u64 = 16 * 1024 * 1024;
const MAX_COVER_LEN: u64 = 64 * 1024 * 1024;
const MIN_AUDIO_BYTES: u64 = 1024;

static CANCELLED: AtomicBool = AtomicBool::new(false);

#[derive(Debug)]
struct Failure {
    code: &'static str,
    message: String,
    extra: Option<Value>,
}

impl Failure {
    fn new(code: &'static str, message: impl Into<String>) -> Self {
        Self {
            code,
            message: message.into(),
            extra: None,
        }
    }

    fn with_extra(code: &'static str, message: impl Into<String>, extra: Value) -> Self {
        Self {
            code,
            message: message.into(),
            extra: Some(extra),
        }
    }
}

#[derive(Debug, Clone, Default)]
struct NcmInfo {
    format: String,
    duration_ms: u64,
    bitrate: u64,
    artist: String,
    title: String,
    album: String,
    music_id: String,
}

fn io_failure(context: &str, error: io::Error) -> Failure {
    Failure::new("IO", format!("{context}: {error}"))
}

/// Validate the container offsets before handing the file to ncmc_lib.
///
/// ncmc_lib allocates key/metadata/cover buffers from length fields in the
/// file.  A corrupt file can otherwise request a multi-gigabyte allocation.
fn check_ncm_structure(path: &Path) -> Result<(), Failure> {
    let mut file = File::open(path).map_err(|e| io_failure("cannot open input", e))?;
    let file_len = file
        .metadata()
        .map_err(|e| io_failure("cannot stat input", e))?
        .len();

    let mut head = [0u8; 10];
    file.read_exact(&mut head)
        .map_err(|_| Failure::new("INVALID_NCM", "file is shorter than the NCM header"))?;
    if &head[..8] != NCM_MAGIC {
        return Err(Failure::new(
            "INVALID_NCM",
            "not an NCM file (missing CTENFDAM header)",
        ));
    }

    let key_len = read_u32(&mut file)? as u64;
    if key_len == 0 || key_len > MAX_KEY_LEN {
        return Err(Failure::new("INVALID_NCM", "implausible NCM key length"));
    }
    checked_skip(&mut file, key_len, file_len, "key block")?;

    let meta_len = read_u32(&mut file)? as u64;
    if meta_len == 0 || meta_len > MAX_META_LEN {
        return Err(Failure::new("INVALID_NCM", "implausible NCM metadata length"));
    }
    checked_skip(&mut file, meta_len, file_len, "metadata block")?;

    // ncmc_lib skips 5 bytes here, then expects cover-frame length and the
    // actual cover length.  The difference between them is padding.
    checked_skip(&mut file, 5, file_len, "CRC block")?;
    let cover_frame_len = read_u32(&mut file)? as u64;
    let cover_len = read_u32(&mut file)? as u64;
    if cover_frame_len < cover_len || cover_frame_len > MAX_COVER_LEN || cover_len > MAX_COVER_LEN {
        return Err(Failure::new("INVALID_NCM", "implausible NCM cover lengths"));
    }
    checked_skip(&mut file, cover_frame_len, file_len, "cover block")?;

    let audio_offset = file.stream_position().map_err(|e| io_failure("seek input", e))?;
    if audio_offset >= file_len || file_len - audio_offset < MIN_AUDIO_BYTES {
        return Err(Failure::new(
            "INCOMPLETE",
            "NCM header is complete but the audio payload is missing or too short",
        ));
    }
    Ok(())
}

fn read_u32(file: &mut File) -> Result<u32, Failure> {
    let mut buf = [0u8; 4];
    file.read_exact(&mut buf)
        .map_err(|_| Failure::new("INVALID_NCM", "truncated NCM length field"))?;
    Ok(u32::from_le_bytes(buf))
}

fn checked_skip(
    file: &mut File,
    amount: u64,
    file_len: u64,
    what: &str,
) -> Result<(), Failure> {
    let pos = file.stream_position().map_err(|e| io_failure("seek input", e))?;
    if amount > file_len.saturating_sub(pos) {
        return Err(Failure::new(
            "INVALID_NCM",
            format!("{what} extends past end of file"),
        ));
    }
    file.seek(SeekFrom::Current(amount as i64))
        .map_err(|e| io_failure("seek input", e))?;
    Ok(())
}

fn read_info(path: &Path) -> Result<(NcmFile, NcmInfo), Failure> {
    check_ncm_structure(path)?;
    let ncm = NcmFile::open(path).map_err(|e| {
        Failure::new("INVALID_NCM", format!("cannot parse NCM container: {e}"))
    })?;
    let meta = ncm.meta();
    let artist = meta
        .artist
        .iter()
        .map(|a| a.name.as_str())
        .collect::<Vec<_>>()
        .join(", ");
    let info = NcmInfo {
        format: meta.format.to_ascii_lowercase(),
        duration_ms: meta.duration as u64,
        bitrate: meta.bitrate as u64,
        artist,
        title: meta.music_name.clone(),
        album: meta.album.clone(),
        music_id: meta.music_id.clone(),
    };
    Ok((ncm, info))
}

fn detect_format(path: &Path, declared: &str) -> Result<&'static str, Failure> {
    let mut file = File::open(path).map_err(|e| io_failure("cannot open decrypted output", e))?;
    let mut magic = [0u8; 4];
    let n = file.read(&mut magic).map_err(|e| io_failure("read output", e))?;
    let by_magic = if n >= 4 && &magic == b"fLaC" {
        Some("flac")
    } else if n >= 3 && &magic[..3] == b"ID3" {
        Some("mp3")
    } else if n >= 2 && magic[0] == 0xff && (magic[1] & 0xe0) == 0xe0 {
        Some("mp3")
    } else {
        None
    };

    match (by_magic, declared) {
        (Some("flac"), "flac") | (Some("mp3"), "mp3") => Ok(by_magic.unwrap()),
        (Some(found), other) if other == "mp3" || other == "flac" => Ok(found),
        (Some(found), _) => Ok(found),
        (None, "mp3") => Err(Failure::new(
            "INCOMPLETE",
            "restored audio does not start with an MP3 frame or ID3 header",
        )),
        (None, "flac") => Err(Failure::new(
            "INCOMPLETE",
            "restored audio does not start with the FLAC magic bytes",
        )),
        (None, _) => Err(Failure::new(
            "UNSUPPORTED_FORMAT",
            format!("unsupported or unrecognised audio format: {declared}"),
        )),
    }
}

struct AudioValidation {
    duration_ms: u64,
    decoded_frames: u64,
    declared_frames: Option<u64>,
}

/// Walk MP3 frame headers from the first audio frame to the logical end of the
/// stream.  A truncated download almost always ends in the middle of a frame;
/// symphonia may silently ignore those trailing bytes, so this structural check
/// is stricter than "the decoder did not return an error".
fn check_mp3_frames(path: &Path) -> Result<(), Failure> {
    let mut file = File::open(path).map_err(|e| io_failure("cannot open MP3 output", e))?;
    let len = file
        .metadata()
        .map_err(|e| io_failure("cannot stat MP3 output", e))?
        .len();
    if len < 16 {
        return Err(Failure::new("INCOMPLETE", "MP3 output is too short"));
    }

    let mut start: u64 = 0;
    let mut head = [0u8; 10];
    if file.read_exact(&mut head).is_ok() && &head[..3] == b"ID3" {
        let size = ((head[6] as u64 & 0x7f) << 21)
            | ((head[7] as u64 & 0x7f) << 14)
            | ((head[8] as u64 & 0x7f) << 7)
            | (head[9] as u64 & 0x7f);
        start = 10 + size;
        if head[5] & 0x10 != 0 {
            start += 10; // ID3v2 footer
        }
    }

    let mut end = len;
    if len >= 128 {
        let mut tag = [0u8; 128];
        file.seek(SeekFrom::Start(len - 128))
            .map_err(|e| io_failure("seek MP3 output", e))?;
        if file.read_exact(&mut tag).is_ok() && &tag[..3] == b"TAG" {
            end -= 128;
        }
    }
    if len >= 32 {
        let mut tag = [0u8; 32];
        file.seek(SeekFrom::Start(len - 32))
            .map_err(|e| io_failure("seek MP3 output", e))?;
        if file.read_exact(&mut tag).is_ok() && &tag[..8] == b"APETAGEX" {
            let size = u32::from_le_bytes([tag[12], tag[13], tag[14], tag[15]]) as u64;
            let flags = u32::from_le_bytes([tag[20], tag[21], tag[22], tag[23]]);
            if size > 0 && size <= end {
                end -= size;
                if flags & 0x8000_0000 != 0 && end >= 32 {
                    end -= 32; // optional APE header
                }
            }
        }
    }

    if start >= end {
        return Err(Failure::new("INCOMPLETE", "MP3 output has no audio payload"));
    }

    // Some encoders leave a few bytes between the ID3 tag and the first frame.
    let probe_len = std::cmp::min(8192, end - start) as usize;
    let mut probe = vec![0u8; probe_len];
    file.seek(SeekFrom::Start(start))
        .map_err(|e| io_failure("seek MP3 output", e))?;
    file.read_exact(&mut probe)
        .map_err(|e| io_failure("read MP3 output", e))?;
    let mut first = None;
    for i in 0..probe.len().saturating_sub(3) {
        if mp3_frame_len(&probe[i..i + 4]).is_some() {
            first = Some(i as u64);
            break;
        }
    }
    let first = first.ok_or_else(|| {
        Failure::new("INCOMPLETE", "MP3 output has no valid frame after the ID3 tag")
    })?;
    let mut pos = start + first;

    while pos < end {
        let remaining = end - pos;
        if remaining < 4 {
            return Err(Failure::new(
                "INCOMPLETE",
                format!("MP3 stream ends with {remaining} stray bytes"),
            ));
        }
        file.seek(SeekFrom::Start(pos))
            .map_err(|e| io_failure("seek MP3 frame", e))?;
        let mut h = [0u8; 4];
        file.read_exact(&mut h)
            .map_err(|e| io_failure("read MP3 frame header", e))?;
        let frame_len = mp3_frame_len(&h).ok_or_else(|| {
            Failure::new(
                "INCOMPLETE",
                format!("invalid MP3 frame header at byte {pos} of {end}"),
            )
        })?;
        if frame_len as u64 > remaining {
            return Err(Failure::new(
                "INCOMPLETE",
                format!(
                    "MP3 stream ends inside a frame at byte {pos}: frame needs {frame_len} bytes, only {remaining} remain"
                ),
            ));
        }
        pos += frame_len as u64;
    }
    Ok(())
}

/// Return the byte length of a Layer III frame, or None for an invalid header.
pub(crate) fn mp3_frame_len(h: &[u8]) -> Option<usize> {
    if h.len() < 4 || h[0] != 0xff || h[1] & 0xe0 != 0xe0 {
        return None;
    }
    let version = (h[1] >> 3) & 0x03; // 3=MPEG1, 2=MPEG2, 0=MPEG2.5
    let layer = (h[1] >> 1) & 0x03; // 1=Layer III
    let bitrate_index = (h[2] >> 4) & 0x0f;
    let sample_rate_index = (h[2] >> 2) & 0x03;
    let padding = ((h[2] >> 1) & 0x01) as usize;
    if version == 1 || layer != 1 || bitrate_index == 0 || bitrate_index == 15 || sample_rate_index == 3
    {
        return None;
    }
    let bitrates_mpeg1 = [
        0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0,
    ];
    let bitrates_mpeg2 = [
        0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0,
    ];
    let sample_rates = if version == 3 {
        [44100usize, 48000, 32000]
    } else if version == 2 {
        [22050, 24000, 16000]
    } else {
        [11025, 12000, 8000]
    };
    let bitrate = if version == 3 {
        bitrates_mpeg1[bitrate_index as usize]
    } else {
        bitrates_mpeg2[bitrate_index as usize]
    } as usize
        * 1000;
    let sample_rate = sample_rates[sample_rate_index as usize];
    let samples_per_frame = if version == 3 { 1152 } else { 576 };
    Some((samples_per_frame / 8) * bitrate / sample_rate + padding)
}

/// Read total_samples from a FLAC STREAMINFO block (0 if unknown).
fn flac_total_samples(path: &Path) -> Result<Option<u64>, Failure> {
    let mut file = File::open(path).map_err(|e| io_failure("cannot open FLAC output", e))?;
    let mut magic = [0u8; 4];
    file.read_exact(&mut magic)
        .map_err(|_| Failure::new("INCOMPLETE", "FLAC output is too short"))?;
    if &magic != b"fLaC" {
        return Err(Failure::new("INCOMPLETE", "FLAC output has no fLaC marker"));
    }
    loop {
        let mut h = [0u8; 4];
        file.read_exact(&mut h)
            .map_err(|_| Failure::new("INCOMPLETE", "truncated FLAC metadata"))?;
        let last = h[0] & 0x80 != 0;
        let block_type = h[0] & 0x7f;
        let length = ((h[1] as u64) << 16) | ((h[2] as u64) << 8) | h[3] as u64;
        if length > 64 * 1024 * 1024 {
            return Err(Failure::new("INVALID_NCM", "implausible FLAC metadata length"));
        }
        if block_type == 0 {
            if length < 34 {
                return Err(Failure::new("INCOMPLETE", "short FLAC STREAMINFO block"));
            }
            let mut info = [0u8; 34];
            file.read_exact(&mut info)
                .map_err(|_| Failure::new("INCOMPLETE", "truncated FLAC STREAMINFO"))?;
            let packed = u64::from_be_bytes(info[10..18].try_into().unwrap());
            let total = packed & ((1u64 << 36) - 1);
            return Ok(if total == 0 { None } else { Some(total) });
        }
        file.seek(SeekFrom::Current(length as i64))
            .map_err(|e| io_failure("seek FLAC metadata", e))?;
        if last {
            return Ok(None);
        }
    }
}

/// Fully decode the restored audio and check its declared sample count.
///
/// A truncated MP3/FLAC can be demuxed far enough to look plausible.  For MP3
/// the frame walk catches a partial final frame; for both formats the decoder
/// is run to EOF and the decoded frame count is compared with the container's
/// declared total (FLAC STREAMINFO total_samples, MP3 Xing/LAME n_frames).
fn validate_audio(path: &Path, format: &str) -> Result<AudioValidation, Failure> {
    if CANCELLED.load(Ordering::Relaxed) {
        return Err(Failure::new("CANCELLED", "decryption cancelled"));
    }
    if format == "mp3" {
        check_mp3_frames(path)?;
    }
    let flac_samples = if format == "flac" {
        flac_total_samples(path)?
    } else {
        None
    };

    let file = File::open(path).map_err(|e| io_failure("cannot open output for validation", e))?;
    let mss = MediaSourceStream::new(Box::new(file), Default::default());
    let mut hint = Hint::new();
    hint.with_extension(format);

    let probed = get_probe()
        .format(
            &hint,
            mss,
            &FormatOptions {
                enable_gapless: true,
                ..Default::default()
            },
            &MetadataOptions::default(),
        )
        .map_err(|e| {
            Failure::new(
                "INCOMPLETE",
                format!("audio container cannot be parsed (truncated file?): {e}"),
            )
        })?;
    let mut fmt = probed.format;
    let track = fmt
        .default_track()
        .ok_or_else(|| Failure::new("INCOMPLETE", "audio container has no decodable track"))?;
    let track_id = track.id;
    let sample_rate = track
        .codec_params
        .sample_rate
        .ok_or_else(|| Failure::new("INCOMPLETE", "audio track has no sample rate"))?;
    let declared_frames = flac_samples.or(track.codec_params.n_frames);
    let mut decoder = get_codecs()
        .make(&track.codec_params, &DecoderOptions::default())
        .map_err(|e| Failure::new("UNSUPPORTED_FORMAT", format!("no decoder: {e}")))?;

    let mut frames: u64 = 0;
    loop {
        if CANCELLED.load(Ordering::Relaxed) {
            return Err(Failure::new("CANCELLED", "decryption cancelled"));
        }
        match fmt.next_packet() {
            Ok(packet) => {
                if packet.track_id() != track_id {
                    continue;
                }
                match decoder.decode(&packet) {
                    Ok(decoded) => frames = frames.saturating_add(decoded.frames() as u64),
                    Err(SymphoniaError::IoError(e))
                        if e.kind() == io::ErrorKind::UnexpectedEof =>
                    {
                        break;
                    }
                    Err(SymphoniaError::DecodeError(msg)) => {
                        return Err(Failure::new(
                            "INCOMPLETE",
                            format!("audio decode failed (truncated or corrupt): {msg}"),
                        ));
                    }
                    Err(e) => {
                        return Err(Failure::new(
                            "INCOMPLETE",
                            format!("audio decode failed (truncated or corrupt): {e}"),
                        ));
                    }
                }
            }
            Err(SymphoniaError::IoError(e)) if e.kind() == io::ErrorKind::UnexpectedEof => break,
            Err(SymphoniaError::ResetRequired) => {
                return Err(Failure::new(
                    "UNSUPPORTED_FORMAT",
                    "audio stream changed parameters during validation",
                ));
            }
            Err(e) => {
                return Err(Failure::new(
                    "INCOMPLETE",
                    format!("audio demux failed (truncated or corrupt): {e}"),
                ));
            }
        }
    }

    if frames == 0 || sample_rate == 0 {
        return Err(Failure::new("INCOMPLETE", "audio contains no decodable frames"));
    }

    if format == "flac" {
        if let Some(total) = flac_samples {
            if frames != total {
                return Err(Failure::with_extra(
                    "INCOMPLETE",
                    format!(
                        "FLAC decoded {frames} samples but STREAMINFO declares {total}; file is truncated"
                    ),
                    json!({"decodedFrames": frames, "declaredFrames": total}),
                ));
            }
        }
    } else if let Some(declared) = declared_frames {
        // For a CBR MP3 without a Xing header symphonia estimates n_frames from
        // the available bytes, so it can be smaller than the decoded count.  It
        // is still safe to reject when fewer frames were decoded than declared.
        if frames < declared {
            return Err(Failure::with_extra(
                "INCOMPLETE",
                format!(
                    "MP3 decoded {frames} samples but the stream declares {declared}; file is truncated"
                ),
                json!({"decodedFrames": frames, "declaredFrames": declared}),
            ));
        }
    }

    Ok(AudioValidation {
        duration_ms: frames.saturating_mul(1000) / sample_rate as u64,
        decoded_frames: frames,
        declared_frames,
    })
}

/// Tolerance between the decoded duration and the NCM metadata duration.
///
/// The metadata duration is in milliseconds.  The structural checks are the
/// primary proof of completeness; this comparison catches streams whose final
/// frame is intact but whose payload was cut at a frame boundary.  500 ms
/// leaves room for encoder padding while rejecting a lost second or more of
/// audio.
const DURATION_TOLERANCE_MS: u64 = 500;

fn check_decoded_duration(validation: &AudioValidation, info: &NcmInfo) -> Result<(), Failure> {
    let decoded_ms = validation.duration_ms;
    if decoded_ms < 1000 {
        return Err(Failure::new(
            "INCOMPLETE",
            format!("decoded audio is only {decoded_ms} ms long"),
        ));
    }
    if info.duration_ms > 0 && decoded_ms.abs_diff(info.duration_ms) > DURATION_TOLERANCE_MS {
        return Err(Failure::with_extra(
            "INCOMPLETE",
            format!(
                "decoded duration {} ms does not match NCM metadata {} ms (tolerance {} ms)",
                decoded_ms, info.duration_ms, DURATION_TOLERANCE_MS
            ),
            json!({
                "decodedMs": decoded_ms,
                "metaDurationMs": info.duration_ms,
                "toleranceMs": DURATION_TOLERANCE_MS,
                "decodedFrames": validation.decoded_frames,
                "declaredFrames": validation.declared_frames,
            }),
        ));
    }
    Ok(())
}

/// What the Kotlin layer should publish, and how it was produced.
struct PublishPlan {
    path: std::path::PathBuf,
    format: &'static str,
    validation: AudioValidation,
    /// Transcode measurements, or the failed attempt when `fallback` is set.
    transcode: Value,
    /// Set only when the FLAC had to be published instead of an MP3.
    fallback: Option<Value>,
}

fn encoder_version() -> String {
    #[cfg(target_os = "android")]
    {
        format!("libmp3lame {}", lame::version())
    }
    #[cfg(not(target_os = "android"))]
    {
        "libmp3lame (not built for host)".to_string()
    }
}

fn transcode_stats_json(stats: &TranscodeStats) -> Value {
    let pcm_bytes = stats
        .decoded_frames
        .saturating_mul(stats.channels as u64)
        .saturating_mul(2);
    json!({
        "ok": true,
        "encoder": encoder_version(),
        "bitrateKbps": 320,
        "inputBytes": stats.input_bytes,
        "outputBytes": stats.output_bytes,
        "pcmBytes": pcm_bytes,
        "sampleRate": stats.sample_rate,
        "outputSampleRate": stats.output_sample_rate,
        "channels": stats.channels,
        "decodedFrames": stats.decoded_frames,
        "durationMs": stats.duration_ms,
        "decodeMs": stats.decode_ms,
        "encodeMs": stats.encode_ms,
        "transcodeMs": stats.transcode_ms,
        "mp3Frames": stats.mp3_frames,
        "resampled": stats.resampled,
    })
}

/// Validate the decrypted audio and, for FLAC, produce the MP3 that replaces it.
///
/// The FLAC is deleted only after the MP3 has been fully decoded and validated.
/// If the encoder cannot be used, the FLAC is validated and returned instead
/// (`fallback` is set) so the task still succeeds, exactly as before.
fn prepare_publish(
    output: &Path,
    source_format: &str,
    info: &NcmInfo,
) -> Result<PublishPlan, Failure> {
    if source_format != "flac" {
        // MP3 NCMs take the original path: one validation decode, no extra pass.
        let validation = match validate_audio(output, "mp3") {
            Ok(v) => v,
            Err(e) => {
                let _ = fs::remove_file(output);
                return Err(e);
            }
        };
        if let Err(e) = check_decoded_duration(&validation, info) {
            let _ = fs::remove_file(output);
            return Err(e);
        }
        return Ok(PublishPlan {
            path: output.to_path_buf(),
            format: "mp3",
            validation,
            transcode: Value::Null,
            fallback: None,
        });
    }

    // Fixed, distinct name: `with_file_name` so the FLAC intermediate can never
    // be clobbered even if a caller passes a path that already ends in .mp3.
    let mp3_path = output.with_file_name("transcoded.mp3");

    let (transcode, fallback) = match transcode::transcode_flac_to_mp3(output, &mp3_path, &CANCELLED)
    {
        Ok(stats) => {
            // Full decode validation of the artefact that will be published.
            let validate_start = std::time::Instant::now();
            let mp3_validation = validate_audio(&mp3_path, "mp3");
            let validate_ms = validate_start.elapsed().as_millis() as u64;
            match mp3_validation {
                Ok(validation) => {
                    if let Err(e) = check_decoded_duration(&validation, info) {
                        let _ = fs::remove_file(&mp3_path);
                        let _ = fs::remove_file(output);
                        return Err(e);
                    }
                    // Conversion succeeded and the result is validated: only
                    // the MP3 survives.
                    let _ = fs::remove_file(output);
                    let mut stats_json = transcode_stats_json(&stats);
                    if let Some(obj) = stats_json.as_object_mut() {
                        obj.insert("validateMs".into(), json!(validate_ms));
                    }
                    return Ok(PublishPlan {
                        path: mp3_path,
                        format: "mp3",
                        validation,
                        transcode: stats_json,
                        fallback: None,
                    });
                }
                Err(e) => {
                    // The encoder produced an invalid MP3.  Never publish it;
                    // the original audio is still on disk, so fall back to it.
                    let _ = fs::remove_file(&mp3_path);
                    (
                        json!({"ok": false, "code": e.code, "message": e.message}),
                        Some(json!({
                            "code": e.code,
                            "message": e.message,
                            "stage": "validate-mp3",
                        })),
                    )
                }
            }
        }
        Err(e) if e.kind == TranscodeErrorKind::Audio => {
            // The FLAC itself is truncated or corrupt.  Publishing it would
            // publish a broken file, so this stays a task failure.
            let _ = fs::remove_file(&mp3_path);
            let _ = fs::remove_file(output);
            return Err(Failure::with_extra(
                e.code,
                e.message,
                json!({"transcodeStage": "decode"}),
            ));
        }
        Err(e) => {
            let _ = fs::remove_file(&mp3_path);
            (
                json!({"ok": false, "code": e.code, "message": e.message}),
                Some(json!({
                    "code": e.code,
                    "message": e.message,
                    "stage": "encode",
                })),
            )
        }
    };

    // Compatibility path: validate and publish the FLAC, as the pipeline did
    // before transcoding existed.  `fallback` is always set here.
    let validation = match validate_audio(output, "flac") {
        Ok(v) => v,
        Err(e) => {
            let _ = fs::remove_file(output);
            return Err(e);
        }
    };
    if let Err(e) = check_decoded_duration(&validation, info) {
        let _ = fs::remove_file(output);
        return Err(e);
    }
    Ok(PublishPlan {
        path: output.to_path_buf(),
        format: "flac",
        validation,
        transcode,
        fallback,
    })
}

fn decrypt_impl(input: &Path, output: &Path) -> Value {
    CANCELLED.store(false, Ordering::Relaxed);
    if let Err(e) = check_ncm_structure(input) {
        return failure_json(e);
    }
    if let Err(e) = fs::remove_file(output) {
        if e.kind() != io::ErrorKind::NotFound {
            return failure_json(io_failure("cannot clear previous temporary output", e));
        }
    }

    let (mut ncm, info) = match read_info(input) {
        Ok(v) => v,
        Err(e) => return failure_json(e),
    };

    let tmp_result = (|| -> Result<u64, Failure> {
        let mut out =
            File::create(output).map_err(|e| io_failure("cannot create temporary output", e))?;
        let mut buf = vec![0u8; 1024 * 1024];
        let mut total: u64 = 0;
        // A FLAC intermediate is decoded and re-read by this same process, so
        // waiting for it to reach the disk (fsync) buys nothing; the MP3 path
        // keeps the durability flush it always had.
        let mut durable = true;
        loop {
            if CANCELLED.load(Ordering::Relaxed) {
                return Err(Failure::new("CANCELLED", "decryption cancelled"));
            }
            let n = ncm
                .read(&mut buf)
                .map_err(|e| io_failure("read NCM audio", e))?;
            if n == 0 {
                break;
            }
            if total == 0 && n >= 4 && &buf[..4] == b"fLaC" {
                durable = false;
            }
            out.write_all(&buf[..n])
                .map_err(|e| io_failure("write temporary output", e))?;
            total = total.saturating_add(n as u64);
        }
        out.flush()
            .map_err(|e| io_failure("flush temporary output", e))?;
        if durable {
            out.sync_all()
                .map_err(|e| io_failure("sync temporary output", e))?;
        }
        if total < MIN_AUDIO_BYTES {
            return Err(Failure::new("INCOMPLETE", "decrypted audio is too short"));
        }
        Ok(total)
    })();

    let bytes = match tmp_result {
        Ok(v) => v,
        Err(e) => {
            let _ = fs::remove_file(output);
            return failure_json(e);
        }
    };

    let source_format = match detect_format(output, &info.format) {
        Ok(f) => f,
        Err(e) => {
            let _ = fs::remove_file(output);
            return failure_json(e);
        }
    };

    let plan = match prepare_publish(output, source_format, &info) {
        Ok(plan) => plan,
        Err(e) => return failure_json(e),
    };
    let decoded_ms = plan.validation.duration_ms;
    let final_size = fs::metadata(&plan.path).map(|m| m.len()).unwrap_or(bytes);

    json!({
        "ok": true,
        "code": "OK",
        "format": plan.format,
        "sourceFormat": source_format,
        "outputPath": plan.path.to_string_lossy(),
        "transcode": plan.transcode,
        "transcodeFallback": plan.fallback.is_some(),
        "transcodeFallbackReason": plan.fallback,
        "durationMs": decoded_ms,
        "metaDurationMs": info.duration_ms,
        "decodedFrames": plan.validation.decoded_frames,
        "declaredFrames": plan.validation.declared_frames,
        "bitrate": info.bitrate,
        "bytes": final_size,
        "artist": info.artist,
        "title": info.title,
        "album": info.album,
        "musicId": info.music_id,
    })
}

fn failure_json(e: Failure) -> Value {
    let mut value = json!({
        "ok": false,
        "code": e.code,
        "message": e.message,
    });
    if let Some(extra) = e.extra {
        if let (Some(dst), Some(src)) = (value.as_object_mut(), extra.as_object()) {
            for (k, v) in src {
                dst.insert(k.clone(), v.clone());
            }
        }
    }
    value
}

fn probe_impl(input: &Path) -> Value {
    match read_info(input) {
        Ok((_ncm, info)) => json!({
            "ok": true,
            "code": "OK",
            "format": info.format,
            "metaDurationMs": info.duration_ms,
            "bitrate": info.bitrate,
            "artist": info.artist,
            "title": info.title,
            "album": info.album,
            "musicId": info.music_id,
        }),
        Err(e) => failure_json(e),
    }
}

fn json_to_jstring(env: &mut jni::JNIEnv<'_>, value: &Value) -> jni::sys::jstring {
    match env.new_string(value.to_string()) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

fn jstring_to_rust(env: &mut jni::JNIEnv<'_>, value: &jni::objects::JString<'_>) -> Option<String> {
    env.get_string(value).ok().map(|s| s.into())
}

/// Decrypt `input` to `output` without tags, validate it, and return JSON.
///
/// The output is deleted on every failure path.  Only a validated file is left
/// for the Kotlin layer to publish.
#[no_mangle]
#[allow(non_snake_case)]
pub extern "system" fn Java_dev_ensomi_ncmdecode_NativeNcm_decrypt(
    mut env: jni::JNIEnv<'_>,
    _class: jni::objects::JClass<'_>,
    input: jni::objects::JString<'_>,
    output: jni::objects::JString<'_>,
) -> jni::sys::jstring {
    let Some(input) = jstring_to_rust(&mut env, &input) else {
        return json_to_jstring(&mut env, &json!({"ok": false, "code": "JNI", "message": "invalid input path"}));
    };
    let Some(output) = jstring_to_rust(&mut env, &output) else {
        return json_to_jstring(&mut env, &json!({"ok": false, "code": "JNI", "message": "invalid output path"}));
    };
    let result = catch_unwind(AssertUnwindSafe(|| {
        decrypt_impl(Path::new(&input), Path::new(&output))
    }))
    .unwrap_or_else(|_| {
        failure_json(Failure::new(
            "INTERNAL",
            "native decryption panicked; temporary output removed",
        ))
    });
    json_to_jstring(&mut env, &result)
}

#[no_mangle]
#[allow(non_snake_case)]
pub extern "system" fn Java_dev_ensomi_ncmdecode_NativeNcm_probe(
    mut env: jni::JNIEnv<'_>,
    _class: jni::objects::JClass<'_>,
    input: jni::objects::JString<'_>,
) -> jni::sys::jstring {
    let Some(input) = jstring_to_rust(&mut env, &input) else {
        return json_to_jstring(&mut env, &json!({"ok": false, "code": "JNI", "message": "invalid input path"}));
    };
    let result = catch_unwind(AssertUnwindSafe(|| probe_impl(Path::new(&input))))
        .unwrap_or_else(|_| failure_json(Failure::new("INTERNAL", "native probe panicked")));
    json_to_jstring(&mut env, &result)
}

#[no_mangle]
#[allow(non_snake_case)]
pub extern "system" fn Java_dev_ensomi_ncmdecode_NativeNcm_cancel(
    _env: jni::JNIEnv<'_>,
    _class: jni::objects::JClass<'_>,
) {
    CANCELLED.store(true, Ordering::Relaxed);
}

/// Host-side test helper used by src/bin/ncmcheck.rs.
pub fn decrypt_for_test(input: &Path, output: &Path) -> Value {
    decrypt_impl(input, output)
}

/// Device/host diagnostic helper used by src/bin/ncmtranscode.rs: run the normal
/// full-decode validation and report the measurements as JSON.
pub fn validate_for_test(path: &Path, format: &str) -> Value {
    match validate_audio(path, format) {
        Ok(v) => json!({
            "ok": true,
            "durationMs": v.duration_ms,
            "decodedFrames": v.decoded_frames,
            "declaredFrames": v.declared_frames,
        }),
        Err(e) => failure_json(e),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_random_file() {
        let path = std::env::temp_dir().join("ncm_jni_random_test.bin");
        fs::write(&path, b"not an ncm").unwrap();
        let result = probe_impl(&path);
        assert_eq!(result["ok"], false);
        assert_eq!(result["code"], "INVALID_NCM");
        let _ = fs::remove_file(path);
    }
}
