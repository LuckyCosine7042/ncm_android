//! FLAC -> MP3 320 kbps CBR transcoding for the decrypt pipeline.
//!
//! The decrypted FLAC is streamed through symphonia's FLAC decoder and encoded
//! with the vendored LAME library; nothing is buffered whole-file.  The same
//! pass doubles as the "did the download arrive complete" check for the FLAC
//! (decoded sample count vs. the STREAMINFO total), so the previous separate
//! validation decode is not repeated.
//!
//! Failure handling is split by cause:
//!
//! * [`TranscodeErrorKind::Audio`]  - the FLAC itself is truncated/corrupt.  The
//!   caller must fail the task exactly like the old validation did; publishing
//!   the FLAC would publish a broken file.
//! * [`TranscodeErrorKind::Encoder`] - the source is fine but the encoder (or
//!   its input format) is not usable.  The caller publishes the FLAC instead,
//!   after validating it, and logs `TRANSCODE_FALLBACK`.

#[cfg(target_os = "android")]
mod android;

#[cfg(target_os = "android")]
pub use android::transcode_flac_to_mp3;

#[cfg(not(target_os = "android"))]
pub fn transcode_flac_to_mp3(
    _flac: &std::path::Path,
    _mp3: &std::path::Path,
    _cancelled: &std::sync::atomic::AtomicBool,
) -> Result<TranscodeStats, TranscodeError> {
    Err(TranscodeError::encoder(
        "TRANSCODE_UNSUPPORTED_HOST",
        "libmp3lame is only built for Android targets",
    ))
}

/// Why a transcode attempt failed, and whether the source audio is trustworthy.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TranscodeErrorKind {
    /// The FLAC could not be decoded completely: do not publish anything.
    Audio,
    /// The FLAC decodes, but it cannot be encoded (unsupported rate/channels,
    /// encoder init/encode error, invalid encoder output): publish the FLAC.
    Encoder,
}

#[derive(Debug)]
pub struct TranscodeError {
    pub kind: TranscodeErrorKind,
    /// Short machine-readable code, e.g. `TRANSCODE_ENCODER_INIT`.
    pub code: &'static str,
    pub message: String,
}

impl TranscodeError {
    pub fn new(kind: TranscodeErrorKind, code: &'static str, message: impl Into<String>) -> Self {
        Self {
            kind,
            code,
            message: message.into(),
        }
    }

    pub fn audio(code: &'static str, message: impl Into<String>) -> Self {
        Self::new(TranscodeErrorKind::Audio, code, message)
    }

    pub fn encoder(code: &'static str, message: impl Into<String>) -> Self {
        Self::new(TranscodeErrorKind::Encoder, code, message)
    }
}

/// Measurements and format facts from one successful transcode.
#[derive(Debug, Clone, Default)]
pub struct TranscodeStats {
    pub input_bytes: u64,
    pub output_bytes: u64,
    pub sample_rate: u32,
    pub output_sample_rate: u32,
    pub channels: u32,
    pub decoded_frames: u64,
    pub duration_ms: u64,
    /// Wall time spent inside the FLAC decoder.
    pub decode_ms: u64,
    /// Wall time spent inside LAME.
    pub encode_ms: u64,
    /// Wall time for the whole transcode (decode + encode + write).
    pub transcode_ms: u64,
    /// Number of complete MP3 frames written (including the Info frame).
    pub mp3_frames: u64,
    /// True when the source rate was resampled to a rate MPEG-1 supports.
    pub resampled: bool,
}
