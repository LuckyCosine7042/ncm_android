//! Minimal safe wrapper around the vendored libmp3lame encoder.
//!
//! Only the calls needed for constant-bitrate encoding of interleaved 16-bit
//! PCM are bound.  The encoder is configured exactly once per file and reused
//! for every frame; all buffers are owned by the caller so the transcode loop
//! can reuse them across the whole file.

#![allow(non_camel_case_types)]

use std::ffi::c_int;

/// Opaque `lame_global_flags` (defined in lame.h).
#[repr(C)]
pub struct LameGlobalFlags {
    _private: [u8; 0],
}

/// `vbr_off` from LAME's `vbr_mode` enum: constant bitrate.
const VBR_OFF: c_int = 0;

extern "C" {
    fn lame_init() -> *mut LameGlobalFlags;
    fn lame_close(gfp: *mut LameGlobalFlags) -> c_int;
    fn lame_set_in_samplerate(gfp: *mut LameGlobalFlags, srate: c_int) -> c_int;
    fn lame_set_out_samplerate(gfp: *mut LameGlobalFlags, srate: c_int) -> c_int;
    fn lame_set_num_channels(gfp: *mut LameGlobalFlags, channels: c_int) -> c_int;
    fn lame_set_brate(gfp: *mut LameGlobalFlags, kbps: c_int) -> c_int;
    fn lame_set_VBR(gfp: *mut LameGlobalFlags, mode: c_int) -> c_int;
    fn lame_set_bWriteVbrTag(gfp: *mut LameGlobalFlags, write: c_int) -> c_int;
    fn lame_init_params(gfp: *mut LameGlobalFlags) -> c_int;
    fn lame_get_framesize(gfp: *const LameGlobalFlags) -> c_int;
    fn lame_encode_buffer_interleaved(
        gfp: *mut LameGlobalFlags,
        pcm: *const i16,
        num_samples: c_int,
        mp3buf: *mut u8,
        mp3buf_size: c_int,
    ) -> c_int;
    fn lame_encode_flush(
        gfp: *mut LameGlobalFlags,
        mp3buf: *mut u8,
        mp3buf_size: c_int,
    ) -> c_int;
    fn lame_get_lametag_frame(
        gfp: *const LameGlobalFlags,
        buffer: *mut u8,
        size: usize,
    ) -> usize;
    fn get_lame_version() -> *const std::ffi::c_char;
}

/// Library version string reported by logcat diagnostics, e.g. `3.100`.
pub fn version() -> String {
    unsafe {
        let ptr = get_lame_version();
        if ptr.is_null() {
            return "unknown".to_string();
        }
        std::ffi::CStr::from_ptr(ptr).to_string_lossy().into_owned()
    }
}

/// Bitrate of every file produced by this app: 320 kbps CBR.
pub const BITRATE_KBPS: c_int = 320;

#[derive(Debug)]
pub struct LameError {
    pub code: &'static str,
    pub message: String,
}

impl LameError {
    fn new(code: &'static str, message: impl Into<String>) -> Self {
        Self {
            code,
            message: message.into(),
        }
    }
}

/// One initialised LAME encoder instance.
pub struct Encoder {
    gfp: *mut LameGlobalFlags,
    channels: usize,
    /// Samples per MP3 granule (1152 for MPEG-1), from `lame_get_framesize`.
    pub framesize: usize,
    /// `1.25 * frames + 7200` is LAME's documented worst case output size.
    pub max_output_bytes: usize,
}

// The encoder is used from a single worker thread; JNI calls are serialised by
// NativeNcm's lock, and the struct owns its own state.
unsafe impl Send for Encoder {}

impl Encoder {
    /// Create and fully initialise an encoder.
    ///
    /// `in_sample_rate` is the PCM rate fed to [`Encoder::encode`];
    /// `out_sample_rate` is the MP3 rate.  They may differ (LAME resamples),
    /// which is how >48 kHz FLAC sources keep a supported MP3 rate.
    pub fn new(
        in_sample_rate: u32,
        out_sample_rate: u32,
        channels: usize,
    ) -> Result<Self, LameError> {
        if channels == 0 || channels > 2 {
            return Err(LameError::new(
                "TRANSCODE_UNSUPPORTED_CHANNELS",
                format!("LAME supports mono/stereo only, source has {channels} channels"),
            ));
        }
        let gfp = unsafe { lame_init() };
        if gfp.is_null() {
            return Err(LameError::new(
                "TRANSCODE_ENCODER_INIT",
                "lame_init returned NULL",
            ));
        }

        let mut enc = Encoder {
            gfp,
            channels,
            framesize: 1152,
            max_output_bytes: 0,
        };

        // Every setter returns < 0 on an invalid argument.
        let checks = unsafe {
            [
                ("in_samplerate", lame_set_in_samplerate(gfp, in_sample_rate as c_int)),
                ("out_samplerate", lame_set_out_samplerate(gfp, out_sample_rate as c_int)),
                ("num_channels", lame_set_num_channels(gfp, channels as c_int)),
                ("brate", lame_set_brate(gfp, BITRATE_KBPS)),
                ("VBR", lame_set_VBR(gfp, VBR_OFF)),
                // Keep LAME's default frame header (Xing/Info with frame count
                // and TOC) so players can seek and report a duration.
                ("bWriteVbrTag", lame_set_bWriteVbrTag(gfp, 1)),
            ]
        };
        for (name, rc) in checks {
            if rc < 0 {
                return Err(LameError::new(
                    "TRANSCODE_ENCODER_INIT",
                    format!("lame_set_{name} failed with {rc}"),
                ));
            }
        }

        // Initialise the psymodel for the actual bitrate/sample-rate pair.  This
        // is where LAME rejects impossible combinations (e.g. 96 kHz MPEG-1).
        let rc = unsafe { lame_init_params(gfp) };
        if rc < 0 {
            return Err(LameError::new(
                "TRANSCODE_ENCODER_INIT",
                format!(
                    "lame_init_params failed with {rc} for {in_sample_rate} Hz -> \
                     {out_sample_rate} Hz, {channels} ch, {BITRATE_KBPS} kbps"
                ),
            ));
        }

        let framesize = unsafe { lame_get_framesize(gfp) };
        if framesize <= 0 {
            return Err(LameError::new(
                "TRANSCODE_ENCODER_INIT",
                format!("lame_get_framesize returned {framesize}"),
            ));
        }
        enc.framesize = framesize as usize;
        enc.max_output_bytes = (framesize as usize * 5 / 4) + 7200;
        Ok(enc)
    }

    /// Encode interleaved 16-bit PCM.
    ///
    /// `pcm` must contain `frames * channels` samples.  `out` is cleared and
    /// filled with the produced MP3 bytes.
    pub fn encode(&mut self, pcm: &[i16], out: &mut Vec<u8>) -> Result<(), LameError> {
        let channels = self.channels;
        let frames = pcm.len() / channels;
        if frames == 0 {
            out.clear();
            return Ok(());
        }
        let needed = frames * 5 / 4 + 7200;
        if out.capacity() < needed {
            out.reserve(needed + 4096);
        }
        let rc = unsafe {
            lame_encode_buffer_interleaved(
                self.gfp,
                pcm.as_ptr(),
                frames as c_int,
                out.as_mut_ptr(),
                out.capacity() as c_int,
            )
        };
        if rc < 0 {
            return Err(LameError::new(
                "TRANSCODE_ENCODE",
                format!(
                    "lame_encode_buffer_interleaved failed with {rc} ({frames} frames, {channels} ch)"
                ),
            ));
        }
        unsafe { out.set_len(rc as usize) };
        Ok(())
    }

    /// Flush the encoder's internal reservoir.  `out` receives the tail frames.
    pub fn flush(&mut self, out: &mut Vec<u8>) -> Result<(), LameError> {
        let capacity = self.framesize * 5 / 4 + 7200;
        if out.capacity() < capacity {
            out.reserve(capacity);
        }
        let rc = unsafe {
            lame_encode_flush(
                self.gfp,
                out.as_mut_ptr(),
                out.capacity() as c_int,
            )
        };
        if rc < 0 {
            return Err(LameError::new(
                "TRANSCODE_ENCODE",
                format!("lame_encode_flush failed with {rc}"),
            ));
        }
        unsafe { out.set_len(rc as usize) };
        Ok(())
    }

    /// Return the finalised Xing/Info frame.
    ///
    /// LAME reserves the first frame for stream metadata; after `flush` this
    /// call produces the version that carries the real frame count and TOC,
    /// which is written over the placeholder at offset 0.
    pub fn lametag_frame(&mut self) -> Vec<u8> {
        let capacity = 4096;
        let mut buf = vec![0u8; capacity];
        let written = unsafe { lame_get_lametag_frame(self.gfp, buf.as_mut_ptr(), capacity) };
        buf.truncate(written.min(capacity));
        buf
    }
}

impl Drop for Encoder {
    fn drop(&mut self) {
        if !self.gfp.is_null() {
            unsafe {
                lame_close(self.gfp);
            }
            self.gfp = std::ptr::null_mut();
        }
    }
}
